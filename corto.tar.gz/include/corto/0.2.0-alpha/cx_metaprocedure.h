/* cx_metaprocedure.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_metaprocedure_H
#define cx_metaprocedure_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::metaprocedure::bind() */
cx_int16 _cx_metaprocedure_bind(cx_metaprocedure _this);
#define cx_metaprocedure_bind(_this) _cx_metaprocedure_bind(cx_metaprocedure(_this))

#ifdef __cplusplus
}
#endif
#endif

