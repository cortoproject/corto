#ifndef HTML_H
#define HTML_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* HTML_H */
