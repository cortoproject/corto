/* include/xml.h
 *
 * This file is generated. Do not modify.
 */

#ifndef xml_H
#define xml_H

#include "corto.h"
#ifdef __cplusplus
extern "C" {
#endif

/* $header() */
/* You can put your own definitions here! */
/* $end */

#ifdef __cplusplus
}
#endif
#endif

