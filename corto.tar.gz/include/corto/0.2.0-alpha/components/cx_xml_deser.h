/*
 * core_deserxml.h
 *
 *  Created on: Mar 20, 2012
 *      Author: sander
 */

#ifndef CORE_DESERXML_H_
#define CORE_DESERXML_H_

#include "corto.h"

int cx_deserXml(cx_string file, int argc, char* argv[], void* udata);

#endif /* CORE_DESERXML_H_ */
