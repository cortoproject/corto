/* cx_character.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_character_H
#define cx_character_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::character::init() */
cx_int16 _cx_character_init(cx_character _this);
#define cx_character_init(_this) _cx_character_init(cx_character(_this))

#ifdef __cplusplus
}
#endif
#endif

