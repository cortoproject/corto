/* cx_constant.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_constant_H
#define cx_constant_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::constant::init() */
cx_int16 _cx_constant_init(cx_constant *_this);
#define cx_constant_init(_this) _cx_constant_init(_this)

#ifdef __cplusplus
}
#endif
#endif

