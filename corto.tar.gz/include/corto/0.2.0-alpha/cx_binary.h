/* cx_binary.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_binary_H
#define cx_binary_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::binary::init() */
cx_int16 _cx_binary_init(cx_binary _this);
#define cx_binary_init(_this) _cx_binary_init(cx_binary(_this))

#ifdef __cplusplus
}
#endif
#endif

