/* cx_package.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_package_H
#define cx_package_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

