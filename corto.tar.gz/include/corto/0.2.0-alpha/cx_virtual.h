/* cx_virtual.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_virtual_H
#define cx_virtual_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::virtual::init() */
cx_int16 _cx_virtual_init(cx_virtual _this);
#define cx_virtual_init(_this) _cx_virtual_init(cx_virtual(_this))

#ifdef __cplusplus
}
#endif
#endif

