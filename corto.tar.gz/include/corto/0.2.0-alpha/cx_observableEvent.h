/* cx_observableEvent.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_observableEvent_H
#define cx_observableEvent_H

#include "corto.h"
#include "cx_event.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* virtual ::corto::lang::observableEvent::handle() */
void cx_observableEvent_handle(cx_observableEvent _this);

/* ::corto::lang::observableEvent::handle() */
cx_void _cx_observableEvent_handle_v(cx_observableEvent _this);
#define cx_observableEvent_handle_v(_this) _cx_observableEvent_handle_v(cx_observableEvent(_this))

#ifdef __cplusplus
}
#endif
#endif

