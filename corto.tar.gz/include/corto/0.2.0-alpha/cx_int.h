/* cx_int.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_int_H
#define cx_int_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::int::init() */
cx_int16 _cx_int_init(cx_int _this);
#define cx_int_init(_this) _cx_int_init(cx_int(_this))

#ifdef __cplusplus
}
#endif
#endif

