/* ic__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_ic__API_H
#define corto_ic__API_H

#include "corto.h"
#include "ic__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::ic::accumulator */
CORTO_IC_EXPORT ic_accumulator ic_accumulatorCreate(cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT ic_accumulator ic_accumulatorCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);

CORTO_IC_EXPORT ic_accumulator ic_accumulatorDeclare(void);
CORTO_IC_EXPORT ic_accumulator ic_accumulatorDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_accumulatorDefine(ic_accumulator _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT void ic_accumulatorUpdate(ic_accumulator _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT void ic_accumulatorSet(ic_accumulator _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT cx_string ic_accumulatorStr(ic_accumulator value);
CORTO_IC_EXPORT ic_accumulator ic_accumulatorFromStr(ic_accumulator value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_accumulatorCopy(ic_accumulator *dst, ic_accumulator src);
CORTO_IC_EXPORT cx_int16 ic_accumulatorCompare(ic_accumulator dst, ic_accumulator src);

/* ::corto::ic::address */
CORTO_IC_EXPORT ic_address ic_addressCreate(cx_word value);
CORTO_IC_EXPORT ic_address ic_addressCreateChild(cx_object _parent, cx_string _name, cx_word value);

CORTO_IC_EXPORT ic_address ic_addressDeclare(void);
CORTO_IC_EXPORT ic_address ic_addressDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_addressDefine(ic_address _this, cx_word value);
CORTO_IC_EXPORT void ic_addressUpdate(ic_address _this, cx_word value);
CORTO_IC_EXPORT void ic_addressSet(ic_address _this, cx_word value);
CORTO_IC_EXPORT cx_string ic_addressStr(ic_address value);
CORTO_IC_EXPORT ic_address ic_addressFromStr(ic_address value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_addressCopy(ic_address *dst, ic_address src);
CORTO_IC_EXPORT cx_int16 ic_addressCompare(ic_address dst, ic_address src);

/* ::corto::ic::derefKind */
CORTO_IC_EXPORT ic_derefKind* ic_derefKindCreate(ic_derefKind value);
CORTO_IC_EXPORT ic_derefKind* ic_derefKindCreateChild(cx_object _parent, cx_string _name, ic_derefKind value);

CORTO_IC_EXPORT ic_derefKind* ic_derefKindDeclare(void);
CORTO_IC_EXPORT ic_derefKind* ic_derefKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_derefKindDefine(ic_derefKind* _this, ic_derefKind value);
CORTO_IC_EXPORT void ic_derefKindUpdate(ic_derefKind* _this, ic_derefKind value);
CORTO_IC_EXPORT void ic_derefKindSet(ic_derefKind* _this, ic_derefKind value);
CORTO_IC_EXPORT cx_string ic_derefKindStr(ic_derefKind value);
CORTO_IC_EXPORT ic_derefKind* ic_derefKindFromStr(ic_derefKind* value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_derefKindCopy(ic_derefKind* *dst, ic_derefKind* src);
CORTO_IC_EXPORT cx_int16 ic_derefKindCompare(ic_derefKind* dst, ic_derefKind* src);

CORTO_IC_EXPORT cx_int16 ic_derefKindInit(ic_derefKind* value);
CORTO_IC_EXPORT cx_int16 ic_derefKindDeinit(ic_derefKind* value);

/* ::corto::ic::element */
CORTO_IC_EXPORT ic_element ic_elementCreate(ic_storage base_1, ic_node index);
CORTO_IC_EXPORT ic_element ic_elementCreateChild(cx_object _parent, cx_string _name, ic_storage base_1, ic_node index);

CORTO_IC_EXPORT ic_element ic_elementDeclare(void);
CORTO_IC_EXPORT ic_element ic_elementDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_elementDefine(ic_element _this, ic_storage base_1, ic_node index);
CORTO_IC_EXPORT void ic_elementUpdate(ic_element _this, ic_storage base_1, ic_node index);
CORTO_IC_EXPORT void ic_elementSet(ic_element _this, ic_storage base_1, ic_node index);
CORTO_IC_EXPORT cx_string ic_elementStr(ic_element value);
CORTO_IC_EXPORT ic_element ic_elementFromStr(ic_element value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_elementCopy(ic_element *dst, ic_element src);
CORTO_IC_EXPORT cx_int16 ic_elementCompare(ic_element dst, ic_element src);

/* ::corto::ic::function */
CORTO_IC_EXPORT ic_function ic_functionCreate(cx_function function);
CORTO_IC_EXPORT ic_function ic_functionCreateChild(cx_object _parent, cx_string _name, cx_function function);

CORTO_IC_EXPORT ic_function ic_functionDeclare(void);
CORTO_IC_EXPORT ic_function ic_functionDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_functionDefine(ic_function _this, cx_function function);
CORTO_IC_EXPORT void ic_functionUpdate(ic_function _this, cx_function function);
CORTO_IC_EXPORT void ic_functionSet(ic_function _this, cx_function function);
CORTO_IC_EXPORT cx_string ic_functionStr(ic_function value);
CORTO_IC_EXPORT ic_function ic_functionFromStr(ic_function value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_functionCopy(ic_function *dst, ic_function src);
CORTO_IC_EXPORT cx_int16 ic_functionCompare(ic_function dst, ic_function src);

/* ::corto::ic::kind */
CORTO_IC_EXPORT ic_kind* ic_kindCreate(ic_kind value);
CORTO_IC_EXPORT ic_kind* ic_kindCreateChild(cx_object _parent, cx_string _name, ic_kind value);

CORTO_IC_EXPORT ic_kind* ic_kindDeclare(void);
CORTO_IC_EXPORT ic_kind* ic_kindDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_kindDefine(ic_kind* _this, ic_kind value);
CORTO_IC_EXPORT void ic_kindUpdate(ic_kind* _this, ic_kind value);
CORTO_IC_EXPORT void ic_kindSet(ic_kind* _this, ic_kind value);
CORTO_IC_EXPORT cx_string ic_kindStr(ic_kind value);
CORTO_IC_EXPORT ic_kind* ic_kindFromStr(ic_kind* value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_kindCopy(ic_kind* *dst, ic_kind* src);
CORTO_IC_EXPORT cx_int16 ic_kindCompare(ic_kind* dst, ic_kind* src);

CORTO_IC_EXPORT cx_int16 ic_kindInit(ic_kind* value);
CORTO_IC_EXPORT cx_int16 ic_kindDeinit(ic_kind* value);

/* ::corto::ic::label */
CORTO_IC_EXPORT ic_label ic_labelCreate(void);
CORTO_IC_EXPORT ic_label ic_labelCreateChild(cx_object _parent, cx_string _name);

CORTO_IC_EXPORT ic_label ic_labelDeclare(void);
CORTO_IC_EXPORT ic_label ic_labelDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_labelDefine(ic_label _this);
CORTO_IC_EXPORT void ic_labelUpdate(ic_label _this);
CORTO_IC_EXPORT void ic_labelSet(ic_label _this);
CORTO_IC_EXPORT cx_string ic_labelStr(ic_label value);
CORTO_IC_EXPORT ic_label ic_labelFromStr(ic_label value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_labelCopy(ic_label *dst, ic_label src);
CORTO_IC_EXPORT cx_int16 ic_labelCompare(ic_label dst, ic_label src);

/* ::corto::ic::literal */
CORTO_IC_EXPORT ic_literal ic_literalCreate(cx_any value);
CORTO_IC_EXPORT ic_literal ic_literalCreateChild(cx_object _parent, cx_string _name, cx_any value);

CORTO_IC_EXPORT ic_literal ic_literalDeclare(void);
CORTO_IC_EXPORT ic_literal ic_literalDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_literalDefine(ic_literal _this, cx_any value);
CORTO_IC_EXPORT void ic_literalUpdate(ic_literal _this, cx_any value);
CORTO_IC_EXPORT void ic_literalSet(ic_literal _this, cx_any value);
CORTO_IC_EXPORT cx_string ic_literalStr(ic_literal value);
CORTO_IC_EXPORT ic_literal ic_literalFromStr(ic_literal value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_literalCopy(ic_literal *dst, ic_literal src);
CORTO_IC_EXPORT cx_int16 ic_literalCompare(ic_literal dst, ic_literal src);

/* ::corto::ic::member */
CORTO_IC_EXPORT ic_member ic_memberCreate(ic_storage base_1, cx_member member);
CORTO_IC_EXPORT ic_member ic_memberCreateChild(cx_object _parent, cx_string _name, ic_storage base_1, cx_member member);

CORTO_IC_EXPORT ic_member ic_memberDeclare(void);
CORTO_IC_EXPORT ic_member ic_memberDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_memberDefine(ic_member _this, ic_storage base_1, cx_member member);
CORTO_IC_EXPORT void ic_memberUpdate(ic_member _this, ic_storage base_1, cx_member member);
CORTO_IC_EXPORT void ic_memberSet(ic_member _this, ic_storage base_1, cx_member member);
CORTO_IC_EXPORT cx_string ic_memberStr(ic_member value);
CORTO_IC_EXPORT ic_member ic_memberFromStr(ic_member value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_memberCopy(ic_member *dst, ic_member src);
CORTO_IC_EXPORT cx_int16 ic_memberCompare(ic_member dst, ic_member src);

/* ::corto::ic::node */
CORTO_IC_EXPORT ic_node ic_nodeCreate(void);
CORTO_IC_EXPORT ic_node ic_nodeCreateChild(cx_object _parent, cx_string _name);

CORTO_IC_EXPORT ic_node ic_nodeDeclare(void);
CORTO_IC_EXPORT ic_node ic_nodeDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_nodeDefine(ic_node _this);
CORTO_IC_EXPORT void ic_nodeUpdate(ic_node _this);
CORTO_IC_EXPORT void ic_nodeSet(ic_node _this);
CORTO_IC_EXPORT cx_string ic_nodeStr(ic_node value);
CORTO_IC_EXPORT ic_node ic_nodeFromStr(ic_node value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_nodeCopy(ic_node *dst, ic_node src);
CORTO_IC_EXPORT cx_int16 ic_nodeCompare(ic_node dst, ic_node src);

/* ::corto::ic::object */
CORTO_IC_EXPORT ic_object ic_objectCreate(cx_object ptr);
CORTO_IC_EXPORT ic_object ic_objectCreateChild(cx_object _parent, cx_string _name, cx_object ptr);

CORTO_IC_EXPORT ic_object ic_objectDeclare(void);
CORTO_IC_EXPORT ic_object ic_objectDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_objectDefine(ic_object _this, cx_object ptr);
CORTO_IC_EXPORT void ic_objectUpdate(ic_object _this, cx_object ptr);
CORTO_IC_EXPORT void ic_objectSet(ic_object _this, cx_object ptr);
CORTO_IC_EXPORT cx_string ic_objectStr(ic_object value);
CORTO_IC_EXPORT ic_object ic_objectFromStr(ic_object value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_objectCopy(ic_object *dst, ic_object src);
CORTO_IC_EXPORT cx_int16 ic_objectCompare(ic_object dst, ic_object src);

/* ::corto::ic::op */
CORTO_IC_EXPORT ic_op ic_opCreate(cx_uint32 line, ic_opKind kind_1, ic_node s1, ic_node s2, ic_node s3, ic_derefKind s1Deref, ic_derefKind s2Deref, ic_derefKind s3Deref, cx_bool s1Any);
CORTO_IC_EXPORT ic_op ic_opCreateChild(cx_object _parent, cx_string _name, cx_uint32 line, ic_opKind kind_1, ic_node s1, ic_node s2, ic_node s3, ic_derefKind s1Deref, ic_derefKind s2Deref, ic_derefKind s3Deref, cx_bool s1Any);

CORTO_IC_EXPORT ic_op ic_opDeclare(void);
CORTO_IC_EXPORT ic_op ic_opDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_opDefine(ic_op _this, cx_uint32 line, ic_opKind kind_1, ic_node s1, ic_node s2, ic_node s3, ic_derefKind s1Deref, ic_derefKind s2Deref, ic_derefKind s3Deref, cx_bool s1Any);
CORTO_IC_EXPORT void ic_opUpdate(ic_op _this, cx_uint32 line, ic_opKind kind_1, ic_node s1, ic_node s2, ic_node s3, ic_derefKind s1Deref, ic_derefKind s2Deref, ic_derefKind s3Deref, cx_bool s1Any);
CORTO_IC_EXPORT void ic_opSet(ic_op _this, cx_uint32 line, ic_opKind kind_1, ic_node s1, ic_node s2, ic_node s3, ic_derefKind s1Deref, ic_derefKind s2Deref, ic_derefKind s3Deref, cx_bool s1Any);
CORTO_IC_EXPORT cx_string ic_opStr(ic_op value);
CORTO_IC_EXPORT ic_op ic_opFromStr(ic_op value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_opCopy(ic_op *dst, ic_op src);
CORTO_IC_EXPORT cx_int16 ic_opCompare(ic_op dst, ic_op src);

/* ::corto::ic::opKind */
CORTO_IC_EXPORT ic_opKind* ic_opKindCreate(ic_opKind value);
CORTO_IC_EXPORT ic_opKind* ic_opKindCreateChild(cx_object _parent, cx_string _name, ic_opKind value);

CORTO_IC_EXPORT ic_opKind* ic_opKindDeclare(void);
CORTO_IC_EXPORT ic_opKind* ic_opKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_opKindDefine(ic_opKind* _this, ic_opKind value);
CORTO_IC_EXPORT void ic_opKindUpdate(ic_opKind* _this, ic_opKind value);
CORTO_IC_EXPORT void ic_opKindSet(ic_opKind* _this, ic_opKind value);
CORTO_IC_EXPORT cx_string ic_opKindStr(ic_opKind value);
CORTO_IC_EXPORT ic_opKind* ic_opKindFromStr(ic_opKind* value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_opKindCopy(ic_opKind* *dst, ic_opKind* src);
CORTO_IC_EXPORT cx_int16 ic_opKindCompare(ic_opKind* dst, ic_opKind* src);

CORTO_IC_EXPORT cx_int16 ic_opKindInit(ic_opKind* value);
CORTO_IC_EXPORT cx_int16 ic_opKindDeinit(ic_opKind* value);

/* ::corto::ic::program */
CORTO_IC_EXPORT ic_program ic_programCreate(cx_string filename);
CORTO_IC_EXPORT ic_program ic_programCreateChild(cx_object _parent, cx_string _name, cx_string filename);

CORTO_IC_EXPORT ic_program ic_programDeclare(void);
CORTO_IC_EXPORT ic_program ic_programDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_programDefine(ic_program _this, cx_string filename);
CORTO_IC_EXPORT void ic_programUpdate(ic_program _this, cx_string filename);
CORTO_IC_EXPORT void ic_programSet(ic_program _this, cx_string filename);
CORTO_IC_EXPORT cx_string ic_programStr(ic_program value);
CORTO_IC_EXPORT ic_program ic_programFromStr(ic_program value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_programCopy(ic_program *dst, ic_program src);
CORTO_IC_EXPORT cx_int16 ic_programCompare(ic_program dst, ic_program src);

/* ::corto::ic::scope */
CORTO_IC_EXPORT ic_scope ic_scopeCreate(ic_scope parent, cx_bool isFunction);
CORTO_IC_EXPORT ic_scope ic_scopeCreateChild(cx_object _parent, cx_string _name, ic_scope parent, cx_bool isFunction);

CORTO_IC_EXPORT ic_scope ic_scopeDeclare(void);
CORTO_IC_EXPORT ic_scope ic_scopeDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_scopeDefine(ic_scope _this, ic_scope parent, cx_bool isFunction);
CORTO_IC_EXPORT void ic_scopeUpdate(ic_scope _this, ic_scope parent, cx_bool isFunction);
CORTO_IC_EXPORT void ic_scopeSet(ic_scope _this, ic_scope parent, cx_bool isFunction);
CORTO_IC_EXPORT cx_string ic_scopeStr(ic_scope value);
CORTO_IC_EXPORT ic_scope ic_scopeFromStr(ic_scope value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_scopeCopy(ic_scope *dst, ic_scope src);
CORTO_IC_EXPORT cx_int16 ic_scopeCompare(ic_scope dst, ic_scope src);

/* ::corto::ic::storage */
CORTO_IC_EXPORT ic_storage ic_storageCreate(cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT ic_storage ic_storageCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);

CORTO_IC_EXPORT ic_storage ic_storageDeclare(void);
CORTO_IC_EXPORT ic_storage ic_storageDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_storageDefine(ic_storage _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT void ic_storageUpdate(ic_storage _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT void ic_storageSet(ic_storage _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn);
CORTO_IC_EXPORT cx_string ic_storageStr(ic_storage value);
CORTO_IC_EXPORT ic_storage ic_storageFromStr(ic_storage value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_storageCopy(ic_storage *dst, ic_storage src);
CORTO_IC_EXPORT cx_int16 ic_storageCompare(ic_storage dst, ic_storage src);

/* ::corto::ic::storageKind */
CORTO_IC_EXPORT ic_storageKind* ic_storageKindCreate(ic_storageKind value);
CORTO_IC_EXPORT ic_storageKind* ic_storageKindCreateChild(cx_object _parent, cx_string _name, ic_storageKind value);

CORTO_IC_EXPORT ic_storageKind* ic_storageKindDeclare(void);
CORTO_IC_EXPORT ic_storageKind* ic_storageKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_storageKindDefine(ic_storageKind* _this, ic_storageKind value);
CORTO_IC_EXPORT void ic_storageKindUpdate(ic_storageKind* _this, ic_storageKind value);
CORTO_IC_EXPORT void ic_storageKindSet(ic_storageKind* _this, ic_storageKind value);
CORTO_IC_EXPORT cx_string ic_storageKindStr(ic_storageKind value);
CORTO_IC_EXPORT ic_storageKind* ic_storageKindFromStr(ic_storageKind* value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_storageKindCopy(ic_storageKind* *dst, ic_storageKind* src);
CORTO_IC_EXPORT cx_int16 ic_storageKindCompare(ic_storageKind* dst, ic_storageKind* src);

CORTO_IC_EXPORT cx_int16 ic_storageKindInit(ic_storageKind* value);
CORTO_IC_EXPORT cx_int16 ic_storageKindDeinit(ic_storageKind* value);

/* ::corto::ic::variable */
CORTO_IC_EXPORT ic_variable ic_variableCreate(cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn, cx_bool isParameter, cx_bool isReturn);
CORTO_IC_EXPORT ic_variable ic_variableCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn, cx_bool isParameter, cx_bool isReturn);

CORTO_IC_EXPORT ic_variable ic_variableDeclare(void);
CORTO_IC_EXPORT ic_variable ic_variableDeclareChild(cx_object _parent, cx_string _name);
CORTO_IC_EXPORT cx_int16 ic_variableDefine(ic_variable _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn, cx_bool isParameter, cx_bool isReturn);
CORTO_IC_EXPORT void ic_variableUpdate(ic_variable _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn, cx_bool isParameter, cx_bool isReturn);
CORTO_IC_EXPORT void ic_variableSet(ic_variable _this, cx_string name, cx_type type, cx_bool isReference, cx_bool holdsReturn, cx_bool isParameter, cx_bool isReturn);
CORTO_IC_EXPORT cx_string ic_variableStr(ic_variable value);
CORTO_IC_EXPORT ic_variable ic_variableFromStr(ic_variable value, cx_string str);
CORTO_IC_EXPORT cx_int16 ic_variableCopy(ic_variable *dst, ic_variable src);
CORTO_IC_EXPORT cx_int16 ic_variableCompare(ic_variable dst, ic_variable src);


/* <0x7fe102c4b658> */
#define ic_labelListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_label elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_labelListInsert(ic_labelList list, ic_label element);
CORTO_IC_EXPORT void ic_labelListAppend(ic_labelList list, ic_label element);
CORTO_IC_EXPORT ic_label ic_labelListTakeFirst(ic_labelList list);
CORTO_IC_EXPORT ic_label ic_labelListLast(ic_labelList list);
CORTO_IC_EXPORT void ic_labelListClear(ic_labelList list);
CORTO_IC_EXPORT ic_label ic_labelListGet(ic_labelList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_labelListSize(ic_labelList list);

/* <0x7fe102c4c4b8> */
#define ic_literalListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_literal elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_literalListInsert(ic_literalList list, ic_literal element);
CORTO_IC_EXPORT void ic_literalListAppend(ic_literalList list, ic_literal element);
CORTO_IC_EXPORT ic_literal ic_literalListTakeFirst(ic_literalList list);
CORTO_IC_EXPORT ic_literal ic_literalListLast(ic_literalList list);
CORTO_IC_EXPORT void ic_literalListClear(ic_literalList list);
CORTO_IC_EXPORT ic_literal ic_literalListGet(ic_literalList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_literalListSize(ic_literalList list);

/* <0x7fe102c48638> */
#define ic_nodeListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_node elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_nodeListInsert(ic_nodeList list, ic_node element);
CORTO_IC_EXPORT void ic_nodeListAppend(ic_nodeList list, ic_node element);
CORTO_IC_EXPORT ic_node ic_nodeListTakeFirst(ic_nodeList list);
CORTO_IC_EXPORT ic_node ic_nodeListLast(ic_nodeList list);
CORTO_IC_EXPORT void ic_nodeListClear(ic_nodeList list);
CORTO_IC_EXPORT ic_node ic_nodeListGet(ic_nodeList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_nodeListSize(ic_nodeList list);

/* <0x7fe102c4cbe8> */
#define ic_opListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_op elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_opListInsert(ic_opList list, ic_op element);
CORTO_IC_EXPORT void ic_opListAppend(ic_opList list, ic_op element);
CORTO_IC_EXPORT ic_op ic_opListTakeFirst(ic_opList list);
CORTO_IC_EXPORT ic_op ic_opListLast(ic_opList list);
CORTO_IC_EXPORT void ic_opListClear(ic_opList list);
CORTO_IC_EXPORT ic_op ic_opListGet(ic_opList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_opListSize(ic_opList list);

/* <0x7fe102c4af28> */
#define ic_scopeListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_scope elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_scopeListInsert(ic_scopeList list, ic_scope element);
CORTO_IC_EXPORT void ic_scopeListAppend(ic_scopeList list, ic_scope element);
CORTO_IC_EXPORT ic_scope ic_scopeListTakeFirst(ic_scopeList list);
CORTO_IC_EXPORT ic_scope ic_scopeListLast(ic_scopeList list);
CORTO_IC_EXPORT void ic_scopeListClear(ic_scopeList list);
CORTO_IC_EXPORT ic_scope ic_scopeListGet(ic_scopeList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_scopeListSize(ic_scopeList list);

/* <0x7fe102c4a6e8> */
#define ic_storageListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ic_storage elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void ic_storageListInsert(ic_storageList list, ic_storage element);
CORTO_IC_EXPORT void ic_storageListAppend(ic_storageList list, ic_storage element);
CORTO_IC_EXPORT ic_storage ic_storageListTakeFirst(ic_storageList list);
CORTO_IC_EXPORT ic_storage ic_storageListLast(ic_storageList list);
CORTO_IC_EXPORT void ic_storageListClear(ic_storageList list);
CORTO_IC_EXPORT ic_storage ic_storageListGet(ic_storageList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 ic_storageListSize(ic_storageList list);

/* <0x7fe102c4bd88> */
#define cx_functionListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    cx_function elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_IC_EXPORT void cx_functionListInsert(cx_functionList list, cx_function element);
CORTO_IC_EXPORT void cx_functionListAppend(cx_functionList list, cx_function element);
CORTO_IC_EXPORT cx_function cx_functionListTakeFirst(cx_functionList list);
CORTO_IC_EXPORT cx_function cx_functionListLast(cx_functionList list);
CORTO_IC_EXPORT void cx_functionListClear(cx_functionList list);
CORTO_IC_EXPORT cx_function cx_functionListGet(cx_functionList list, cx_uint32 index);
CORTO_IC_EXPORT cx_uint32 cx_functionListSize(cx_functionList list);

/* <0x7fe102c515e8> */
#define cx_stringSeqForeach(seq, elem) \
    cx_uint32 elem##_iter;\
    cx_string elem;\
    for(elem##_iter=0; seq.buffer ? elem = seq.buffer[elem##_iter] : elem, elem##_iter<seq.length; elem##_iter++)\

CORTO_IC_EXPORT cx_string* cx_stringSeqAppend(cx_stringSeq *seq);
CORTO_IC_EXPORT void cx_stringSeqSize(cx_stringSeq *seq, cx_uint32 length);
CORTO_IC_EXPORT void cx_stringSeqClear(cx_stringSeq *seq);

#ifdef __cplusplus
}
#endif
#endif

