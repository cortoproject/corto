/* ic_label.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_LABEL_H
#define CORTO_IC_LABEL_H

#include "corto.h"
#include "ic_node.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::label::construct() */
CORTO_IC_EXPORT cx_int16 _ic_label_construct(ic_label _this);
#define ic_label_construct(_this) _ic_label_construct(ic_label(_this))

/* ::corto::ic::label::str(string in) */
CORTO_IC_EXPORT cx_string _ic_label_str(ic_label _this, cx_string in);
#define ic_label_str(_this, in) _ic_label_str(ic_label(_this), in)

#ifdef __cplusplus
}
#endif
#endif

