/* ic_variable.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_VARIABLE_H
#define CORTO_IC_VARIABLE_H

#include "corto.h"
#include "ic_storage.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::variable::construct() */
CORTO_IC_EXPORT cx_int16 _ic_variable_construct(ic_variable _this);
#define ic_variable_construct(_this) _ic_variable_construct(ic_variable(_this))

#ifdef __cplusplus
}
#endif
#endif

