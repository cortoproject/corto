/* ic_node.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_NODE_H
#define CORTO_IC_NODE_H

#include "corto.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::node::construct() */
CORTO_IC_EXPORT cx_int16 _ic_node_construct(ic_node _this);
#define ic_node_construct(_this) _ic_node_construct(ic_node(_this))

/* virtual ::corto::ic::node::str(string in) */
CORTO_IC_EXPORT cx_string _ic_node_str(ic_node _this, cx_string in);
#define ic_node_str(_this, in) _ic_node_str(ic_node(_this), in)

/* ::corto::ic::node::str(string in) */
CORTO_IC_EXPORT cx_string _ic_node_str_v(ic_node _this, cx_string in);
#define ic_node_str_v(_this, in) _ic_node_str_v(ic_node(_this), in)

#ifdef __cplusplus
}
#endif
#endif

