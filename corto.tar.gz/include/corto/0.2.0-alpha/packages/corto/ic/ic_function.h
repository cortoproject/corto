/* ic_function.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_FUNCTION_H
#define CORTO_IC_FUNCTION_H

#include "corto.h"
#include "ic_node.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::function::construct() */
CORTO_IC_EXPORT cx_int16 _ic_function_construct(ic_function _this);
#define ic_function_construct(_this) _ic_function_construct(ic_function(_this))

/* ::corto::ic::function::str(string in) */
CORTO_IC_EXPORT cx_string _ic_function_str(ic_function _this, cx_string in);
#define ic_function_str(_this, in) _ic_function_str(ic_function(_this), in)

#ifdef __cplusplus
}
#endif
#endif

