/* ic_storage.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_STORAGE_H
#define CORTO_IC_STORAGE_H

#include "corto.h"
#include "ic_node.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::storage::construct() */
CORTO_IC_EXPORT cx_int16 _ic_storage_construct(ic_storage _this);
#define ic_storage_construct(_this) _ic_storage_construct(ic_storage(_this))

/* ::corto::ic::storage::free() */
CORTO_IC_EXPORT cx_void _ic_storage_free(ic_storage _this);
#define ic_storage_free(_this) _ic_storage_free(ic_storage(_this))

/* ::corto::ic::storage::str(string in) */
CORTO_IC_EXPORT cx_string _ic_storage_str(ic_storage _this, cx_string in);
#define ic_storage_str(_this, in) _ic_storage_str(ic_storage(_this), in)

#ifdef __cplusplus
}
#endif
#endif

