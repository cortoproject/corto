/* ic__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_IC
#include "ic__type.h"
#include "ic__api.h"
#include "ic__meta.h"
#else
#include "corto/ic/ic__type.h"
#include "corto/ic/ic__api.h"
#include "corto/ic/ic__meta.h"
#endif

#if BUILDING_CORTO_IC && defined _MSC_VER
#define CORTO_IC_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_IC
#define CORTO_IC_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_IC_EXPORT __declspec(dllimport)
#else
#define CORTO_IC_EXPORT
#endif

