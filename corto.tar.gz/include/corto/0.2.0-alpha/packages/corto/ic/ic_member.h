/* ic_member.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_MEMBER_H
#define CORTO_IC_MEMBER_H

#include "corto.h"
#include "ic_storage.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::member::construct() */
CORTO_IC_EXPORT cx_int16 _ic_member_construct(ic_member _this);
#define ic_member_construct(_this) _ic_member_construct(ic_member(_this))

#ifdef __cplusplus
}
#endif
#endif

