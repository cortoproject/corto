/* ic_object.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IC_OBJECT_H
#define CORTO_IC_OBJECT_H

#include "corto.h"
#include "ic_storage.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ic::object::construct() */
CORTO_IC_EXPORT cx_int16 _ic_object_construct(ic_object _this);
#define ic_object_construct(_this) _ic_object_construct(ic_object(_this))

#ifdef __cplusplus
}
#endif
#endif

