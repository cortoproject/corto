/* ic__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_ic_META_H
#define corto_ic_META_H

#include "corto.h"
#include "ic__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_IC_EXPORT extern cx_package _o;
extern cx_package ic_o;
CORTO_IC_EXPORT extern cx_class ic_accumulator_o;
CORTO_IC_EXPORT extern cx_method ic_accumulator_construct_o;
CORTO_IC_EXPORT extern cx_class ic_address_o;
CORTO_IC_EXPORT extern cx_method ic_address_construct_o;
CORTO_IC_EXPORT extern cx_member ic_address_value_o;
CORTO_IC_EXPORT extern cx_enum ic_derefKind_o;
CORTO_IC_EXPORT extern cx_constant ___ (*ic_derefKind_DEREF_ADDRESS_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_derefKind_DEREF_VALUE_o);
CORTO_IC_EXPORT extern cx_class ic_element_o;
CORTO_IC_EXPORT extern cx_member ic_element_base_o;
CORTO_IC_EXPORT extern cx_method ic_element_construct_o;
CORTO_IC_EXPORT extern cx_member ic_element_index_o;
CORTO_IC_EXPORT extern cx_member ic_element_variableIndex_o;
CORTO_IC_EXPORT extern cx_class ic_function_o;
CORTO_IC_EXPORT extern cx_method ic_function_construct_o;
CORTO_IC_EXPORT extern cx_member ic_function_function_o;
CORTO_IC_EXPORT extern cx_method ic_function_str_o;
CORTO_IC_EXPORT extern cx_enum ic_kind_o;
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_ADDRESS_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_FUNCTION_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_LABEL_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_LITERAL_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_OP_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_SCOPE_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_kind_STORAGE_o);
CORTO_IC_EXPORT extern cx_class ic_label_o;
CORTO_IC_EXPORT extern cx_method ic_label_construct_o;
CORTO_IC_EXPORT extern cx_member ic_label_id_o;
CORTO_IC_EXPORT extern cx_method ic_label_str_o;
CORTO_IC_EXPORT extern cx_class ic_literal_o;
CORTO_IC_EXPORT extern cx_method ic_literal_construct_o;
CORTO_IC_EXPORT extern cx_method ic_literal_str_o;
CORTO_IC_EXPORT extern cx_member ic_literal_value_o;
CORTO_IC_EXPORT extern cx_class ic_member_o;
CORTO_IC_EXPORT extern cx_member ic_member_base_o;
CORTO_IC_EXPORT extern cx_method ic_member_construct_o;
CORTO_IC_EXPORT extern cx_member ic_member_member_o;
CORTO_IC_EXPORT extern cx_class ic_node_o;
CORTO_IC_EXPORT extern cx_method ic_node_construct_o;
CORTO_IC_EXPORT extern cx_member ic_node_kind_o;
CORTO_IC_EXPORT extern cx_virtual ic_node_str_o;
CORTO_IC_EXPORT extern cx_class ic_object_o;
CORTO_IC_EXPORT extern cx_method ic_object_construct_o;
CORTO_IC_EXPORT extern cx_member ic_object_ptr_o;
CORTO_IC_EXPORT extern cx_class ic_op_o;
CORTO_IC_EXPORT extern cx_method ic_op_construct_o;
CORTO_IC_EXPORT extern cx_member ic_op_kind_o;
CORTO_IC_EXPORT extern cx_member ic_op_line_o;
CORTO_IC_EXPORT extern cx_member ic_op_s1_o;
CORTO_IC_EXPORT extern cx_member ic_op_s1Any_o;
CORTO_IC_EXPORT extern cx_member ic_op_s1Deref_o;
CORTO_IC_EXPORT extern cx_member ic_op_s2_o;
CORTO_IC_EXPORT extern cx_member ic_op_s2Deref_o;
CORTO_IC_EXPORT extern cx_member ic_op_s3_o;
CORTO_IC_EXPORT extern cx_member ic_op_s3Deref_o;
CORTO_IC_EXPORT extern cx_method ic_op_str_o;
CORTO_IC_EXPORT extern cx_method ic_op_validate_o;
CORTO_IC_EXPORT extern cx_enum ic_opKind_o;
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_add_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_and_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_call_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cast_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_and_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_eq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_gt_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_gteq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_lt_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_lteq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_neq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_not_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_cond_or_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_dec_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_define_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_deinit_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_div_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_free_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_inc_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_init_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_jeq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_jneq_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_jump_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_keep_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_mod_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_mul_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_new_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_not_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_or_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_push_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_ret_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_set_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_shift_left_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_shift_right_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_stop_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_strcat_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_strcpy_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_sub_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_update_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_updatebegin_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_updatecancel_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_updateend_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_wait_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_waitfor_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_opKind_xor_o);
CORTO_IC_EXPORT extern cx_function ic_opKindFromOperator_o;
CORTO_IC_EXPORT extern cx_class ic_program_o;
CORTO_IC_EXPORT extern cx_member ic_program_accumulatorSp_o;
CORTO_IC_EXPORT extern cx_member ic_program_accumulatorStack_o;
CORTO_IC_EXPORT extern cx_method ic_program_add_o;
CORTO_IC_EXPORT extern cx_method ic_program_assemble_o;
CORTO_IC_EXPORT extern cx_member ic_program_autoAccId_o;
CORTO_IC_EXPORT extern cx_method ic_program_construct_o;
CORTO_IC_EXPORT extern cx_method ic_program_declareVariable_o;
CORTO_IC_EXPORT extern cx_member ic_program_errors_o;
CORTO_IC_EXPORT extern cx_member ic_program_filename_o;
CORTO_IC_EXPORT extern cx_member ic_program_functions_o;
CORTO_IC_EXPORT extern cx_function ic_program_get_o;
CORTO_IC_EXPORT extern cx_method ic_program_getAccId_o;
CORTO_IC_EXPORT extern cx_method ic_program_getElement_o;
CORTO_IC_EXPORT extern cx_method ic_program_getLabel_o;
CORTO_IC_EXPORT extern cx_method ic_program_getMember_o;
CORTO_IC_EXPORT extern cx_method ic_program_getObject_o;
CORTO_IC_EXPORT extern cx_method ic_program_getVariable_o;
CORTO_IC_EXPORT extern cx_member ic_program_labelCount_o;
CORTO_IC_EXPORT extern cx_member ic_program_labels_o;
CORTO_IC_EXPORT extern cx_member ic_program_literals_o;
CORTO_IC_EXPORT extern cx_member ic_program_ops_o;
CORTO_IC_EXPORT extern cx_method ic_program_popAccumulator_o;
CORTO_IC_EXPORT extern cx_method ic_program_popScope_o;
CORTO_IC_EXPORT extern cx_method ic_program_pushAccumulator_o;
CORTO_IC_EXPORT extern cx_method ic_program_pushFunction_o;
CORTO_IC_EXPORT extern cx_method ic_program_pushScope_o;
CORTO_IC_EXPORT extern cx_method ic_program_run_o;
CORTO_IC_EXPORT extern cx_member ic_program_scope_o;
CORTO_IC_EXPORT extern cx_member ic_program_scopes_o;
CORTO_IC_EXPORT extern cx_member ic_program_storages_o;
CORTO_IC_EXPORT extern cx_method ic_program_str_o;
CORTO_IC_EXPORT extern cx_member ic_program_vmprogram_o;
CORTO_IC_EXPORT extern cx_class ic_scope_o;
CORTO_IC_EXPORT extern cx_method ic_scope_add_o;
CORTO_IC_EXPORT extern cx_method ic_scope_addStorage_o;
CORTO_IC_EXPORT extern cx_method ic_scope_construct_o;
CORTO_IC_EXPORT extern cx_member ic_scope_isFunction_o;
CORTO_IC_EXPORT extern cx_method ic_scope_lookupStorage_o;
CORTO_IC_EXPORT extern cx_member ic_scope_parent_o;
CORTO_IC_EXPORT extern cx_member ic_scope_program_o;
CORTO_IC_EXPORT extern cx_member ic_scope_storages_o;
CORTO_IC_EXPORT extern cx_method ic_scope_str_o;
CORTO_IC_EXPORT extern cx_class ic_storage_o;
CORTO_IC_EXPORT extern cx_member ic_storage_base_o;
CORTO_IC_EXPORT extern cx_method ic_storage_construct_o;
CORTO_IC_EXPORT extern cx_method ic_storage_free_o;
CORTO_IC_EXPORT extern cx_member ic_storage_holdsReturn_o;
CORTO_IC_EXPORT extern cx_member ic_storage_isReference_o;
CORTO_IC_EXPORT extern cx_member ic_storage_kind_o;
CORTO_IC_EXPORT extern cx_member ic_storage_name_o;
CORTO_IC_EXPORT extern cx_member ic_storage_scope_o;
CORTO_IC_EXPORT extern cx_method ic_storage_str_o;
CORTO_IC_EXPORT extern cx_member ic_storage_type_o;
CORTO_IC_EXPORT extern cx_member ic_storage_used_o;
CORTO_IC_EXPORT extern cx_enum ic_storageKind_o;
CORTO_IC_EXPORT extern cx_constant ___ (*ic_storageKind_ACCUMULATOR_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_storageKind_ELEMENT_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_storageKind_MEMBER_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_storageKind_OBJECT_o);
CORTO_IC_EXPORT extern cx_constant ___ (*ic_storageKind_VARIABLE_o);
CORTO_IC_EXPORT extern cx_class ic_variable_o;
CORTO_IC_EXPORT extern cx_method ic_variable_construct_o;
CORTO_IC_EXPORT extern cx_member ic_variable_isParameter_o;
CORTO_IC_EXPORT extern cx_member ic_variable_isReturn_o;

#ifdef __cplusplus
}
#endif
#endif

