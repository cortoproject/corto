/* math__type.h
 *
 * Type definitions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_math__type_H
#define corto_math__type_H

#include "corto.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Casting macro's for classes */

/* Type definitions */
#ifdef __cplusplus
}
#endif
#endif

