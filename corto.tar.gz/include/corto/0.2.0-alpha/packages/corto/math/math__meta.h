/* math__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_math_META_H
#define corto_math_META_H

#include "corto.h"
#include "math__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_MATH_EXPORT extern cx_package _o;
extern cx_package mth_o;
CORTO_MATH_EXPORT extern cx_function mth_abs_o;
CORTO_MATH_EXPORT extern cx_function mth_acos_o;
CORTO_MATH_EXPORT extern cx_function mth_asin_o;
CORTO_MATH_EXPORT extern cx_function mth_atan_o;
CORTO_MATH_EXPORT extern cx_function mth_cos_o;
CORTO_MATH_EXPORT extern cx_function mth_exp_o;
CORTO_MATH_EXPORT extern cx_function mth_log_o;
CORTO_MATH_EXPORT extern cx_function mth_log10_o;
CORTO_MATH_EXPORT extern cx_function mth_pow_o;
CORTO_MATH_EXPORT extern cx_function mth_rand_o;
CORTO_MATH_EXPORT extern cx_function mth_seed_o;
CORTO_MATH_EXPORT extern cx_function mth_sin_o;
CORTO_MATH_EXPORT extern cx_function mth_sqrt_o;
CORTO_MATH_EXPORT extern cx_function mth_tan_o;

#ifdef __cplusplus
}
#endif
#endif

