/* math__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_MATH
#include "math__type.h"
#include "math__api.h"
#include "math__meta.h"
#else
#include "corto/math/math__type.h"
#include "corto/math/math__api.h"
#include "corto/math/math__meta.h"
#endif

#if BUILDING_CORTO_MATH && defined _MSC_VER
#define CORTO_MATH_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_MATH
#define CORTO_MATH_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_MATH_EXPORT __declspec(dllimport)
#else
#define CORTO_MATH_EXPORT
#endif

