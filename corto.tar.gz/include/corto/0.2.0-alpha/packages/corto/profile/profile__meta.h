/* profile__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_profile_META_H
#define corto_profile_META_H

#include "corto.h"
#include "profile__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_PROFILE_EXPORT extern cx_package _o;
extern cx_package profile_o;
CORTO_PROFILE_EXPORT extern cx_struct profile_Profile_o;
CORTO_PROFILE_EXPORT extern cx_member profile_Profile_callCount_o;
CORTO_PROFILE_EXPORT extern cx_member profile_Profile_nanoseconds_o;
CORTO_PROFILE_EXPORT extern cx_member profile_Profile_seconds_o;
CORTO_PROFILE_EXPORT extern cx_function profile_start_o;
CORTO_PROFILE_EXPORT extern cx_function profile_stop_o;

#ifdef __cplusplus
}
#endif
#endif

