/* profile_Profile.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_PROFILE_PROFILE_H
#define CORTO_PROFILE_PROFILE_H

#include "corto.h"
#include "profile__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

