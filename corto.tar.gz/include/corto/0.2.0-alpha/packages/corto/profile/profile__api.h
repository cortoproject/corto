/* profile__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_profile__API_H
#define corto_profile__API_H

#include "corto.h"
#include "profile__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::profile::Profile */
CORTO_PROFILE_EXPORT profile_Profile* profile_ProfileCreate(cx_uint64 seconds, cx_uint64 nanoseconds, cx_uint64 callCount);
CORTO_PROFILE_EXPORT profile_Profile* profile_ProfileCreateChild(cx_object _parent, cx_string _name, cx_uint64 seconds, cx_uint64 nanoseconds, cx_uint64 callCount);

CORTO_PROFILE_EXPORT profile_Profile* profile_ProfileDeclare(void);
CORTO_PROFILE_EXPORT profile_Profile* profile_ProfileDeclareChild(cx_object _parent, cx_string _name);
CORTO_PROFILE_EXPORT cx_int16 profile_ProfileDefine(profile_Profile* _this, cx_uint64 seconds, cx_uint64 nanoseconds, cx_uint64 callCount);
CORTO_PROFILE_EXPORT void profile_ProfileUpdate(profile_Profile* _this, cx_uint64 seconds, cx_uint64 nanoseconds, cx_uint64 callCount);
CORTO_PROFILE_EXPORT void profile_ProfileSet(profile_Profile* _this, cx_uint64 seconds, cx_uint64 nanoseconds, cx_uint64 callCount);
CORTO_PROFILE_EXPORT cx_string profile_ProfileStr(profile_Profile* value);
CORTO_PROFILE_EXPORT profile_Profile* profile_ProfileFromStr(profile_Profile* value, cx_string str);
CORTO_PROFILE_EXPORT cx_int16 profile_ProfileCopy(profile_Profile* *dst, profile_Profile* src);
CORTO_PROFILE_EXPORT cx_int16 profile_ProfileCompare(profile_Profile* dst, profile_Profile* src);

CORTO_PROFILE_EXPORT cx_int16 profile_ProfileInit(profile_Profile* value);
CORTO_PROFILE_EXPORT cx_int16 profile_ProfileDeinit(profile_Profile* value);


#ifdef __cplusplus
}
#endif
#endif

