/* profile__type.h
 *
 * Type definitions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_profile__type_H
#define corto_profile__type_H

#include "corto.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Casting macro's for classes */
#define profile_Profile(o) ((profile_Profile *)cx_assertType((cx_type)profile_Profile_o, o))

/* Type definitions */
/*  ::corto::profile::Profile */
typedef struct profile_Profile profile_Profile;

struct profile_Profile {
    cx_uint64 seconds;
    cx_uint64 nanoseconds;
    cx_uint64 callCount;
};

#ifdef __cplusplus
}
#endif
#endif

