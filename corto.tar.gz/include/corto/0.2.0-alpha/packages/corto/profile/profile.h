/* profile.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_PROFILE_H
#define CORTO_PROFILE_H

#include "corto.h"
#include "profile__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::profile::start(string name) */
CORTO_PROFILE_EXPORT cx_void _profile_start(cx_string name);
#define profile_start(name) _profile_start(name)

/* ::corto::profile::stop() */
CORTO_PROFILE_EXPORT cx_void _profile_stop(void);
#define profile_stop() _profile_stop()

#ifdef __cplusplus
}
#endif
#endif

#include "profile_Profile.h"
