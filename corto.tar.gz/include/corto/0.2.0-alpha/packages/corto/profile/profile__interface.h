/* profile__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_PROFILE
#include "profile__type.h"
#include "profile__api.h"
#include "profile__meta.h"
#else
#include "corto/profile/profile__type.h"
#include "corto/profile/profile__api.h"
#include "corto/profile/profile__meta.h"
#endif

#if BUILDING_CORTO_PROFILE && defined _MSC_VER
#define CORTO_PROFILE_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_PROFILE
#define CORTO_PROFILE_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_PROFILE_EXPORT __declspec(dllimport)
#else
#define CORTO_PROFILE_EXPORT
#endif

