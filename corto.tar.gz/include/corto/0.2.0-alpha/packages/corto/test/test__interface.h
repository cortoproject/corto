/* test__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_TEST
#include "test__type.h"
#include "test__api.h"
#include "test__meta.h"
#else
#include "corto/test/test__type.h"
#include "corto/test/test__api.h"
#include "corto/test/test__meta.h"
#endif

#if BUILDING_CORTO_TEST && defined _MSC_VER
#define CORTO_TEST_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_TEST
#define CORTO_TEST_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_TEST_EXPORT __declspec(dllimport)
#else
#define CORTO_TEST_EXPORT
#endif

