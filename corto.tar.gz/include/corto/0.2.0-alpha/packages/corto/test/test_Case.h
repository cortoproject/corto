/* test_Case.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_TEST_CASE_H
#define CORTO_TEST_CASE_H

#include "corto.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

