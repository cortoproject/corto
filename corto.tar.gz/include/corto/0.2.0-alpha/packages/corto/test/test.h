/* test.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_TEST_H
#define CORTO_TEST_H

#include "corto.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::test::assert(bool condition,string $condition,uint32 $__line) */
CORTO_TEST_EXPORT cx_bool _test_assert(cx_bool condition, cx_string str_condition, cx_uint32 __line);
#define test_assert(condition) _test_assert(condition, #condition, __LINE__)

/* ::corto::test::assertEqual(any a,any b,string $a,string $b,uint32 $__line) */
CORTO_TEST_EXPORT cx_bool _test_assertEqual(cx_any a, cx_any b, cx_string str_a, cx_string str_b, cx_uint32 __line);
#define test_assertEqual(a, b) _test_assertEqual(a, b, #a, #b, __LINE__)

/* ::corto::test::fail(string err) */
CORTO_TEST_EXPORT cx_void _test_fail(cx_string err);
#define test_fail(err) _test_fail(err)

#ifdef __cplusplus
}
#endif
#endif

#include "test_Case.h"
#include "test_Result.h"
#include "test_Runner.h"
#include "test_Suite.h"
#include "test_SuiteData.h"
