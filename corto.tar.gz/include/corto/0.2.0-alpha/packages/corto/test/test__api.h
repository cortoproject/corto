/* test__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_test__API_H
#define corto_test__API_H

#include "corto.h"
#include "test__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::test::Case */
CORTO_TEST_EXPORT test_Case test_CaseCreate(cx_type returnType, cx_bool returnsReference, cx_bool _virtual, void(*_impl)(cx_function f, void *result, void *args));
CORTO_TEST_EXPORT test_Case test_CaseCreateChild(cx_object _parent, cx_string _name, cx_type returnType, cx_bool returnsReference, cx_bool _virtual, void(*_impl)(cx_function f, void *result, void *args));

CORTO_TEST_EXPORT test_Case test_CaseDeclare(void);
CORTO_TEST_EXPORT test_Case test_CaseDeclareChild(cx_object _parent, cx_string _name);
CORTO_TEST_EXPORT cx_int16 test_CaseDefine(test_Case _this, cx_type returnType, cx_bool returnsReference, cx_bool _virtual, void(*_impl)(cx_function f, void *result, void *args));
CORTO_TEST_EXPORT void test_CaseUpdate(test_Case _this, cx_type returnType, cx_bool returnsReference, cx_bool _virtual);
CORTO_TEST_EXPORT void test_CaseSet(test_Case _this, cx_type returnType, cx_bool returnsReference, cx_bool _virtual);
CORTO_TEST_EXPORT cx_string test_CaseStr(test_Case value);
CORTO_TEST_EXPORT test_Case test_CaseFromStr(test_Case value, cx_string str);
CORTO_TEST_EXPORT cx_int16 test_CaseCopy(test_Case *dst, test_Case src);
CORTO_TEST_EXPORT cx_int16 test_CaseCompare(test_Case dst, test_Case src);

/* ::corto::test::Result */
CORTO_TEST_EXPORT test_Result* test_ResultCreate(cx_string errmsg);
CORTO_TEST_EXPORT test_Result* test_ResultCreateChild(cx_object _parent, cx_string _name, cx_string errmsg);

CORTO_TEST_EXPORT test_Result* test_ResultDeclare(void);
CORTO_TEST_EXPORT test_Result* test_ResultDeclareChild(cx_object _parent, cx_string _name);
CORTO_TEST_EXPORT cx_int16 test_ResultDefine(test_Result* _this, cx_string errmsg);
CORTO_TEST_EXPORT void test_ResultUpdate(test_Result* _this, cx_string errmsg);
CORTO_TEST_EXPORT void test_ResultSet(test_Result* _this, cx_string errmsg);
CORTO_TEST_EXPORT cx_string test_ResultStr(test_Result* value);
CORTO_TEST_EXPORT test_Result* test_ResultFromStr(test_Result* value, cx_string str);
CORTO_TEST_EXPORT cx_int16 test_ResultCopy(test_Result* *dst, test_Result* src);
CORTO_TEST_EXPORT cx_int16 test_ResultCompare(test_Result* dst, test_Result* src);

CORTO_TEST_EXPORT cx_int16 test_ResultInit(test_Result* value);
CORTO_TEST_EXPORT cx_int16 test_ResultDeinit(test_Result* value);

/* ::corto::test::Runner */
CORTO_TEST_EXPORT test_Runner test_RunnerCreate(cx_string name, cx_string lib, cx_string testcase);
CORTO_TEST_EXPORT test_Runner test_RunnerCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_string lib, cx_string testcase);

CORTO_TEST_EXPORT test_Runner test_RunnerDeclare(void);
CORTO_TEST_EXPORT test_Runner test_RunnerDeclareChild(cx_object _parent, cx_string _name);
CORTO_TEST_EXPORT cx_int16 test_RunnerDefine(test_Runner _this, cx_string name, cx_string lib, cx_string testcase);
CORTO_TEST_EXPORT void test_RunnerUpdate(test_Runner _this, cx_string name, cx_string lib, cx_string testcase);
CORTO_TEST_EXPORT void test_RunnerSet(test_Runner _this, cx_string name, cx_string lib, cx_string testcase);
CORTO_TEST_EXPORT cx_string test_RunnerStr(test_Runner value);
CORTO_TEST_EXPORT test_Runner test_RunnerFromStr(test_Runner value, cx_string str);
CORTO_TEST_EXPORT cx_int16 test_RunnerCopy(test_Runner *dst, test_Runner src);
CORTO_TEST_EXPORT cx_int16 test_RunnerCompare(test_Runner dst, test_Runner src);

/* ::corto::test::Suite */
CORTO_TEST_EXPORT test_Suite test_SuiteCreate(cx_interface base, cx_modifier baseAccess, cx_interfaceseq implements, cx_type parentType, cx_state parentState, cx_type defaultType, cx_type defaultProcedureType);
CORTO_TEST_EXPORT test_Suite test_SuiteCreateChild(cx_object _parent, cx_string _name, cx_interface base, cx_modifier baseAccess, cx_interfaceseq implements, cx_type parentType, cx_state parentState, cx_type defaultType, cx_type defaultProcedureType);

CORTO_TEST_EXPORT test_Suite test_SuiteDeclare(void);
CORTO_TEST_EXPORT test_Suite test_SuiteDeclareChild(cx_object _parent, cx_string _name);
CORTO_TEST_EXPORT cx_int16 test_SuiteDefine(test_Suite _this, cx_interface base, cx_modifier baseAccess, cx_interfaceseq implements, cx_type parentType, cx_state parentState, cx_type defaultType, cx_type defaultProcedureType);
CORTO_TEST_EXPORT void test_SuiteUpdate(test_Suite _this, cx_interface base, cx_modifier baseAccess, cx_interfaceseq implements, cx_type parentType, cx_state parentState, cx_type defaultType, cx_type defaultProcedureType);
CORTO_TEST_EXPORT void test_SuiteSet(test_Suite _this, cx_interface base, cx_modifier baseAccess, cx_interfaceseq implements, cx_type parentType, cx_state parentState, cx_type defaultType, cx_type defaultProcedureType);
CORTO_TEST_EXPORT cx_string test_SuiteStr(test_Suite value);
CORTO_TEST_EXPORT test_Suite test_SuiteFromStr(test_Suite value, cx_string str);
CORTO_TEST_EXPORT cx_int16 test_SuiteCopy(test_Suite *dst, test_Suite src);
CORTO_TEST_EXPORT cx_int16 test_SuiteCompare(test_Suite dst, test_Suite src);

/* ::corto::test::SuiteData */
CORTO_TEST_EXPORT test_SuiteData test_SuiteDataCreate(test_Case test, cx_uint32 assertCount);
CORTO_TEST_EXPORT test_SuiteData test_SuiteDataCreateChild(cx_object _parent, cx_string _name, test_Case test, cx_uint32 assertCount);

CORTO_TEST_EXPORT test_SuiteData test_SuiteDataDeclare(void);
CORTO_TEST_EXPORT test_SuiteData test_SuiteDataDeclareChild(cx_object _parent, cx_string _name);
CORTO_TEST_EXPORT cx_int16 test_SuiteDataDefine(test_SuiteData _this, test_Case test, cx_uint32 assertCount);
CORTO_TEST_EXPORT void test_SuiteDataUpdate(test_SuiteData _this, test_Case test, cx_uint32 assertCount);
CORTO_TEST_EXPORT void test_SuiteDataSet(test_SuiteData _this, test_Case test, cx_uint32 assertCount);
CORTO_TEST_EXPORT cx_string test_SuiteDataStr(test_SuiteData value);
CORTO_TEST_EXPORT test_SuiteData test_SuiteDataFromStr(test_SuiteData value, cx_string str);
CORTO_TEST_EXPORT cx_int16 test_SuiteDataCopy(test_SuiteData *dst, test_SuiteData src);
CORTO_TEST_EXPORT cx_int16 test_SuiteDataCompare(test_SuiteData dst, test_SuiteData src);


/* <0x7fd9807c5128> */
#define test_CaseListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    test_Case elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_TEST_EXPORT void test_CaseListInsert(test_CaseList list, test_Case element);
CORTO_TEST_EXPORT void test_CaseListAppend(test_CaseList list, test_Case element);
CORTO_TEST_EXPORT test_Case test_CaseListTakeFirst(test_CaseList list);
CORTO_TEST_EXPORT test_Case test_CaseListLast(test_CaseList list);
CORTO_TEST_EXPORT void test_CaseListClear(test_CaseList list);
CORTO_TEST_EXPORT test_Case test_CaseListGet(test_CaseList list, cx_uint32 index);
CORTO_TEST_EXPORT cx_uint32 test_CaseListSize(test_CaseList list);

#ifdef __cplusplus
}
#endif
#endif

