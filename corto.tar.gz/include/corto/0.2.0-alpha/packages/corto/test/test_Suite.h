/* test_Suite.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_TEST_SUITE_H
#define CORTO_TEST_SUITE_H

#include "corto.h"
#include "cx_class.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::test::Suite::construct() */
CORTO_TEST_EXPORT cx_int16 _test_Suite_construct(test_Suite _this);
#define test_Suite_construct(_this) _test_Suite_construct(test_Suite(_this))

#ifdef __cplusplus
}
#endif
#endif

