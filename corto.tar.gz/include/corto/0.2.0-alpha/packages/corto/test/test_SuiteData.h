/* test_SuiteData.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_TEST_SUITEDATA_H
#define CORTO_TEST_SUITEDATA_H

#include "corto.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::test::SuiteData::construct() */
CORTO_TEST_EXPORT cx_int16 _test_SuiteData_construct(test_SuiteData _this);
#define test_SuiteData_construct(_this) _test_SuiteData_construct(test_SuiteData(_this))

/* virtual ::corto::test::SuiteData::setup() */
CORTO_TEST_EXPORT void _test_SuiteData_setup(test_SuiteData _this);
#define test_SuiteData_setup(_this) _test_SuiteData_setup(test_SuiteData(_this))

/* ::corto::test::SuiteData::setup() */
CORTO_TEST_EXPORT cx_void _test_SuiteData_setup_v(test_SuiteData _this);
#define test_SuiteData_setup_v(_this) _test_SuiteData_setup_v(test_SuiteData(_this))

/* virtual ::corto::test::SuiteData::teardown() */
CORTO_TEST_EXPORT void _test_SuiteData_teardown(test_SuiteData _this);
#define test_SuiteData_teardown(_this) _test_SuiteData_teardown(test_SuiteData(_this))

/* ::corto::test::SuiteData::teardown() */
CORTO_TEST_EXPORT cx_void _test_SuiteData_teardown_v(test_SuiteData _this);
#define test_SuiteData_teardown_v(_this) _test_SuiteData_teardown_v(test_SuiteData(_this))

#ifdef __cplusplus
}
#endif
#endif

