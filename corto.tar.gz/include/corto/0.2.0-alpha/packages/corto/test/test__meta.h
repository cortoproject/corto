/* test__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_test_META_H
#define corto_test_META_H

#include "corto.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_TEST_EXPORT extern cx_package _o;
extern cx_package test_o;
CORTO_TEST_EXPORT extern cx_function test_assert_o;
CORTO_TEST_EXPORT extern cx_function test_assertEqual_o;
CORTO_TEST_EXPORT extern cx_procedure test_Case_o;
CORTO_TEST_EXPORT extern cx_function test_fail_o;
CORTO_TEST_EXPORT extern cx_struct test_Result_o;
CORTO_TEST_EXPORT extern cx_member test_Result_errmsg_o;
CORTO_TEST_EXPORT extern cx_member test_Result_success_o;
CORTO_TEST_EXPORT extern cx_class test_Runner_o;
CORTO_TEST_EXPORT extern cx_method test_Runner_construct_o;
CORTO_TEST_EXPORT extern cx_method test_Runner_destruct_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_failures_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_lib_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_name_o;
CORTO_TEST_EXPORT extern cx_observer test_Runner_runTest_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_successes_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_testcase_o;
CORTO_TEST_EXPORT extern cx_member test_Runner_testsRun_o;
CORTO_TEST_EXPORT extern cx_class test_Suite_o;
CORTO_TEST_EXPORT extern cx_method test_Suite_construct_o;
CORTO_TEST_EXPORT extern cx_class test_SuiteData_o;
CORTO_TEST_EXPORT extern cx_member test_SuiteData_assertCount_o;
CORTO_TEST_EXPORT extern cx_method test_SuiteData_construct_o;
CORTO_TEST_EXPORT extern cx_member test_SuiteData_result_o;
CORTO_TEST_EXPORT extern cx_virtual test_SuiteData_setup_o;
CORTO_TEST_EXPORT extern cx_virtual test_SuiteData_teardown_o;
CORTO_TEST_EXPORT extern cx_member test_SuiteData_test_o;

#ifdef __cplusplus
}
#endif
#endif

