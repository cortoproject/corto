/* test__type.h
 *
 * Type definitions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_test__type_H
#define corto_test__type_H

#include "corto.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Casting macro's for classes */
#define test_Case(o) ((test_Case)cx_assertType((cx_type)test_Case_o, o))
#define test_Result(o) ((test_Result *)cx_assertType((cx_type)test_Result_o, o))
#define test_Runner(o) ((test_Runner)cx_assertType((cx_type)test_Runner_o, o))
#define test_Suite(o) ((test_Suite)cx_assertType((cx_type)test_Suite_o, o))
#define test_SuiteData(o) ((test_SuiteData)cx_assertType((cx_type)test_SuiteData_o, o))

/* Type definitions */
/*  ::corto::test::Case */
CX_CLASS(test_Case);

CX_CLASS_DEF(test_Case) {
    CX_EXTEND(cx_method);
};

/*  ::corto::test::Result */
typedef struct test_Result test_Result;

struct test_Result {
    cx_bool success;
    cx_string errmsg;
};

CX_LIST(test_CaseList);

/*  ::corto::test::Runner */
CX_CLASS(test_Runner);

CX_CLASS_DEF(test_Runner) {
    cx_string name;
    cx_string lib;
    cx_string testcase;
    test_CaseList successes;
    test_CaseList failures;
    cx_int32 testsRun;
};

/*  ::corto::test::Suite */
CX_CLASS(test_Suite);

CX_CLASS_DEF(test_Suite) {
    CX_EXTEND(cx_class);
};

/*  ::corto::test::SuiteData */
CX_CLASS(test_SuiteData);

CX_CLASS_DEF(test_SuiteData) {
    test_Case test;
    cx_uint32 assertCount;
    test_Result result;
};

#ifdef __cplusplus
}
#endif
#endif

