/* test_Runner.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_TEST_RUNNER_H
#define CORTO_TEST_RUNNER_H

#include "corto.h"
#include "test__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::test::Runner::construct() */
CORTO_TEST_EXPORT cx_int16 _test_Runner_construct(test_Runner _this);
#define test_Runner_construct(_this) _test_Runner_construct(test_Runner(_this))

/* ::corto::test::Runner::destruct() */
CORTO_TEST_EXPORT cx_void _test_Runner_destruct(test_Runner _this);
#define test_Runner_destruct(_this) _test_Runner_destruct(test_Runner(_this))

/* ::corto::test::Runner::runTest() */
CORTO_TEST_EXPORT cx_void _test_Runner_runTest(test_Runner _this, cx_object observable);
#define test_Runner_runTest(_this, observable) _test_Runner_runTest(test_Runner(_this), observable)

#ifdef __cplusplus
}
#endif
#endif

