/* md__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_md_META_H
#define corto_md_META_H

#include "corto.h"
#include "md__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_MD_EXPORT extern cx_package _o;
extern cx_package md_o;
CORTO_MD_EXPORT extern cx_class md_Doc_o;
CORTO_MD_EXPORT extern cx_member md_Doc_description_o;
CORTO_MD_EXPORT extern cx_member md_Doc_level_o;
CORTO_MD_EXPORT extern cx_member md_Doc_o_o;
CORTO_MD_EXPORT extern cx_member md_Doc_text_o;
CORTO_MD_EXPORT extern cx_function md_parse_o;

#ifdef __cplusplus
}
#endif
#endif

