/* md__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_md__API_H
#define corto_md__API_H

#include "corto.h"
#include "md__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::md::Doc */
CORTO_MD_EXPORT md_Doc md_DocCreate(cx_object o, cx_uint8 level);
CORTO_MD_EXPORT md_Doc md_DocCreateChild(cx_object _parent, cx_string _name, cx_object o, cx_uint8 level);

CORTO_MD_EXPORT md_Doc md_DocDeclare(void);
CORTO_MD_EXPORT md_Doc md_DocDeclareChild(cx_object _parent, cx_string _name);
CORTO_MD_EXPORT cx_int16 md_DocDefine(md_Doc _this, cx_object o, cx_uint8 level);
CORTO_MD_EXPORT void md_DocUpdate(md_Doc _this, cx_object o, cx_uint8 level);
CORTO_MD_EXPORT void md_DocSet(md_Doc _this, cx_object o, cx_uint8 level);
CORTO_MD_EXPORT cx_string md_DocStr(md_Doc value);
CORTO_MD_EXPORT md_Doc md_DocFromStr(md_Doc value, cx_string str);
CORTO_MD_EXPORT cx_int16 md_DocCopy(md_Doc *dst, md_Doc src);
CORTO_MD_EXPORT cx_int16 md_DocCompare(md_Doc dst, md_Doc src);


#ifdef __cplusplus
}
#endif
#endif

