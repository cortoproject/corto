/* md_Doc.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_MD_DOC_H
#define CORTO_MD_DOC_H

#include "corto.h"
#include "md__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

