/* md__type.h
 *
 * Type definitions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_md__type_H
#define corto_md__type_H

#include "corto.h"
#ifdef __cplusplus
extern "C" {
#endif

/* Casting macro's for classes */
#define md_Doc(o) ((md_Doc)cx_assertType((cx_type)md_Doc_o, o))

/* Type definitions */
/*  ::corto::md::Doc */
CX_CLASS(md_Doc);

CX_CLASS_DEF(md_Doc) {
    cx_object o;
    cx_uint8 level;
    cx_string description;
    cx_string text;
};

#ifdef __cplusplus
}
#endif
#endif

