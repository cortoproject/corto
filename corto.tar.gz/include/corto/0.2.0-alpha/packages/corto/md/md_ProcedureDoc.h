/* md_ProcedureDoc.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_MD_PROCEDUREDOC_H
#define CORTO_MD_PROCEDUREDOC_H

#include "corto.h"
#include "md_Doc.h"
#include "md__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

