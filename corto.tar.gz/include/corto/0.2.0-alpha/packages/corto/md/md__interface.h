/* md__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_MD
#include "md__type.h"
#include "md__api.h"
#include "md__meta.h"
#else
#include "corto/md/md__type.h"
#include "corto/md/md__api.h"
#include "corto/md/md__meta.h"
#endif

#if BUILDING_CORTO_MD && defined _MSC_VER
#define CORTO_MD_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_MD
#define CORTO_MD_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_MD_EXPORT __declspec(dllimport)
#else
#define CORTO_MD_EXPORT
#endif

