/* md.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_MD_H
#define CORTO_MD_H

#include "corto.h"
#include "md__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::md::parse(object destination,string text) */
CORTO_MD_EXPORT cx_void _md_parse(cx_object destination, cx_string text);
#define md_parse(destination, text) _md_parse(destination, text)

#ifdef __cplusplus
}
#endif
#endif

#include "md_Doc.h"
