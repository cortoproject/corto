/* os_time.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_OS_TIME_H
#define CORTO_OS_TIME_H

#include "corto.h"
#include "os__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::os::time::add(::corto::os::time t) */
CORTO_OS_EXPORT cx_void _os_time_add(os_time _this, os_time t);
#define os_time_add(_this, t) _os_time_add(os_time(_this), os_time(t))

/* ::corto::os::time::get() */
CORTO_OS_EXPORT cx_void _os_time_get(os_time _this);
#define os_time_get(_this) _os_time_get(os_time(_this))

/* ::corto::os::time::sub(::corto::os::time t) */
CORTO_OS_EXPORT cx_void _os_time_sub(os_time _this, os_time t);
#define os_time_sub(_this, t) _os_time_sub(os_time(_this), os_time(t))

/* ::corto::os::time::toFloat() */
CORTO_OS_EXPORT cx_float64 _os_time_toFloat(os_time _this);
#define os_time_toFloat(_this) _os_time_toFloat(os_time(_this))

#ifdef __cplusplus
}
#endif
#endif

