/* os__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_os_META_H
#define corto_os_META_H

#include "corto.h"
#include "os__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_OS_EXPORT extern cx_package _o;
extern cx_package os_o;
CORTO_OS_EXPORT extern cx_function os_exit_o;
CORTO_OS_EXPORT extern cx_function os_sleep_o;
CORTO_OS_EXPORT extern cx_function os_system_o;
CORTO_OS_EXPORT extern cx_class os_thread_o;
CORTO_OS_EXPORT extern cx_method os_thread_construct_o;
CORTO_OS_EXPORT extern cx_method os_thread_destruct_o;
CORTO_OS_EXPORT extern cx_member os_thread_handle_o;
CORTO_OS_EXPORT extern cx_method os_thread_join_o;
CORTO_OS_EXPORT extern cx_virtual os_thread_run_o;
CORTO_OS_EXPORT extern cx_method os_thread_start_o;
CORTO_OS_EXPORT extern cx_method os_thread_stop_o;
CORTO_OS_EXPORT extern cx_member os_thread_stopping_o;
CORTO_OS_EXPORT extern cx_class os_time_o;
CORTO_OS_EXPORT extern cx_method os_time_add_o;
CORTO_OS_EXPORT extern cx_method os_time_get_o;
CORTO_OS_EXPORT extern cx_member os_time_nanoseconds_o;
CORTO_OS_EXPORT extern cx_member os_time_seconds_o;
CORTO_OS_EXPORT extern cx_method os_time_sub_o;
CORTO_OS_EXPORT extern cx_method os_time_toFloat_o;
CORTO_OS_EXPORT extern cx_class os_timer_o;
CORTO_OS_EXPORT extern cx_member os_timer_nanosec_o;
CORTO_OS_EXPORT extern cx_method os_timer_run_o;
CORTO_OS_EXPORT extern cx_member os_timer_sec_o;
CORTO_OS_EXPORT extern cx_method os_timer_stop_o;

#ifdef __cplusplus
}
#endif
#endif

