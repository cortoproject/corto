/* os__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_OS
#include "os__type.h"
#include "os__api.h"
#include "os__meta.h"
#else
#include "corto/os/os__type.h"
#include "corto/os/os__api.h"
#include "corto/os/os__meta.h"
#endif

#if BUILDING_CORTO_OS && defined _MSC_VER
#define CORTO_OS_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_OS
#define CORTO_OS_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_OS_EXPORT __declspec(dllimport)
#else
#define CORTO_OS_EXPORT
#endif

