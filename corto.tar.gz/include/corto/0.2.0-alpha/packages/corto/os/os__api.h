/* os__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_os__API_H
#define corto_os__API_H

#include "corto.h"
#include "os__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::os::thread */
CORTO_OS_EXPORT os_thread os_threadCreate(void);
CORTO_OS_EXPORT os_thread os_threadCreateChild(cx_object _parent, cx_string _name);

CORTO_OS_EXPORT os_thread os_threadDeclare(void);
CORTO_OS_EXPORT os_thread os_threadDeclareChild(cx_object _parent, cx_string _name);
CORTO_OS_EXPORT cx_int16 os_threadDefine(os_thread _this);
CORTO_OS_EXPORT void os_threadUpdate(os_thread _this);
CORTO_OS_EXPORT void os_threadSet(os_thread _this);
CORTO_OS_EXPORT cx_string os_threadStr(os_thread value);
CORTO_OS_EXPORT os_thread os_threadFromStr(os_thread value, cx_string str);
CORTO_OS_EXPORT cx_int16 os_threadCopy(os_thread *dst, os_thread src);
CORTO_OS_EXPORT cx_int16 os_threadCompare(os_thread dst, os_thread src);

/* ::corto::os::time */
CORTO_OS_EXPORT os_time os_timeCreate(cx_int32 seconds, cx_uint32 nanoseconds);
CORTO_OS_EXPORT os_time os_timeCreateChild(cx_object _parent, cx_string _name, cx_int32 seconds, cx_uint32 nanoseconds);

CORTO_OS_EXPORT os_time os_timeDeclare(void);
CORTO_OS_EXPORT os_time os_timeDeclareChild(cx_object _parent, cx_string _name);
CORTO_OS_EXPORT cx_int16 os_timeDefine(os_time _this, cx_int32 seconds, cx_uint32 nanoseconds);
CORTO_OS_EXPORT void os_timeUpdate(os_time _this, cx_int32 seconds, cx_uint32 nanoseconds);
CORTO_OS_EXPORT void os_timeSet(os_time _this, cx_int32 seconds, cx_uint32 nanoseconds);
CORTO_OS_EXPORT cx_string os_timeStr(os_time value);
CORTO_OS_EXPORT os_time os_timeFromStr(os_time value, cx_string str);
CORTO_OS_EXPORT cx_int16 os_timeCopy(os_time *dst, os_time src);
CORTO_OS_EXPORT cx_int16 os_timeCompare(os_time dst, os_time src);

/* ::corto::os::timer */
CORTO_OS_EXPORT os_timer os_timerCreate(cx_int32 sec, cx_uint32 nanosec);
CORTO_OS_EXPORT os_timer os_timerCreateChild(cx_object _parent, cx_string _name, cx_int32 sec, cx_uint32 nanosec);

CORTO_OS_EXPORT os_timer os_timerDeclare(void);
CORTO_OS_EXPORT os_timer os_timerDeclareChild(cx_object _parent, cx_string _name);
CORTO_OS_EXPORT cx_int16 os_timerDefine(os_timer _this, cx_int32 sec, cx_uint32 nanosec);
CORTO_OS_EXPORT void os_timerUpdate(os_timer _this, cx_int32 sec, cx_uint32 nanosec);
CORTO_OS_EXPORT void os_timerSet(os_timer _this, cx_int32 sec, cx_uint32 nanosec);
CORTO_OS_EXPORT cx_string os_timerStr(os_timer value);
CORTO_OS_EXPORT os_timer os_timerFromStr(os_timer value, cx_string str);
CORTO_OS_EXPORT cx_int16 os_timerCopy(os_timer *dst, os_timer src);
CORTO_OS_EXPORT cx_int16 os_timerCompare(os_timer dst, os_timer src);


#ifdef __cplusplus
}
#endif
#endif

