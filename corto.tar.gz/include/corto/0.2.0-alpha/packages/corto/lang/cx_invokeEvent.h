/* cx_invokeEvent.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_INVOKEEVENT_H
#define CORTO_LANG_INVOKEEVENT_H

#include "corto.h"
#include "cx_event.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* virtual ::corto::lang::invokeEvent::handle() */
CORTO_LANG_EXPORT void _cx_invokeEvent_handle(cx_invokeEvent _this);
#define cx_invokeEvent_handle(_this) _cx_invokeEvent_handle(cx_invokeEvent(_this))

/* ::corto::lang::invokeEvent::handle() */
CORTO_LANG_EXPORT cx_void _cx_invokeEvent_handle_v(cx_invokeEvent _this);
#define cx_invokeEvent_handle_v(_this) _cx_invokeEvent_handle_v(cx_invokeEvent(_this))

#ifdef __cplusplus
}
#endif
#endif

