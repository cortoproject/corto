/* cx_query.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_QUERY_H
#define CORTO_LANG_QUERY_H

#include "corto.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

