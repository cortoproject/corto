/* cx_text.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_TEXT_H
#define CORTO_LANG_TEXT_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::text::init() */
CORTO_LANG_EXPORT cx_int16 _cx_text_init(cx_text _this);
#define cx_text_init(_this) _cx_text_init(cx_text(_this))

#ifdef __cplusplus
}
#endif
#endif

