/* cx__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_LANG
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"
#else
#include "corto/lang/cx__type.h"
#include "corto/lang/cx__api.h"
#include "corto/lang/cx__meta.h"
#endif

#if BUILDING_CORTO_LANG && defined _MSC_VER
#define CORTO_LANG_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_LANG
#define CORTO_LANG_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_LANG_EXPORT __declspec(dllimport)
#else
#define CORTO_LANG_EXPORT
#endif

