/* cx_binary.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_BINARY_H
#define CORTO_LANG_BINARY_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::binary::init() */
CORTO_LANG_EXPORT cx_int16 _cx_binary_init(cx_binary _this);
#define cx_binary_init(_this) _cx_binary_init(cx_binary(_this))

#ifdef __cplusplus
}
#endif
#endif

