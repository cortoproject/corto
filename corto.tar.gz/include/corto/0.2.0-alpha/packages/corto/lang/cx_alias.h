/* cx_alias.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_ALIAS_H
#define CORTO_LANG_ALIAS_H

#include "corto.h"
#include "cx_member.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::alias::construct() */
CORTO_LANG_EXPORT cx_int16 _cx_alias_construct(cx_alias _this);
#define cx_alias_construct(_this) _cx_alias_construct(cx_alias(_this))

/* ::corto::lang::alias::init() */
CORTO_LANG_EXPORT cx_int16 _cx_alias_init(cx_alias _this);
#define cx_alias_init(_this) _cx_alias_init(cx_alias(_this))

#ifdef __cplusplus
}
#endif
#endif

