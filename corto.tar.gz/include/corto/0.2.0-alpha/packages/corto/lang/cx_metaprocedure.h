/* cx_metaprocedure.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_METAPROCEDURE_H
#define CORTO_LANG_METAPROCEDURE_H

#include "corto.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::metaprocedure::bind() */
CORTO_LANG_EXPORT cx_int16 _cx_metaprocedure_bind(cx_metaprocedure _this);
#define cx_metaprocedure_bind(_this) _cx_metaprocedure_bind(cx_metaprocedure(_this))

#ifdef __cplusplus
}
#endif
#endif

