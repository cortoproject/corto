/* cx_boolean.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_BOOLEAN_H
#define CORTO_LANG_BOOLEAN_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::boolean::init() */
CORTO_LANG_EXPORT cx_int16 _cx_boolean_init(cx_boolean _this);
#define cx_boolean_init(_this) _cx_boolean_init(cx_boolean(_this))

#ifdef __cplusplus
}
#endif
#endif

