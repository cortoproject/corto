/* cx_method.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_METHOD_H
#define CORTO_LANG_METHOD_H

#include "corto.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::method::bind() */
CORTO_LANG_EXPORT cx_int16 _cx_method_bind(cx_method _this);
#define cx_method_bind(_this) _cx_method_bind(cx_method(_this))

/* ::corto::lang::method::init() */
CORTO_LANG_EXPORT cx_int16 _cx_method_init(cx_method _this);
#define cx_method_init(_this) _cx_method_init(cx_method(_this))

#ifdef __cplusplus
}
#endif
#endif

