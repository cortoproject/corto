/* cx_member.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_MEMBER_H
#define CORTO_LANG_MEMBER_H

#include "corto.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::member::construct() */
CORTO_LANG_EXPORT cx_int16 _cx_member_construct(cx_member _this);
#define cx_member_construct(_this) _cx_member_construct(cx_member(_this))

/* ::corto::lang::member::init() */
CORTO_LANG_EXPORT cx_int16 _cx_member_init(cx_member _this);
#define cx_member_init(_this) _cx_member_init(cx_member(_this))

#ifdef __cplusplus
}
#endif
#endif

