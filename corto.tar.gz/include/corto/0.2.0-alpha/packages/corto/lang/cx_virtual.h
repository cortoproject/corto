/* cx_virtual.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_VIRTUAL_H
#define CORTO_LANG_VIRTUAL_H

#include "corto.h"
#include "cx__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::virtual::init() */
CORTO_LANG_EXPORT cx_int16 _cx_virtual_init(cx_virtual _this);
#define cx_virtual_init(_this) _cx_virtual_init(cx_virtual(_this))

#ifdef __cplusplus
}
#endif
#endif

