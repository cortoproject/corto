/* ast_Element.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_ELEMENT_H
#define CORTO_AST_ELEMENT_H

#include "corto.h"
#include "ast_Storage.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Element::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Element_construct(ast_Element _this);
#define ast_Element_construct(_this) _ast_Element_construct(ast_Element(_this))

/* virtual ::corto::ast::Element::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Element_toIc(ast_Element _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Element_toIc(_this, program, storage, stored) _ast_Element_toIc(ast_Element(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Element::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Element_toIc_v(ast_Element _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Element_toIc_v(_this, program, storage, stored) _ast_Element_toIc_v(ast_Element(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

