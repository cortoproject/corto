/* ast_PostFix.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_POSTFIX_H
#define CORTO_AST_POSTFIX_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::PostFix::construct() */
CORTO_AST_EXPORT cx_int16 _ast_PostFix_construct(ast_PostFix _this);
#define ast_PostFix_construct(_this) _ast_PostFix_construct(ast_PostFix(_this))

/* virtual ::corto::ast::PostFix::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_PostFix_hasReturnedResource(ast_PostFix _this);
#define ast_PostFix_hasReturnedResource(_this) _ast_PostFix_hasReturnedResource(ast_PostFix(_this))

/* ::corto::ast::PostFix::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_PostFix_hasReturnedResource_v(ast_PostFix _this);
#define ast_PostFix_hasReturnedResource_v(_this) _ast_PostFix_hasReturnedResource_v(ast_PostFix(_this))

/* virtual ::corto::ast::PostFix::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_PostFix_toIc(ast_PostFix _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_PostFix_toIc(_this, program, storage, stored) _ast_PostFix_toIc(ast_PostFix(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::PostFix::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_PostFix_toIc_v(ast_PostFix _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_PostFix_toIc_v(_this, program, storage, stored) _ast_PostFix_toIc_v(ast_PostFix(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

