/* ast_Null.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_NULL_H
#define CORTO_AST_NULL_H

#include "corto.h"
#include "ast_Literal.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Null::init() */
CORTO_AST_EXPORT cx_int16 _ast_Null_init(ast_Null _this);
#define ast_Null_init(_this) _ast_Null_init(ast_Null(_this))

/* ::corto::ast::Null::serialize(type dstType,word dst) */
CORTO_AST_EXPORT cx_int16 _ast_Null_serialize(ast_Null _this, cx_type dstType, cx_word dst);
#define ast_Null_serialize(_this, dstType, dst) _ast_Null_serialize(ast_Null(_this), cx_type(dstType), dst)

/* virtual ::corto::ast::Null::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Null_toIc(ast_Null _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Null_toIc(_this, program, storage, stored) _ast_Null_toIc(ast_Null(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Null::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Null_toIc_v(ast_Null _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Null_toIc_v(_this, program, storage, stored) _ast_Null_toIc_v(ast_Null(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

