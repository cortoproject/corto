/* ast_StaticCall.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_STATICCALL_H
#define CORTO_AST_STATICCALL_H

#include "corto.h"
#include "ast_Call.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::StaticCall::construct() */
CORTO_AST_EXPORT cx_int16 _ast_StaticCall_construct(ast_StaticCall _this);
#define ast_StaticCall_construct(_this) _ast_StaticCall_construct(ast_StaticCall(_this))

#ifdef __cplusplus
}
#endif
#endif

