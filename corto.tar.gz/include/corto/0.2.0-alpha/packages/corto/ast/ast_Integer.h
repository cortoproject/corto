/* ast_Integer.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_INTEGER_H
#define CORTO_AST_INTEGER_H

#include "corto.h"
#include "ast_Literal.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Integer::init() */
CORTO_AST_EXPORT cx_int16 _ast_Integer_init(ast_Integer _this);
#define ast_Integer_init(_this) _ast_Integer_init(ast_Integer(_this))

/* ::corto::ast::Integer::serialize(type dstType,word dst) */
CORTO_AST_EXPORT cx_int16 _ast_Integer_serialize(ast_Integer _this, cx_type dstType, cx_word dst);
#define ast_Integer_serialize(_this, dstType, dst) _ast_Integer_serialize(ast_Integer(_this), cx_type(dstType), dst)

/* virtual ::corto::ast::Integer::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Integer_toIc(ast_Integer _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Integer_toIc(_this, program, storage, stored) _ast_Integer_toIc(ast_Integer(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Integer::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Integer_toIc_v(ast_Integer _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Integer_toIc_v(_this, program, storage, stored) _ast_Integer_toIc_v(ast_Integer(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

