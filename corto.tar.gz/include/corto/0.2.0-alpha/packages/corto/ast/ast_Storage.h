/* ast_Storage.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_STORAGE_H
#define CORTO_AST_STORAGE_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Storage::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Storage_construct(ast_Storage _this);
#define ast_Storage_construct(_this) _ast_Storage_construct(ast_Storage(_this))

#ifdef __cplusplus
}
#endif
#endif

