/* ast_Parser.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_PARSER_H
#define CORTO_AST_PARSER_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Parser::addStatement(ast::Node statement) */
CORTO_AST_EXPORT cx_void _ast_Parser_addStatement(ast_Parser _this, ast_Node statement);
#define ast_Parser_addStatement(_this, statement) _ast_Parser_addStatement(ast_Parser(_this), ast_Node(statement))

/* ::corto::ast::Parser::argumentToString(type type,string id,bool reference) */
CORTO_AST_EXPORT cx_string _ast_Parser_argumentToString(ast_Parser _this, cx_type type, cx_string id, cx_bool reference);
#define ast_Parser_argumentToString(_this, type, id, reference) _ast_Parser_argumentToString(ast_Parser(_this), cx_type(type), id, reference)

/* ::corto::ast::Parser::binaryExpr(ast::Expression lvalues,ast::Expression rvalues,operatorKind operator) */
CORTO_AST_EXPORT ast_Node _ast_Parser_binaryExpr(ast_Parser _this, ast_Expression lvalues, ast_Expression rvalues, cx_operatorKind _operator);
#define ast_Parser_binaryExpr(_this, lvalues, rvalues, _operator) _ast_Parser_binaryExpr(ast_Parser(_this), ast_Expression(lvalues), ast_Expression(rvalues), _operator)

/* ::corto::ast::Parser::bind(ast::Storage function,ast::Block block) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_bind(ast_Parser _this, ast_Storage function, ast_Block block);
#define ast_Parser_bind(_this, function, block) _ast_Parser_bind(ast_Parser(_this), ast_Storage(function), ast_Block(block))

/* ::corto::ast::Parser::bindOneliner(ast::Storage function,ast::Block block,ast::Expression expr) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_bindOneliner(ast_Parser _this, ast_Storage function, ast_Block block, ast_Expression expr);
#define ast_Parser_bindOneliner(_this, function, block, expr) _ast_Parser_bindOneliner(ast_Parser(_this), ast_Storage(function), ast_Block(block), ast_Expression(expr))

/* ::corto::ast::Parser::blockPop() */
CORTO_AST_EXPORT cx_void _ast_Parser_blockPop(ast_Parser _this);
#define ast_Parser_blockPop(_this) _ast_Parser_blockPop(ast_Parser(_this))

/* ::corto::ast::Parser::blockPush(bool presetBlock) */
CORTO_AST_EXPORT ast_Block _ast_Parser_blockPush(ast_Parser _this, cx_bool presetBlock);
#define ast_Parser_blockPush(_this, presetBlock) _ast_Parser_blockPush(ast_Parser(_this), presetBlock)

/* ::corto::ast::Parser::callExpr(ast::Expression function,ast::Expression arguments) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_callExpr(ast_Parser _this, ast_Expression function, ast_Expression arguments);
#define ast_Parser_callExpr(_this, function, arguments) _ast_Parser_callExpr(ast_Parser(_this), ast_Expression(function), ast_Expression(arguments))

/* ::corto::ast::Parser::castExpr(type lvalue,ast::Expression rvalue) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_castExpr(ast_Parser _this, cx_type lvalue, ast_Expression rvalue);
#define ast_Parser_castExpr(_this, lvalue, rvalue) _ast_Parser_castExpr(ast_Parser(_this), cx_type(lvalue), ast_Expression(rvalue))

/* ::corto::ast::Parser::collect(object o) */
CORTO_AST_EXPORT cx_void _ast_Parser_collect(ast_Parser _this, cx_object o);
#define ast_Parser_collect(_this, o) _ast_Parser_collect(ast_Parser(_this), o)

/* ::corto::ast::Parser::collectHeap(word addr) */
CORTO_AST_EXPORT cx_void _ast_Parser_collectHeap(ast_Parser _this, cx_word addr);
#define ast_Parser_collectHeap(_this, addr) _ast_Parser_collectHeap(ast_Parser(_this), addr)

/* ::corto::ast::Parser::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_construct(ast_Parser _this);
#define ast_Parser_construct(_this) _ast_Parser_construct(ast_Parser(_this))

/* ::corto::ast::Parser::declaration(type type,string id,bool isReference) */
CORTO_AST_EXPORT ast_Storage _ast_Parser_declaration(ast_Parser _this, cx_type type, cx_string id, cx_bool isReference);
#define ast_Parser_declaration(_this, type, id, isReference) _ast_Parser_declaration(ast_Parser(_this), cx_type(type), id, isReference)

/* ::corto::ast::Parser::declareFunction(type returnType,string id,type kind,bool returnsReference) */
CORTO_AST_EXPORT ast_Storage _ast_Parser_declareFunction(ast_Parser _this, cx_type returnType, cx_string id, cx_type kind, cx_bool returnsReference);
#define ast_Parser_declareFunction(_this, returnType, id, kind, returnsReference) _ast_Parser_declareFunction(ast_Parser(_this), cx_type(returnType), id, cx_type(kind), returnsReference)

/* ::corto::ast::Parser::declareFunctionParams(Storage function) */
CORTO_AST_EXPORT ast_Block _ast_Parser_declareFunctionParams(ast_Parser _this, ast_Storage function);
#define ast_Parser_declareFunctionParams(_this, function) _ast_Parser_declareFunctionParams(ast_Parser(_this), ast_Storage(function))

/* ::corto::ast::Parser::define() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_define(ast_Parser _this);
#define ast_Parser_define(_this) _ast_Parser_define(ast_Parser(_this))

/* ::corto::ast::Parser::defineScope() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_defineScope(ast_Parser _this);
#define ast_Parser_defineScope(_this) _ast_Parser_defineScope(ast_Parser(_this))

/* ::corto::ast::Parser::defineVariable(Storage object) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_defineVariable(ast_Parser _this, ast_Storage object);
#define ast_Parser_defineVariable(_this, object) _ast_Parser_defineVariable(ast_Parser(_this), ast_Storage(object))

/* ::corto::ast::Parser::destruct() */
CORTO_AST_EXPORT cx_void _ast_Parser_destruct(ast_Parser _this);
#define ast_Parser_destruct(_this) _ast_Parser_destruct(ast_Parser(_this))

/* ::corto::ast::Parser::elementExpr(ast::Expression lvalue,ast::Expression rvalue) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_elementExpr(ast_Parser _this, ast_Expression lvalue, ast_Expression rvalue);
#define ast_Parser_elementExpr(_this, lvalue, rvalue) _ast_Parser_elementExpr(ast_Parser(_this), ast_Expression(lvalue), ast_Expression(rvalue))

/* ::corto::ast::Parser::finalize(ic::program program) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_finalize(ast_Parser _this, ic_program program);
#define ast_Parser_finalize(_this, program) _ast_Parser_finalize(ast_Parser(_this), ic_program(program))

/* ::corto::ast::Parser::foreach(string loopId,ast::Expression collection) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_foreach(ast_Parser _this, cx_string loopId, ast_Expression collection);
#define ast_Parser_foreach(_this, loopId, collection) _ast_Parser_foreach(ast_Parser(_this), loopId, ast_Expression(collection))

/* ::corto::ast::Parser::getComplexType() */
CORTO_AST_EXPORT cx_type _ast_Parser_getComplexType(ast_Parser _this);
#define ast_Parser_getComplexType(_this) _ast_Parser_getComplexType(ast_Parser(_this))

/* ::corto::ast::Parser::getLvalue(bool assignment) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_getLvalue(ast_Parser _this, cx_bool assignment);
#define ast_Parser_getLvalue(_this, assignment) _ast_Parser_getLvalue(ast_Parser(_this), assignment)

/* ::corto::ast::Parser::getLvalueType(bool assignment) */
CORTO_AST_EXPORT cx_type _ast_Parser_getLvalueType(ast_Parser _this, cx_bool assignment);
#define ast_Parser_getLvalueType(_this, assignment) _ast_Parser_getLvalueType(ast_Parser(_this), assignment)

/* ::corto::ast::Parser::ifStatement(ast::Expression condition,ast::Block trueBranch,ast::If falseBranch) */
CORTO_AST_EXPORT ast_Node _ast_Parser_ifStatement(ast_Parser _this, ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);
#define ast_Parser_ifStatement(_this, condition, trueBranch, falseBranch) _ast_Parser_ifStatement(ast_Parser(_this), ast_Expression(condition), ast_Block(trueBranch), ast_If(falseBranch))

/* ::corto::ast::Parser::initDeclareStaged(ast::Expression expr) */
CORTO_AST_EXPORT cx_void _ast_Parser_initDeclareStaged(ast_Parser _this, ast_Expression expr);
#define ast_Parser_initDeclareStaged(_this, expr) _ast_Parser_initDeclareStaged(ast_Parser(_this), ast_Expression(expr))

/* ::corto::ast::Parser::initKeyValuePop() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initKeyValuePop(ast_Parser _this);
#define ast_Parser_initKeyValuePop(_this) _ast_Parser_initKeyValuePop(ast_Parser(_this))

/* ::corto::ast::Parser::initKeyValuePush() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initKeyValuePush(ast_Parser _this);
#define ast_Parser_initKeyValuePush(_this) _ast_Parser_initKeyValuePush(ast_Parser(_this))

/* ::corto::ast::Parser::initKeyValueSet(ast::Expression expr) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initKeyValueSet(ast_Parser _this, ast_Expression expr);
#define ast_Parser_initKeyValueSet(_this, expr) _ast_Parser_initKeyValueSet(ast_Parser(_this), ast_Expression(expr))

/* ::corto::ast::Parser::initMember(string member) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initMember(ast_Parser _this, cx_string member);
#define ast_Parser_initMember(_this, member) _ast_Parser_initMember(ast_Parser(_this), member)

/* ::corto::ast::Parser::initPop() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initPop(ast_Parser _this);
#define ast_Parser_initPop(_this) _ast_Parser_initPop(ast_Parser(_this))

/* ::corto::ast::Parser::initPush() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initPush(ast_Parser _this);
#define ast_Parser_initPush(_this) _ast_Parser_initPush(ast_Parser(_this))

/* ::corto::ast::Parser::initPushExpression() */
CORTO_AST_EXPORT ast_Expression _ast_Parser_initPushExpression(ast_Parser _this);
#define ast_Parser_initPushExpression(_this) _ast_Parser_initPushExpression(ast_Parser(_this))

/* ::corto::ast::Parser::initPushIdentifier(Expression type) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_initPushIdentifier(ast_Parser _this, ast_Expression type);
#define ast_Parser_initPushIdentifier(_this, type) _ast_Parser_initPushIdentifier(ast_Parser(_this), ast_Expression(type))

/* ::corto::ast::Parser::initPushStatic() */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initPushStatic(ast_Parser _this);
#define ast_Parser_initPushStatic(_this) _ast_Parser_initPushStatic(ast_Parser(_this))

/* ::corto::ast::Parser::initStage(string id,bool found) */
CORTO_AST_EXPORT cx_void _ast_Parser_initStage(ast_Parser _this, cx_string id, cx_bool found);
#define ast_Parser_initStage(_this, id, found) _ast_Parser_initStage(ast_Parser(_this), id, found)

/* ::corto::ast::Parser::initValue(Expression expr) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_initValue(ast_Parser _this, ast_Expression expr);
#define ast_Parser_initValue(_this, expr) _ast_Parser_initValue(ast_Parser(_this), ast_Expression(expr))

/* ::corto::ast::Parser::isAbortSet() */
CORTO_AST_EXPORT cx_bool _ast_Parser_isAbortSet(ast_Parser _this);
#define ast_Parser_isAbortSet(_this) _ast_Parser_isAbortSet(ast_Parser(_this))

/* ::corto::ast::Parser::isErrSet() */
CORTO_AST_EXPORT cx_bool _ast_Parser_isErrSet(ast_Parser _this);
#define ast_Parser_isErrSet(_this) _ast_Parser_isErrSet(ast_Parser(_this))

/* ::corto::ast::Parser::lookup(string id) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_lookup(ast_Parser _this, cx_string id);
#define ast_Parser_lookup(_this, id) _ast_Parser_lookup(ast_Parser(_this), id)

/* ::corto::ast::Parser::memberExpr(ast::Expression lvalue,ast::Expression rvalue) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_memberExpr(ast_Parser _this, ast_Expression lvalue, ast_Expression rvalue);
#define ast_Parser_memberExpr(_this, lvalue, rvalue) _ast_Parser_memberExpr(ast_Parser(_this), ast_Expression(lvalue), ast_Expression(rvalue))

/* ::corto::ast::Parser::observerDeclaration(string id,ast::Expression object,eventMask mask,ast::Object dispatcher) */
CORTO_AST_EXPORT ast_Storage _ast_Parser_observerDeclaration(ast_Parser _this, cx_string id, ast_Expression object, cx_eventMask mask, ast_Object dispatcher);
#define ast_Parser_observerDeclaration(_this, id, object, mask, dispatcher) _ast_Parser_observerDeclaration(ast_Parser(_this), id, ast_Expression(object), mask, ast_Object(dispatcher))

/* ::corto::ast::Parser::observerPush() */
CORTO_AST_EXPORT cx_void _ast_Parser_observerPush(ast_Parser _this);
#define ast_Parser_observerPush(_this) _ast_Parser_observerPush(ast_Parser(_this))

/* ::corto::ast::Parser::parse(sequence{string} argv) */
CORTO_AST_EXPORT cx_uint32 _ast_Parser_parse(ast_Parser _this, cx_stringSeq argv);
#define ast_Parser_parse(_this, argv) _ast_Parser_parse(ast_Parser(_this), argv)

/* ::corto::ast::Parser::parseExpression(string expr,ast::Block block,object scope,uint32 line,uint32 column) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_parseExpression(ast_Parser _this, cx_string expr, ast_Block block, cx_object scope, cx_uint32 line, cx_uint32 column);
#define ast_Parser_parseExpression(_this, expr, block, scope, line, column) _ast_Parser_parseExpression(ast_Parser(_this), expr, ast_Block(block), scope, line, column)

/* ::corto::ast::Parser::parseLine(string expr,object scope,word value) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_parseLine(cx_string expr, cx_object scope, cx_word value);
#define ast_Parser_parseLine(expr, scope, value) _ast_Parser_parseLine(expr, scope, value)

/* ::corto::ast::Parser::popComplexType() */
CORTO_AST_EXPORT cx_void _ast_Parser_popComplexType(ast_Parser _this);
#define ast_Parser_popComplexType(_this) _ast_Parser_popComplexType(ast_Parser(_this))

/* ::corto::ast::Parser::popLvalue() */
CORTO_AST_EXPORT cx_void _ast_Parser_popLvalue(ast_Parser _this);
#define ast_Parser_popLvalue(_this) _ast_Parser_popLvalue(ast_Parser(_this))

/* ::corto::ast::Parser::popScope(object previous) */
CORTO_AST_EXPORT cx_void _ast_Parser_popScope(ast_Parser _this, cx_object previous);
#define ast_Parser_popScope(_this, previous) _ast_Parser_popScope(ast_Parser(_this), previous)

/* ::corto::ast::Parser::postfixExpr(ast::Expression lvalue,operatorKind operator) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_postfixExpr(ast_Parser _this, ast_Expression lvalue, cx_operatorKind _operator);
#define ast_Parser_postfixExpr(_this, lvalue, _operator) _ast_Parser_postfixExpr(ast_Parser(_this), ast_Expression(lvalue), _operator)

/* ::corto::ast::Parser::pushComplexType(ast::Expression lvalue) */
CORTO_AST_EXPORT cx_void _ast_Parser_pushComplexType(ast_Parser _this, ast_Expression lvalue);
#define ast_Parser_pushComplexType(_this, lvalue) _ast_Parser_pushComplexType(ast_Parser(_this), ast_Expression(lvalue))

/* ::corto::ast::Parser::pushLvalue(ast::Expression lvalue,bool isAssignment) */
CORTO_AST_EXPORT cx_void _ast_Parser_pushLvalue(ast_Parser _this, ast_Expression lvalue, cx_bool isAssignment);
#define ast_Parser_pushLvalue(_this, lvalue, isAssignment) _ast_Parser_pushLvalue(ast_Parser(_this), ast_Expression(lvalue), isAssignment)

/* ::corto::ast::Parser::pushPackage(string name) */
CORTO_AST_EXPORT cx_int16 _ast_Parser_pushPackage(ast_Parser _this, cx_string name);
#define ast_Parser_pushPackage(_this, name) _ast_Parser_pushPackage(ast_Parser(_this), name)

/* ::corto::ast::Parser::pushReturnAsLvalue(function function) */
CORTO_AST_EXPORT cx_void _ast_Parser_pushReturnAsLvalue(ast_Parser _this, cx_function function);
#define ast_Parser_pushReturnAsLvalue(_this, function) _ast_Parser_pushReturnAsLvalue(ast_Parser(_this), cx_function(function))

/* ::corto::ast::Parser::pushScope() */
CORTO_AST_EXPORT cx_object _ast_Parser_pushScope(ast_Parser _this);
#define ast_Parser_pushScope(_this) _ast_Parser_pushScope(ast_Parser(_this))

/* ::corto::ast::Parser::reset() */
CORTO_AST_EXPORT cx_void _ast_Parser_reset(ast_Parser _this);
#define ast_Parser_reset(_this) _ast_Parser_reset(ast_Parser(_this))

/* ::corto::ast::Parser::ternaryExpr(ast::Expression cond,ast::Expression iftrue,ast::Expression iffalse) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_ternaryExpr(ast_Parser _this, ast_Expression cond, ast_Expression iftrue, ast_Expression iffalse);
#define ast_Parser_ternaryExpr(_this, cond, iftrue, iffalse) _ast_Parser_ternaryExpr(ast_Parser(_this), ast_Expression(cond), ast_Expression(iftrue), ast_Expression(iffalse))

/* ::corto::ast::Parser::unaryExpr(ast::Expression lvalue,operatorKind operator) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_unaryExpr(ast_Parser _this, ast_Expression lvalue, cx_operatorKind _operator);
#define ast_Parser_unaryExpr(_this, lvalue, _operator) _ast_Parser_unaryExpr(ast_Parser(_this), ast_Expression(lvalue), _operator)

/* ::corto::ast::Parser::updateStatement(ast::Expression expr,ast::Block block) */
CORTO_AST_EXPORT ast_Node _ast_Parser_updateStatement(ast_Parser _this, ast_Expression expr, ast_Block block);
#define ast_Parser_updateStatement(_this, expr, block) _ast_Parser_updateStatement(ast_Parser(_this), ast_Expression(expr), ast_Block(block))

/* ::corto::ast::Parser::waitExpr(ast::Expression expr,ast::Expression timeout) */
CORTO_AST_EXPORT ast_Expression _ast_Parser_waitExpr(ast_Parser _this, ast_Expression expr, ast_Expression timeout);
#define ast_Parser_waitExpr(_this, expr, timeout) _ast_Parser_waitExpr(ast_Parser(_this), ast_Expression(expr), ast_Expression(timeout))

/* ::corto::ast::Parser::whileStatement(ast::Expression condition,ast::Block trueBranch,bool isUntil) */
CORTO_AST_EXPORT ast_Node _ast_Parser_whileStatement(ast_Parser _this, ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);
#define ast_Parser_whileStatement(_this, condition, trueBranch, isUntil) _ast_Parser_whileStatement(ast_Parser(_this), ast_Expression(condition), ast_Block(trueBranch), isUntil)

#ifdef __cplusplus
}
#endif
#endif

