/* ast_Init.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_INIT_H
#define CORTO_AST_INIT_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Init::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Init_construct(ast_Init _this);
#define ast_Init_construct(_this) _ast_Init_construct(ast_Init(_this))

/* virtual ::corto::ast::Init::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Init_toIc(ast_Init _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Init_toIc(_this, program, storage, stored) _ast_Init_toIc(ast_Init(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Init::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Init_toIc_v(ast_Init _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Init_toIc_v(_this, program, storage, stored) _ast_Init_toIc_v(ast_Init(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

