/* ast_CallBuilder.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_CALLBUILDER_H
#define CORTO_AST_CALLBUILDER_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::CallBuilder::build() */
CORTO_AST_EXPORT ast_Call _ast_CallBuilder_build(ast_CallBuilder *_this);
#define ast_CallBuilder_build(_this) _ast_CallBuilder_build(_this)

/* ::corto::ast::CallBuilder::buildSignature() */
CORTO_AST_EXPORT cx_int16 _ast_CallBuilder_buildSignature(ast_CallBuilder *_this);
#define ast_CallBuilder_buildSignature(_this) _ast_CallBuilder_buildSignature(_this)

#ifdef __cplusplus
}
#endif
#endif

