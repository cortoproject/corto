/* ast_Temporary.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_TEMPORARY_H
#define CORTO_AST_TEMPORARY_H

#include "corto.h"
#include "ast_Storage.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Temporary::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Temporary_construct(ast_Temporary _this);
#define ast_Temporary_construct(_this) _ast_Temporary_construct(ast_Temporary(_this))

/* ::corto::ast::Temporary::setProxy(Temporary proxy) */
CORTO_AST_EXPORT cx_void _ast_Temporary_setProxy(ast_Temporary _this, ast_Temporary proxy);
#define ast_Temporary_setProxy(_this, proxy) _ast_Temporary_setProxy(ast_Temporary(_this), ast_Temporary(proxy))

/* virtual ::corto::ast::Temporary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Temporary_toIc(ast_Temporary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Temporary_toIc(_this, program, storage, stored) _ast_Temporary_toIc(ast_Temporary(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Temporary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Temporary_toIc_v(ast_Temporary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Temporary_toIc_v(_this, program, storage, stored) _ast_Temporary_toIc_v(ast_Temporary(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

