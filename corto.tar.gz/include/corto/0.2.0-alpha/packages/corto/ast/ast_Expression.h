/* ast_Expression.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_EXPRESSION_H
#define CORTO_AST_EXPRESSION_H

#include "corto.h"
#include "ast_Node.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Expression::cast(type type,bool isReference) */
CORTO_AST_EXPORT ast_Expression _ast_Expression_cast(ast_Expression _this, cx_type type, cx_bool isReference);
#define ast_Expression_cast(_this, type, isReference) _ast_Expression_cast(ast_Expression(_this), cx_type(type), isReference)

/* ::corto::ast::Expression::cleanList(list{Expression} list) */
CORTO_AST_EXPORT cx_void _ast_Expression_cleanList(ast_ExpressionList list);
#define ast_Expression_cleanList(list) _ast_Expression_cleanList(list)

/* virtual ::corto::ast::Expression::fold() */
CORTO_AST_EXPORT ast_Expression _ast_Expression_fold(ast_Expression _this);
#define ast_Expression_fold(_this) _ast_Expression_fold(ast_Expression(_this))

/* ::corto::ast::Expression::fold() */
CORTO_AST_EXPORT ast_Expression _ast_Expression_fold_v(ast_Expression _this);
#define ast_Expression_fold_v(_this) _ast_Expression_fold_v(ast_Expression(_this))

/* ::corto::ast::Expression::fromList(list{Expression} list) */
CORTO_AST_EXPORT ast_Expression _ast_Expression_fromList(ast_ExpressionList list);
#define ast_Expression_fromList(list) _ast_Expression_fromList(list)

/* ::corto::ast::Expression::getType() */
CORTO_AST_EXPORT cx_type _ast_Expression_getType(ast_Expression _this);
#define ast_Expression_getType(_this) _ast_Expression_getType(ast_Expression(_this))

/* ::corto::ast::Expression::getType_expr(Expression target) */
CORTO_AST_EXPORT cx_type _ast_Expression_getType_expr(ast_Expression _this, ast_Expression target);
#define ast_Expression_getType_expr(_this, target) _ast_Expression_getType_expr(ast_Expression(_this), ast_Expression(target))

/* ::corto::ast::Expression::getType_type(type target) */
CORTO_AST_EXPORT cx_type _ast_Expression_getType_type(ast_Expression _this, cx_type target);
#define ast_Expression_getType_type(_this, target) _ast_Expression_getType_type(ast_Expression(_this), cx_type(target))

/* virtual ::corto::ast::Expression::getValue() */
CORTO_AST_EXPORT cx_word _ast_Expression_getValue(ast_Expression _this);
#define ast_Expression_getValue(_this) _ast_Expression_getValue(ast_Expression(_this))

/* ::corto::ast::Expression::getValue() */
CORTO_AST_EXPORT cx_word _ast_Expression_getValue_v(ast_Expression _this);
#define ast_Expression_getValue_v(_this) _ast_Expression_getValue_v(ast_Expression(_this))

/* virtual ::corto::ast::Expression::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Expression_hasReturnedResource(ast_Expression _this);
#define ast_Expression_hasReturnedResource(_this) _ast_Expression_hasReturnedResource(ast_Expression(_this))

/* ::corto::ast::Expression::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Expression_hasReturnedResource_v(ast_Expression _this);
#define ast_Expression_hasReturnedResource_v(_this) _ast_Expression_hasReturnedResource_v(ast_Expression(_this))

/* virtual ::corto::ast::Expression::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Expression_hasSideEffects(ast_Expression _this);
#define ast_Expression_hasSideEffects(_this) _ast_Expression_hasSideEffects(ast_Expression(_this))

/* ::corto::ast::Expression::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Expression_hasSideEffects_v(ast_Expression _this);
#define ast_Expression_hasSideEffects_v(_this) _ast_Expression_hasSideEffects_v(ast_Expression(_this))

/* virtual ::corto::ast::Expression::serialize(type dstType,word dst) */
CORTO_AST_EXPORT cx_int16 _ast_Expression_serialize(ast_Expression _this, cx_type dstType, cx_word dst);
#define ast_Expression_serialize(_this, dstType, dst) _ast_Expression_serialize(ast_Expression(_this), cx_type(dstType), dst)

/* ::corto::ast::Expression::serialize(type dstType,word dst) */
CORTO_AST_EXPORT cx_int16 _ast_Expression_serialize_v(ast_Expression _this, cx_type dstType, cx_word dst);
#define ast_Expression_serialize_v(_this, dstType, dst) _ast_Expression_serialize_v(ast_Expression(_this), cx_type(dstType), dst)

/* virtual ::corto::ast::Expression::toList() */
CORTO_AST_EXPORT ast_ExpressionList _ast_Expression_toList(ast_Expression _this);
#define ast_Expression_toList(_this) _ast_Expression_toList(ast_Expression(_this))

/* ::corto::ast::Expression::toList() */
CORTO_AST_EXPORT ast_ExpressionList _ast_Expression_toList_v(ast_Expression _this);
#define ast_Expression_toList_v(_this) _ast_Expression_toList_v(ast_Expression(_this))

#ifdef __cplusplus
}
#endif
#endif

