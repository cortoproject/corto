/* ast.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_H
#define CORTO_AST_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::isOperatorAssignment(operatorKind operator) */
CORTO_AST_EXPORT cx_bool _ast_isOperatorAssignment(cx_operatorKind _operator);
#define ast_isOperatorAssignment(_operator) _ast_isOperatorAssignment(_operator)

/* ::corto::ast::report(string kind,string filename,uint32 line,uint32 column,string error,string token) */
CORTO_AST_EXPORT cx_void _ast_report(cx_string kind, cx_string filename, cx_uint32 line, cx_uint32 column, cx_string error, cx_string token);
#define ast_report(kind, filename, line, column, error, token) _ast_report(kind, filename, line, column, error, token)

/* ::corto::ast::reportError(string filename,uint32 line,uint32 column,string error,string token) */
CORTO_AST_EXPORT cx_void _ast_reportError(cx_string filename, cx_uint32 line, cx_uint32 column, cx_string error, cx_string token);
#define ast_reportError(filename, line, column, error, token) _ast_reportError(filename, line, column, error, token)

/* ::corto::ast::reportWarning(string filename,uint32 line,uint32 column,string error,string token) */
CORTO_AST_EXPORT cx_void _ast_reportWarning(cx_string filename, cx_uint32 line, cx_uint32 column, cx_string error, cx_string token);
#define ast_reportWarning(filename, line, column, error, token) _ast_reportWarning(filename, line, column, error, token)

/* ::corto::ast::valueKindFromType(type type) */
CORTO_AST_EXPORT ast_valueKind _ast_valueKindFromType(cx_type type);
#define ast_valueKindFromType(type) _ast_valueKindFromType(cx_type(type))

#ifdef __cplusplus
}
#endif
#endif

#include "ast_Binary.h"
#include "ast_Binding.h"
#include "ast_Block.h"
#include "ast_Boolean.h"
#include "ast_Call.h"
#include "ast_CallBuilder.h"
#include "ast_Cast.h"
#include "ast_Character.h"
#include "ast_Comma.h"
#include "ast_Define.h"
#include "ast_Deinit.h"
#include "ast_DelegateCall.h"
#include "ast_DynamicInitializer.h"
#include "ast_DynamicInitializerFrame.h"
#include "ast_Element.h"
#include "ast_Expression.h"
#include "ast_FloatingPoint.h"
#include "ast_If.h"
#include "ast_Init.h"
#include "ast_Initializer.h"
#include "ast_InitializerExpression.h"
#include "ast_InitializerFrame.h"
#include "ast_InitializerVariable.h"
#include "ast_InitOper.h"
#include "ast_Integer.h"
#include "ast_Literal.h"
#include "ast_Local.h"
#include "ast_Lvalue.h"
#include "ast_Member.h"
#include "ast_New.h"
#include "ast_Node.h"
#include "ast_Null.h"
#include "ast_Object.h"
#include "ast_Parser.h"
#include "ast_Parser_stagedId.h"
#include "ast_ParserDeclaration.h"
#include "ast_ParserNew.h"
#include "ast_PostFix.h"
#include "ast_SignedInteger.h"
#include "ast_StaticCall.h"
#include "ast_StaticInitializer.h"
#include "ast_StaticInitializerFrame.h"
#include "ast_Storage.h"
#include "ast_String.h"
#include "ast_Template.h"
#include "ast_Temporary.h"
#include "ast_Ternary.h"
#include "ast_Unary.h"
#include "ast_Update.h"
#include "ast_Wait.h"
#include "ast_While.h"
#include "corto/ic/ic.h"
