/* ast_Ternary.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_TERNARY_H
#define CORTO_AST_TERNARY_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Ternary::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Ternary_construct(ast_Ternary _this);
#define ast_Ternary_construct(_this) _ast_Ternary_construct(ast_Ternary(_this))

/* virtual ::corto::ast::Ternary::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Ternary_hasReturnedResource(ast_Ternary _this);
#define ast_Ternary_hasReturnedResource(_this) _ast_Ternary_hasReturnedResource(ast_Ternary(_this))

/* ::corto::ast::Ternary::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Ternary_hasReturnedResource_v(ast_Ternary _this);
#define ast_Ternary_hasReturnedResource_v(_this) _ast_Ternary_hasReturnedResource_v(ast_Ternary(_this))

/* virtual ::corto::ast::Ternary::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Ternary_hasSideEffects(ast_Ternary _this);
#define ast_Ternary_hasSideEffects(_this) _ast_Ternary_hasSideEffects(ast_Ternary(_this))

/* ::corto::ast::Ternary::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Ternary_hasSideEffects_v(ast_Ternary _this);
#define ast_Ternary_hasSideEffects_v(_this) _ast_Ternary_hasSideEffects_v(ast_Ternary(_this))

/* ::corto::ast::Ternary::setOperator(operatorKind kind) */
CORTO_AST_EXPORT cx_void _ast_Ternary_setOperator(ast_Ternary _this, cx_operatorKind kind);
#define ast_Ternary_setOperator(_this, kind) _ast_Ternary_setOperator(ast_Ternary(_this), kind)

/* virtual ::corto::ast::Ternary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Ternary_toIc(ast_Ternary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Ternary_toIc(_this, program, storage, stored) _ast_Ternary_toIc(ast_Ternary(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Ternary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Ternary_toIc_v(ast_Ternary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Ternary_toIc_v(_this, program, storage, stored) _ast_Ternary_toIc_v(ast_Ternary(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

