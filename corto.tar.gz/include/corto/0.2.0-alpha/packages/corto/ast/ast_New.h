/* ast_New.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_NEW_H
#define CORTO_AST_NEW_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::New::construct() */
CORTO_AST_EXPORT cx_int16 _ast_New_construct(ast_New _this);
#define ast_New_construct(_this) _ast_New_construct(ast_New(_this))

/* virtual ::corto::ast::New::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_New_hasSideEffects(ast_New _this);
#define ast_New_hasSideEffects(_this) _ast_New_hasSideEffects(ast_New(_this))

/* ::corto::ast::New::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_New_hasSideEffects_v(ast_New _this);
#define ast_New_hasSideEffects_v(_this) _ast_New_hasSideEffects_v(ast_New(_this))

/* virtual ::corto::ast::New::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_New_toIc(ast_New _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_New_toIc(_this, program, storage, stored) _ast_New_toIc(ast_New(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::New::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_New_toIc_v(ast_New _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_New_toIc_v(_this, program, storage, stored) _ast_New_toIc_v(ast_New(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

