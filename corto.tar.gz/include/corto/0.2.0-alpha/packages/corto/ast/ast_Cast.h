/* ast_Cast.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_CAST_H
#define CORTO_AST_CAST_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Cast::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Cast_construct(ast_Cast _this);
#define ast_Cast_construct(_this) _ast_Cast_construct(ast_Cast(_this))

/* virtual ::corto::ast::Cast::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Cast_hasReturnedResource(ast_Cast _this);
#define ast_Cast_hasReturnedResource(_this) _ast_Cast_hasReturnedResource(ast_Cast(_this))

/* ::corto::ast::Cast::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Cast_hasReturnedResource_v(ast_Cast _this);
#define ast_Cast_hasReturnedResource_v(_this) _ast_Cast_hasReturnedResource_v(ast_Cast(_this))

/* virtual ::corto::ast::Cast::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Cast_toIc(ast_Cast _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Cast_toIc(_this, program, storage, stored) _ast_Cast_toIc(ast_Cast(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Cast::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Cast_toIc_v(ast_Cast _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Cast_toIc_v(_this, program, storage, stored) _ast_Cast_toIc_v(ast_Cast(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

