/* ast__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_ast__API_H
#define corto_ast__API_H

#include "corto.h"
#include "ast__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::ast::Binary */
CORTO_AST_EXPORT ast_Binary ast_BinaryCreate(ast_Expression lvalue, ast_Expression rvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT ast_Binary ast_BinaryCreateChild(cx_object _parent, cx_string _name, ast_Expression lvalue, ast_Expression rvalue, cx_operatorKind _operator);

CORTO_AST_EXPORT ast_Binary ast_BinaryDeclare(void);
CORTO_AST_EXPORT ast_Binary ast_BinaryDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_BinaryDefine(ast_Binary _this, ast_Expression lvalue, ast_Expression rvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_BinaryUpdate(ast_Binary _this, ast_Expression lvalue, ast_Expression rvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_BinarySet(ast_Binary _this, ast_Expression lvalue, ast_Expression rvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT cx_string ast_BinaryStr(ast_Binary value);
CORTO_AST_EXPORT ast_Binary ast_BinaryFromStr(ast_Binary value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_BinaryCopy(ast_Binary *dst, ast_Binary src);
CORTO_AST_EXPORT cx_int16 ast_BinaryCompare(ast_Binary dst, ast_Binary src);

/* ::corto::ast::Binding */
CORTO_AST_EXPORT ast_Binding* ast_BindingCreate(cx_function function, ast_Block impl);
CORTO_AST_EXPORT ast_Binding* ast_BindingCreateChild(cx_object _parent, cx_string _name, cx_function function, ast_Block impl);

CORTO_AST_EXPORT ast_Binding* ast_BindingDeclare(void);
CORTO_AST_EXPORT ast_Binding* ast_BindingDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_BindingDefine(ast_Binding* _this, cx_function function, ast_Block impl);
CORTO_AST_EXPORT void ast_BindingUpdate(ast_Binding* _this, cx_function function, ast_Block impl);
CORTO_AST_EXPORT void ast_BindingSet(ast_Binding* _this, cx_function function, ast_Block impl);
CORTO_AST_EXPORT cx_string ast_BindingStr(ast_Binding* value);
CORTO_AST_EXPORT ast_Binding* ast_BindingFromStr(ast_Binding* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_BindingCopy(ast_Binding* *dst, ast_Binding* src);
CORTO_AST_EXPORT cx_int16 ast_BindingCompare(ast_Binding* dst, ast_Binding* src);

CORTO_AST_EXPORT cx_int16 ast_BindingInit(ast_Binding* value);
CORTO_AST_EXPORT cx_int16 ast_BindingDeinit(ast_Binding* value);

/* ::corto::ast::Block */
CORTO_AST_EXPORT ast_Block ast_BlockCreate(ast_Block parent);
CORTO_AST_EXPORT ast_Block ast_BlockCreateChild(cx_object _parent, cx_string _name, ast_Block parent);

CORTO_AST_EXPORT ast_Block ast_BlockDeclare(void);
CORTO_AST_EXPORT ast_Block ast_BlockDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_BlockDefine(ast_Block _this, ast_Block parent);
CORTO_AST_EXPORT void ast_BlockUpdate(ast_Block _this, ast_Block parent);
CORTO_AST_EXPORT void ast_BlockSet(ast_Block _this, ast_Block parent);
CORTO_AST_EXPORT cx_string ast_BlockStr(ast_Block value);
CORTO_AST_EXPORT ast_Block ast_BlockFromStr(ast_Block value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_BlockCopy(ast_Block *dst, ast_Block src);
CORTO_AST_EXPORT cx_int16 ast_BlockCompare(ast_Block dst, ast_Block src);

/* ::corto::ast::Boolean */
CORTO_AST_EXPORT ast_Boolean ast_BooleanCreate(cx_bool value);
CORTO_AST_EXPORT ast_Boolean ast_BooleanCreateChild(cx_object _parent, cx_string _name, cx_bool value);

CORTO_AST_EXPORT ast_Boolean ast_BooleanDeclare(void);
CORTO_AST_EXPORT ast_Boolean ast_BooleanDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_BooleanDefine(ast_Boolean _this, cx_bool value);
CORTO_AST_EXPORT void ast_BooleanUpdate(ast_Boolean _this, cx_bool value);
CORTO_AST_EXPORT void ast_BooleanSet(ast_Boolean _this, cx_bool value);
CORTO_AST_EXPORT cx_string ast_BooleanStr(ast_Boolean value);
CORTO_AST_EXPORT ast_Boolean ast_BooleanFromStr(ast_Boolean value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_BooleanCopy(ast_Boolean *dst, ast_Boolean src);
CORTO_AST_EXPORT cx_int16 ast_BooleanCompare(ast_Boolean dst, ast_Boolean src);

/* ::corto::ast::Call */
CORTO_AST_EXPORT ast_Call ast_CallCreate(ast_Expression instanceExpr, ast_Expression arguments);
CORTO_AST_EXPORT ast_Call ast_CallCreateChild(cx_object _parent, cx_string _name, ast_Expression instanceExpr, ast_Expression arguments);

CORTO_AST_EXPORT ast_Call ast_CallDeclare(void);
CORTO_AST_EXPORT ast_Call ast_CallDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_CallDefine(ast_Call _this, ast_Expression instanceExpr, ast_Expression arguments);
CORTO_AST_EXPORT void ast_CallUpdate(ast_Call _this, ast_Expression instanceExpr, ast_Expression arguments);
CORTO_AST_EXPORT void ast_CallSet(ast_Call _this, ast_Expression instanceExpr, ast_Expression arguments);
CORTO_AST_EXPORT cx_string ast_CallStr(ast_Call value);
CORTO_AST_EXPORT ast_Call ast_CallFromStr(ast_Call value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_CallCopy(ast_Call *dst, ast_Call src);
CORTO_AST_EXPORT cx_int16 ast_CallCompare(ast_Call dst, ast_Call src);

/* ::corto::ast::CallBuilder */
CORTO_AST_EXPORT ast_CallBuilder* ast_CallBuilderCreate(cx_string name, ast_Expression arguments, ast_Expression instance, cx_object scope, ast_Block block);
CORTO_AST_EXPORT ast_CallBuilder* ast_CallBuilderCreateChild(cx_object _parent, cx_string _name, cx_string name, ast_Expression arguments, ast_Expression instance, cx_object scope, ast_Block block);

CORTO_AST_EXPORT ast_CallBuilder* ast_CallBuilderDeclare(void);
CORTO_AST_EXPORT ast_CallBuilder* ast_CallBuilderDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_CallBuilderDefine(ast_CallBuilder* _this, cx_string name, ast_Expression arguments, ast_Expression instance, cx_object scope, ast_Block block);
CORTO_AST_EXPORT void ast_CallBuilderUpdate(ast_CallBuilder* _this, cx_string name, ast_Expression arguments, ast_Expression instance, cx_object scope, ast_Block block);
CORTO_AST_EXPORT void ast_CallBuilderSet(ast_CallBuilder* _this, cx_string name, ast_Expression arguments, ast_Expression instance, cx_object scope, ast_Block block);
CORTO_AST_EXPORT cx_string ast_CallBuilderStr(ast_CallBuilder* value);
CORTO_AST_EXPORT ast_CallBuilder* ast_CallBuilderFromStr(ast_CallBuilder* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_CallBuilderCopy(ast_CallBuilder* *dst, ast_CallBuilder* src);
CORTO_AST_EXPORT cx_int16 ast_CallBuilderCompare(ast_CallBuilder* dst, ast_CallBuilder* src);

CORTO_AST_EXPORT cx_int16 ast_CallBuilderInit(ast_CallBuilder* value);
CORTO_AST_EXPORT cx_int16 ast_CallBuilderDeinit(ast_CallBuilder* value);

/* ::corto::ast::Cast */
CORTO_AST_EXPORT ast_Cast ast_CastCreate(cx_type lvalue, ast_Expression rvalue, cx_bool isReference_1);
CORTO_AST_EXPORT ast_Cast ast_CastCreateChild(cx_object _parent, cx_string _name, cx_type lvalue, ast_Expression rvalue, cx_bool isReference_1);

CORTO_AST_EXPORT ast_Cast ast_CastDeclare(void);
CORTO_AST_EXPORT ast_Cast ast_CastDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_CastDefine(ast_Cast _this, cx_type lvalue, ast_Expression rvalue, cx_bool isReference_1);
CORTO_AST_EXPORT void ast_CastUpdate(ast_Cast _this, cx_type lvalue, ast_Expression rvalue, cx_bool isReference_1);
CORTO_AST_EXPORT void ast_CastSet(ast_Cast _this, cx_type lvalue, ast_Expression rvalue, cx_bool isReference_1);
CORTO_AST_EXPORT cx_string ast_CastStr(ast_Cast value);
CORTO_AST_EXPORT ast_Cast ast_CastFromStr(ast_Cast value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_CastCopy(ast_Cast *dst, ast_Cast src);
CORTO_AST_EXPORT cx_int16 ast_CastCompare(ast_Cast dst, ast_Cast src);

/* ::corto::ast::Character */
CORTO_AST_EXPORT ast_Character ast_CharacterCreate(cx_char value);
CORTO_AST_EXPORT ast_Character ast_CharacterCreateChild(cx_object _parent, cx_string _name, cx_char value);

CORTO_AST_EXPORT ast_Character ast_CharacterDeclare(void);
CORTO_AST_EXPORT ast_Character ast_CharacterDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_CharacterDefine(ast_Character _this, cx_char value);
CORTO_AST_EXPORT void ast_CharacterUpdate(ast_Character _this, cx_char value);
CORTO_AST_EXPORT void ast_CharacterSet(ast_Character _this, cx_char value);
CORTO_AST_EXPORT cx_string ast_CharacterStr(ast_Character value);
CORTO_AST_EXPORT ast_Character ast_CharacterFromStr(ast_Character value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_CharacterCopy(ast_Character *dst, ast_Character src);
CORTO_AST_EXPORT cx_int16 ast_CharacterCompare(ast_Character dst, ast_Character src);

/* ::corto::ast::Comma */
CORTO_AST_EXPORT ast_Comma ast_CommaCreate(void);
CORTO_AST_EXPORT ast_Comma ast_CommaCreateChild(cx_object _parent, cx_string _name);

CORTO_AST_EXPORT ast_Comma ast_CommaDeclare(void);
CORTO_AST_EXPORT ast_Comma ast_CommaDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_CommaDefine(ast_Comma _this);
CORTO_AST_EXPORT void ast_CommaUpdate(ast_Comma _this);
CORTO_AST_EXPORT void ast_CommaSet(ast_Comma _this);
CORTO_AST_EXPORT cx_string ast_CommaStr(ast_Comma value);
CORTO_AST_EXPORT ast_Comma ast_CommaFromStr(ast_Comma value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_CommaCopy(ast_Comma *dst, ast_Comma src);
CORTO_AST_EXPORT cx_int16 ast_CommaCompare(ast_Comma dst, ast_Comma src);

/* ::corto::ast::Define */
CORTO_AST_EXPORT ast_Define ast_DefineCreate(ast_Expression object);
CORTO_AST_EXPORT ast_Define ast_DefineCreateChild(cx_object _parent, cx_string _name, ast_Expression object);

CORTO_AST_EXPORT ast_Define ast_DefineDeclare(void);
CORTO_AST_EXPORT ast_Define ast_DefineDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_DefineDefine(ast_Define _this, ast_Expression object);
CORTO_AST_EXPORT void ast_DefineUpdate(ast_Define _this, ast_Expression object);
CORTO_AST_EXPORT void ast_DefineSet(ast_Define _this, ast_Expression object);
CORTO_AST_EXPORT cx_string ast_DefineStr(ast_Define value);
CORTO_AST_EXPORT ast_Define ast_DefineFromStr(ast_Define value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_DefineCopy(ast_Define *dst, ast_Define src);
CORTO_AST_EXPORT cx_int16 ast_DefineCompare(ast_Define dst, ast_Define src);

/* ::corto::ast::Deinit */
CORTO_AST_EXPORT ast_Deinit ast_DeinitCreate(ast_Storage storage);
CORTO_AST_EXPORT ast_Deinit ast_DeinitCreateChild(cx_object _parent, cx_string _name, ast_Storage storage);

CORTO_AST_EXPORT ast_Deinit ast_DeinitDeclare(void);
CORTO_AST_EXPORT ast_Deinit ast_DeinitDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_DeinitDefine(ast_Deinit _this, ast_Storage storage);
CORTO_AST_EXPORT void ast_DeinitUpdate(ast_Deinit _this, ast_Storage storage);
CORTO_AST_EXPORT void ast_DeinitSet(ast_Deinit _this, ast_Storage storage);
CORTO_AST_EXPORT cx_string ast_DeinitStr(ast_Deinit value);
CORTO_AST_EXPORT ast_Deinit ast_DeinitFromStr(ast_Deinit value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_DeinitCopy(ast_Deinit *dst, ast_Deinit src);
CORTO_AST_EXPORT cx_int16 ast_DeinitCompare(ast_Deinit dst, ast_Deinit src);

/* ::corto::ast::DelegateCall */
CORTO_AST_EXPORT ast_DelegateCall ast_DelegateCallCreate(ast_Expression instanceExpr, ast_Expression arguments, ast_Expression expr);
CORTO_AST_EXPORT ast_DelegateCall ast_DelegateCallCreateChild(cx_object _parent, cx_string _name, ast_Expression instanceExpr, ast_Expression arguments, ast_Expression expr);

CORTO_AST_EXPORT ast_DelegateCall ast_DelegateCallDeclare(void);
CORTO_AST_EXPORT ast_DelegateCall ast_DelegateCallDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_DelegateCallDefine(ast_DelegateCall _this, ast_Expression instanceExpr, ast_Expression arguments, ast_Expression expr);
CORTO_AST_EXPORT void ast_DelegateCallUpdate(ast_DelegateCall _this, ast_Expression instanceExpr, ast_Expression arguments, ast_Expression expr);
CORTO_AST_EXPORT void ast_DelegateCallSet(ast_DelegateCall _this, ast_Expression instanceExpr, ast_Expression arguments, ast_Expression expr);
CORTO_AST_EXPORT cx_string ast_DelegateCallStr(ast_DelegateCall value);
CORTO_AST_EXPORT ast_DelegateCall ast_DelegateCallFromStr(ast_DelegateCall value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_DelegateCallCopy(ast_DelegateCall *dst, ast_DelegateCall src);
CORTO_AST_EXPORT cx_int16 ast_DelegateCallCompare(ast_DelegateCall dst, ast_DelegateCall src);

/* ::corto::ast::derefKind */
CORTO_AST_EXPORT ast_derefKind* ast_derefKindCreate(ast_derefKind value);
CORTO_AST_EXPORT ast_derefKind* ast_derefKindCreateChild(cx_object _parent, cx_string _name, ast_derefKind value);

CORTO_AST_EXPORT ast_derefKind* ast_derefKindDeclare(void);
CORTO_AST_EXPORT ast_derefKind* ast_derefKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_derefKindDefine(ast_derefKind* _this, ast_derefKind value);
CORTO_AST_EXPORT void ast_derefKindUpdate(ast_derefKind* _this, ast_derefKind value);
CORTO_AST_EXPORT void ast_derefKindSet(ast_derefKind* _this, ast_derefKind value);
CORTO_AST_EXPORT cx_string ast_derefKindStr(ast_derefKind value);
CORTO_AST_EXPORT ast_derefKind* ast_derefKindFromStr(ast_derefKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_derefKindCopy(ast_derefKind* *dst, ast_derefKind* src);
CORTO_AST_EXPORT cx_int16 ast_derefKindCompare(ast_derefKind* dst, ast_derefKind* src);

CORTO_AST_EXPORT cx_int16 ast_derefKindInit(ast_derefKind* value);
CORTO_AST_EXPORT cx_int16 ast_derefKindDeinit(ast_derefKind* value);

/* ::corto::ast::DynamicInitializer */
CORTO_AST_EXPORT ast_DynamicInitializer ast_DynamicInitializerCreate(ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT ast_DynamicInitializer ast_DynamicInitializerCreateChild(cx_object _parent, cx_string _name, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);

CORTO_AST_EXPORT ast_DynamicInitializer ast_DynamicInitializerDeclare(void);
CORTO_AST_EXPORT ast_DynamicInitializer ast_DynamicInitializerDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerDefine(ast_DynamicInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT void ast_DynamicInitializerUpdate(ast_DynamicInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT void ast_DynamicInitializerSet(ast_DynamicInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT cx_string ast_DynamicInitializerStr(ast_DynamicInitializer value);
CORTO_AST_EXPORT ast_DynamicInitializer ast_DynamicInitializerFromStr(ast_DynamicInitializer value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerCopy(ast_DynamicInitializer *dst, ast_DynamicInitializer src);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerCompare(ast_DynamicInitializer dst, ast_DynamicInitializer src);

/* ::corto::ast::DynamicInitializerFrame */
CORTO_AST_EXPORT ast_DynamicInitializerFrame* ast_DynamicInitializerFrameCreate(ast_ExpressionArray64 expr, ast_ExpressionArray64 keyExpr, ast_Integer sequenceSize);
CORTO_AST_EXPORT ast_DynamicInitializerFrame* ast_DynamicInitializerFrameCreateChild(cx_object _parent, cx_string _name, ast_ExpressionArray64 expr, ast_ExpressionArray64 keyExpr, ast_Integer sequenceSize);

CORTO_AST_EXPORT ast_DynamicInitializerFrame* ast_DynamicInitializerFrameDeclare(void);
CORTO_AST_EXPORT ast_DynamicInitializerFrame* ast_DynamicInitializerFrameDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerFrameDefine(ast_DynamicInitializerFrame* _this, ast_ExpressionArray64 expr, ast_ExpressionArray64 keyExpr, ast_Integer sequenceSize);
CORTO_AST_EXPORT void ast_DynamicInitializerFrameUpdate(ast_DynamicInitializerFrame* _this, ast_ExpressionArray64 expr, ast_ExpressionArray64 keyExpr, ast_Integer sequenceSize);
CORTO_AST_EXPORT void ast_DynamicInitializerFrameSet(ast_DynamicInitializerFrame* _this, ast_ExpressionArray64 expr, ast_ExpressionArray64 keyExpr, ast_Integer sequenceSize);
CORTO_AST_EXPORT cx_string ast_DynamicInitializerFrameStr(ast_DynamicInitializerFrame* value);
CORTO_AST_EXPORT ast_DynamicInitializerFrame* ast_DynamicInitializerFrameFromStr(ast_DynamicInitializerFrame* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerFrameCopy(ast_DynamicInitializerFrame* *dst, ast_DynamicInitializerFrame* src);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerFrameCompare(ast_DynamicInitializerFrame* dst, ast_DynamicInitializerFrame* src);

CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerFrameInit(ast_DynamicInitializerFrame* value);
CORTO_AST_EXPORT cx_int16 ast_DynamicInitializerFrameDeinit(ast_DynamicInitializerFrame* value);

/* ::corto::ast::Element */
CORTO_AST_EXPORT ast_Element ast_ElementCreate(ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT ast_Element ast_ElementCreateChild(cx_object _parent, cx_string _name, ast_Expression lvalue, ast_Expression rvalue);

CORTO_AST_EXPORT ast_Element ast_ElementDeclare(void);
CORTO_AST_EXPORT ast_Element ast_ElementDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ElementDefine(ast_Element _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT void ast_ElementUpdate(ast_Element _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT void ast_ElementSet(ast_Element _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT cx_string ast_ElementStr(ast_Element value);
CORTO_AST_EXPORT ast_Element ast_ElementFromStr(ast_Element value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ElementCopy(ast_Element *dst, ast_Element src);
CORTO_AST_EXPORT cx_int16 ast_ElementCompare(ast_Element dst, ast_Element src);

/* ::corto::ast::Expression */
CORTO_AST_EXPORT ast_Expression ast_ExpressionCreate(ast_nodeKind kind);
CORTO_AST_EXPORT ast_Expression ast_ExpressionCreateChild(cx_object _parent, cx_string _name, ast_nodeKind kind);

CORTO_AST_EXPORT ast_Expression ast_ExpressionDeclare(void);
CORTO_AST_EXPORT ast_Expression ast_ExpressionDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ExpressionDefine(ast_Expression _this, ast_nodeKind kind);
CORTO_AST_EXPORT void ast_ExpressionUpdate(ast_Expression _this, ast_nodeKind kind);
CORTO_AST_EXPORT void ast_ExpressionSet(ast_Expression _this, ast_nodeKind kind);
CORTO_AST_EXPORT cx_string ast_ExpressionStr(ast_Expression value);
CORTO_AST_EXPORT ast_Expression ast_ExpressionFromStr(ast_Expression value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ExpressionCopy(ast_Expression *dst, ast_Expression src);
CORTO_AST_EXPORT cx_int16 ast_ExpressionCompare(ast_Expression dst, ast_Expression src);

/* ::corto::ast::FloatingPoint */
CORTO_AST_EXPORT ast_FloatingPoint ast_FloatingPointCreate(cx_float64 value);
CORTO_AST_EXPORT ast_FloatingPoint ast_FloatingPointCreateChild(cx_object _parent, cx_string _name, cx_float64 value);

CORTO_AST_EXPORT ast_FloatingPoint ast_FloatingPointDeclare(void);
CORTO_AST_EXPORT ast_FloatingPoint ast_FloatingPointDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_FloatingPointDefine(ast_FloatingPoint _this, cx_float64 value);
CORTO_AST_EXPORT void ast_FloatingPointUpdate(ast_FloatingPoint _this, cx_float64 value);
CORTO_AST_EXPORT void ast_FloatingPointSet(ast_FloatingPoint _this, cx_float64 value);
CORTO_AST_EXPORT cx_string ast_FloatingPointStr(ast_FloatingPoint value);
CORTO_AST_EXPORT ast_FloatingPoint ast_FloatingPointFromStr(ast_FloatingPoint value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_FloatingPointCopy(ast_FloatingPoint *dst, ast_FloatingPoint src);
CORTO_AST_EXPORT cx_int16 ast_FloatingPointCompare(ast_FloatingPoint dst, ast_FloatingPoint src);

/* ::corto::ast::If */
CORTO_AST_EXPORT ast_If ast_IfCreate(ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);
CORTO_AST_EXPORT ast_If ast_IfCreateChild(cx_object _parent, cx_string _name, ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);

CORTO_AST_EXPORT ast_If ast_IfDeclare(void);
CORTO_AST_EXPORT ast_If ast_IfDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_IfDefine(ast_If _this, ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);
CORTO_AST_EXPORT void ast_IfUpdate(ast_If _this, ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);
CORTO_AST_EXPORT void ast_IfSet(ast_If _this, ast_Expression condition, ast_Block trueBranch, ast_If falseBranch);
CORTO_AST_EXPORT cx_string ast_IfStr(ast_If value);
CORTO_AST_EXPORT ast_If ast_IfFromStr(ast_If value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_IfCopy(ast_If *dst, ast_If src);
CORTO_AST_EXPORT cx_int16 ast_IfCompare(ast_If dst, ast_If src);

/* ::corto::ast::Init */
CORTO_AST_EXPORT ast_Init ast_InitCreate(ast_Storage storage);
CORTO_AST_EXPORT ast_Init ast_InitCreateChild(cx_object _parent, cx_string _name, ast_Storage storage);

CORTO_AST_EXPORT ast_Init ast_InitDeclare(void);
CORTO_AST_EXPORT ast_Init ast_InitDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitDefine(ast_Init _this, ast_Storage storage);
CORTO_AST_EXPORT void ast_InitUpdate(ast_Init _this, ast_Storage storage);
CORTO_AST_EXPORT void ast_InitSet(ast_Init _this, ast_Storage storage);
CORTO_AST_EXPORT cx_string ast_InitStr(ast_Init value);
CORTO_AST_EXPORT ast_Init ast_InitFromStr(ast_Init value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitCopy(ast_Init *dst, ast_Init src);
CORTO_AST_EXPORT cx_int16 ast_InitCompare(ast_Init dst, ast_Init src);

/* ::corto::ast::Initializer */
CORTO_AST_EXPORT ast_Initializer ast_InitializerCreate(ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT ast_Initializer ast_InitializerCreateChild(cx_object _parent, cx_string _name, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);

CORTO_AST_EXPORT ast_Initializer ast_InitializerDeclare(void);
CORTO_AST_EXPORT ast_Initializer ast_InitializerDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitializerDefine(ast_Initializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT void ast_InitializerUpdate(ast_Initializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT void ast_InitializerSet(ast_Initializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT cx_string ast_InitializerStr(ast_Initializer value);
CORTO_AST_EXPORT ast_Initializer ast_InitializerFromStr(ast_Initializer value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitializerCopy(ast_Initializer *dst, ast_Initializer src);
CORTO_AST_EXPORT cx_int16 ast_InitializerCompare(ast_Initializer dst, ast_Initializer src);

/* ::corto::ast::InitializerExpression */
CORTO_AST_EXPORT ast_InitializerExpression ast_InitializerExpressionCreate(ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT ast_InitializerExpression ast_InitializerExpressionCreateChild(cx_object _parent, cx_string _name, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);

CORTO_AST_EXPORT ast_InitializerExpression ast_InitializerExpressionDeclare(void);
CORTO_AST_EXPORT ast_InitializerExpression ast_InitializerExpressionDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitializerExpressionDefine(ast_InitializerExpression _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT void ast_InitializerExpressionUpdate(ast_InitializerExpression _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT void ast_InitializerExpressionSet(ast_InitializerExpression _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount, cx_bool assignValue);
CORTO_AST_EXPORT cx_string ast_InitializerExpressionStr(ast_InitializerExpression value);
CORTO_AST_EXPORT ast_InitializerExpression ast_InitializerExpressionFromStr(ast_InitializerExpression value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitializerExpressionCopy(ast_InitializerExpression *dst, ast_InitializerExpression src);
CORTO_AST_EXPORT cx_int16 ast_InitializerExpressionCompare(ast_InitializerExpression dst, ast_InitializerExpression src);

/* ::corto::ast::InitializerFrame */
CORTO_AST_EXPORT ast_InitializerFrame* ast_InitializerFrameCreate(cx_uint32 location, cx_type type, cx_bool isKey, cx_member member);
CORTO_AST_EXPORT ast_InitializerFrame* ast_InitializerFrameCreateChild(cx_object _parent, cx_string _name, cx_uint32 location, cx_type type, cx_bool isKey, cx_member member);

CORTO_AST_EXPORT ast_InitializerFrame* ast_InitializerFrameDeclare(void);
CORTO_AST_EXPORT ast_InitializerFrame* ast_InitializerFrameDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitializerFrameDefine(ast_InitializerFrame* _this, cx_uint32 location, cx_type type, cx_bool isKey, cx_member member);
CORTO_AST_EXPORT void ast_InitializerFrameUpdate(ast_InitializerFrame* _this, cx_uint32 location, cx_type type, cx_bool isKey, cx_member member);
CORTO_AST_EXPORT void ast_InitializerFrameSet(ast_InitializerFrame* _this, cx_uint32 location, cx_type type, cx_bool isKey, cx_member member);
CORTO_AST_EXPORT cx_string ast_InitializerFrameStr(ast_InitializerFrame* value);
CORTO_AST_EXPORT ast_InitializerFrame* ast_InitializerFrameFromStr(ast_InitializerFrame* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitializerFrameCopy(ast_InitializerFrame* *dst, ast_InitializerFrame* src);
CORTO_AST_EXPORT cx_int16 ast_InitializerFrameCompare(ast_InitializerFrame* dst, ast_InitializerFrame* src);

CORTO_AST_EXPORT cx_int16 ast_InitializerFrameInit(ast_InitializerFrame* value);
CORTO_AST_EXPORT cx_int16 ast_InitializerFrameDeinit(ast_InitializerFrame* value);

/* ::corto::ast::InitializerKind */
CORTO_AST_EXPORT ast_InitializerKind* ast_InitializerKindCreate(ast_InitializerKind value);
CORTO_AST_EXPORT ast_InitializerKind* ast_InitializerKindCreateChild(cx_object _parent, cx_string _name, ast_InitializerKind value);

CORTO_AST_EXPORT ast_InitializerKind* ast_InitializerKindDeclare(void);
CORTO_AST_EXPORT ast_InitializerKind* ast_InitializerKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitializerKindDefine(ast_InitializerKind* _this, ast_InitializerKind value);
CORTO_AST_EXPORT void ast_InitializerKindUpdate(ast_InitializerKind* _this, ast_InitializerKind value);
CORTO_AST_EXPORT void ast_InitializerKindSet(ast_InitializerKind* _this, ast_InitializerKind value);
CORTO_AST_EXPORT cx_string ast_InitializerKindStr(ast_InitializerKind value);
CORTO_AST_EXPORT ast_InitializerKind* ast_InitializerKindFromStr(ast_InitializerKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitializerKindCopy(ast_InitializerKind* *dst, ast_InitializerKind* src);
CORTO_AST_EXPORT cx_int16 ast_InitializerKindCompare(ast_InitializerKind* dst, ast_InitializerKind* src);

CORTO_AST_EXPORT cx_int16 ast_InitializerKindInit(ast_InitializerKind* value);
CORTO_AST_EXPORT cx_int16 ast_InitializerKindDeinit(ast_InitializerKind* value);

/* ::corto::ast::InitializerVariable */
CORTO_AST_EXPORT ast_InitializerVariable* ast_InitializerVariableCreate(cx_word offset, ast_Expression object, cx_word key);
CORTO_AST_EXPORT ast_InitializerVariable* ast_InitializerVariableCreateChild(cx_object _parent, cx_string _name, cx_word offset, ast_Expression object, cx_word key);

CORTO_AST_EXPORT ast_InitializerVariable* ast_InitializerVariableDeclare(void);
CORTO_AST_EXPORT ast_InitializerVariable* ast_InitializerVariableDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitializerVariableDefine(ast_InitializerVariable* _this, cx_word offset, ast_Expression object, cx_word key);
CORTO_AST_EXPORT void ast_InitializerVariableUpdate(ast_InitializerVariable* _this, cx_word offset, ast_Expression object, cx_word key);
CORTO_AST_EXPORT void ast_InitializerVariableSet(ast_InitializerVariable* _this, cx_word offset, ast_Expression object, cx_word key);
CORTO_AST_EXPORT cx_string ast_InitializerVariableStr(ast_InitializerVariable* value);
CORTO_AST_EXPORT ast_InitializerVariable* ast_InitializerVariableFromStr(ast_InitializerVariable* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitializerVariableCopy(ast_InitializerVariable* *dst, ast_InitializerVariable* src);
CORTO_AST_EXPORT cx_int16 ast_InitializerVariableCompare(ast_InitializerVariable* dst, ast_InitializerVariable* src);

CORTO_AST_EXPORT cx_int16 ast_InitializerVariableInit(ast_InitializerVariable* value);
CORTO_AST_EXPORT cx_int16 ast_InitializerVariableDeinit(ast_InitializerVariable* value);

/* ::corto::ast::InitOper */
CORTO_AST_EXPORT ast_InitOper* ast_InitOperCreate(ast_InitOperKind kind, ast_Expression expr, cx_string name);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperCreateChild(cx_object _parent, cx_string _name, ast_InitOperKind kind, ast_Expression expr, cx_string name);

CORTO_AST_EXPORT ast_InitOper* ast_InitOperDeclare(void);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitOperDefine(ast_InitOper* _this, ast_InitOperKind kind, ast_Expression expr, cx_string name);
CORTO_AST_EXPORT void ast_InitOperUpdate(ast_InitOper* _this, ast_InitOperKind kind, ast_Expression expr, cx_string name);
CORTO_AST_EXPORT void ast_InitOperSet(ast_InitOper* _this, ast_InitOperKind kind, ast_Expression expr, cx_string name);
CORTO_AST_EXPORT cx_string ast_InitOperStr(ast_InitOper* value);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperFromStr(ast_InitOper* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitOperCopy(ast_InitOper* *dst, ast_InitOper* src);
CORTO_AST_EXPORT cx_int16 ast_InitOperCompare(ast_InitOper* dst, ast_InitOper* src);

CORTO_AST_EXPORT cx_int16 ast_InitOperInit(ast_InitOper* value);
CORTO_AST_EXPORT cx_int16 ast_InitOperDeinit(ast_InitOper* value);

/* ::corto::ast::InitOperKind */
CORTO_AST_EXPORT ast_InitOperKind* ast_InitOperKindCreate(ast_InitOperKind value);
CORTO_AST_EXPORT ast_InitOperKind* ast_InitOperKindCreateChild(cx_object _parent, cx_string _name, ast_InitOperKind value);

CORTO_AST_EXPORT ast_InitOperKind* ast_InitOperKindDeclare(void);
CORTO_AST_EXPORT ast_InitOperKind* ast_InitOperKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_InitOperKindDefine(ast_InitOperKind* _this, ast_InitOperKind value);
CORTO_AST_EXPORT void ast_InitOperKindUpdate(ast_InitOperKind* _this, ast_InitOperKind value);
CORTO_AST_EXPORT void ast_InitOperKindSet(ast_InitOperKind* _this, ast_InitOperKind value);
CORTO_AST_EXPORT cx_string ast_InitOperKindStr(ast_InitOperKind value);
CORTO_AST_EXPORT ast_InitOperKind* ast_InitOperKindFromStr(ast_InitOperKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_InitOperKindCopy(ast_InitOperKind* *dst, ast_InitOperKind* src);
CORTO_AST_EXPORT cx_int16 ast_InitOperKindCompare(ast_InitOperKind* dst, ast_InitOperKind* src);

CORTO_AST_EXPORT cx_int16 ast_InitOperKindInit(ast_InitOperKind* value);
CORTO_AST_EXPORT cx_int16 ast_InitOperKindDeinit(ast_InitOperKind* value);

/* ::corto::ast::Integer */
CORTO_AST_EXPORT ast_Integer ast_IntegerCreate(cx_uint64 value);
CORTO_AST_EXPORT ast_Integer ast_IntegerCreateChild(cx_object _parent, cx_string _name, cx_uint64 value);

CORTO_AST_EXPORT ast_Integer ast_IntegerDeclare(void);
CORTO_AST_EXPORT ast_Integer ast_IntegerDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_IntegerDefine(ast_Integer _this, cx_uint64 value);
CORTO_AST_EXPORT void ast_IntegerUpdate(ast_Integer _this, cx_uint64 value);
CORTO_AST_EXPORT void ast_IntegerSet(ast_Integer _this, cx_uint64 value);
CORTO_AST_EXPORT cx_string ast_IntegerStr(ast_Integer value);
CORTO_AST_EXPORT ast_Integer ast_IntegerFromStr(ast_Integer value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_IntegerCopy(ast_Integer *dst, ast_Integer src);
CORTO_AST_EXPORT cx_int16 ast_IntegerCompare(ast_Integer dst, ast_Integer src);

/* ::corto::ast::Literal */
CORTO_AST_EXPORT ast_Literal ast_LiteralCreate(ast_valueKind kind_1);
CORTO_AST_EXPORT ast_Literal ast_LiteralCreateChild(cx_object _parent, cx_string _name, ast_valueKind kind_1);

CORTO_AST_EXPORT ast_Literal ast_LiteralDeclare(void);
CORTO_AST_EXPORT ast_Literal ast_LiteralDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_LiteralDefine(ast_Literal _this, ast_valueKind kind_1);
CORTO_AST_EXPORT void ast_LiteralUpdate(ast_Literal _this, ast_valueKind kind_1);
CORTO_AST_EXPORT void ast_LiteralSet(ast_Literal _this, ast_valueKind kind_1);
CORTO_AST_EXPORT cx_string ast_LiteralStr(ast_Literal value);
CORTO_AST_EXPORT ast_Literal ast_LiteralFromStr(ast_Literal value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_LiteralCopy(ast_Literal *dst, ast_Literal src);
CORTO_AST_EXPORT cx_int16 ast_LiteralCompare(ast_Literal dst, ast_Literal src);

/* ::corto::ast::Local */
CORTO_AST_EXPORT ast_Local ast_LocalCreate(cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT ast_Local ast_LocalCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);

CORTO_AST_EXPORT ast_Local ast_LocalDeclare(void);
CORTO_AST_EXPORT ast_Local ast_LocalDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_LocalDefine(ast_Local _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT void ast_LocalUpdate(ast_Local _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT void ast_LocalSet(ast_Local _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT cx_string ast_LocalStr(ast_Local value);
CORTO_AST_EXPORT ast_Local ast_LocalFromStr(ast_Local value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_LocalCopy(ast_Local *dst, ast_Local src);
CORTO_AST_EXPORT cx_int16 ast_LocalCompare(ast_Local dst, ast_Local src);

/* ::corto::ast::LocalKind */
CORTO_AST_EXPORT ast_LocalKind* ast_LocalKindCreate(ast_LocalKind value);
CORTO_AST_EXPORT ast_LocalKind* ast_LocalKindCreateChild(cx_object _parent, cx_string _name, ast_LocalKind value);

CORTO_AST_EXPORT ast_LocalKind* ast_LocalKindDeclare(void);
CORTO_AST_EXPORT ast_LocalKind* ast_LocalKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_LocalKindDefine(ast_LocalKind* _this, ast_LocalKind value);
CORTO_AST_EXPORT void ast_LocalKindUpdate(ast_LocalKind* _this, ast_LocalKind value);
CORTO_AST_EXPORT void ast_LocalKindSet(ast_LocalKind* _this, ast_LocalKind value);
CORTO_AST_EXPORT cx_string ast_LocalKindStr(ast_LocalKind value);
CORTO_AST_EXPORT ast_LocalKind* ast_LocalKindFromStr(ast_LocalKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_LocalKindCopy(ast_LocalKind* *dst, ast_LocalKind* src);
CORTO_AST_EXPORT cx_int16 ast_LocalKindCompare(ast_LocalKind* dst, ast_LocalKind* src);

CORTO_AST_EXPORT cx_int16 ast_LocalKindInit(ast_LocalKind* value);
CORTO_AST_EXPORT cx_int16 ast_LocalKindDeinit(ast_LocalKind* value);

/* ::corto::ast::Lvalue */
CORTO_AST_EXPORT ast_Lvalue* ast_LvalueCreate(ast_Expression expr, cx_bool isAssignment);
CORTO_AST_EXPORT ast_Lvalue* ast_LvalueCreateChild(cx_object _parent, cx_string _name, ast_Expression expr, cx_bool isAssignment);

CORTO_AST_EXPORT ast_Lvalue* ast_LvalueDeclare(void);
CORTO_AST_EXPORT ast_Lvalue* ast_LvalueDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_LvalueDefine(ast_Lvalue* _this, ast_Expression expr, cx_bool isAssignment);
CORTO_AST_EXPORT void ast_LvalueUpdate(ast_Lvalue* _this, ast_Expression expr, cx_bool isAssignment);
CORTO_AST_EXPORT void ast_LvalueSet(ast_Lvalue* _this, ast_Expression expr, cx_bool isAssignment);
CORTO_AST_EXPORT cx_string ast_LvalueStr(ast_Lvalue* value);
CORTO_AST_EXPORT ast_Lvalue* ast_LvalueFromStr(ast_Lvalue* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_LvalueCopy(ast_Lvalue* *dst, ast_Lvalue* src);
CORTO_AST_EXPORT cx_int16 ast_LvalueCompare(ast_Lvalue* dst, ast_Lvalue* src);

CORTO_AST_EXPORT cx_int16 ast_LvalueInit(ast_Lvalue* value);
CORTO_AST_EXPORT cx_int16 ast_LvalueDeinit(ast_Lvalue* value);

/* ::corto::ast::Member */
CORTO_AST_EXPORT ast_Member ast_MemberCreate(ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT ast_Member ast_MemberCreateChild(cx_object _parent, cx_string _name, ast_Expression lvalue, ast_Expression rvalue);

CORTO_AST_EXPORT ast_Member ast_MemberDeclare(void);
CORTO_AST_EXPORT ast_Member ast_MemberDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_MemberDefine(ast_Member _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT void ast_MemberUpdate(ast_Member _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT void ast_MemberSet(ast_Member _this, ast_Expression lvalue, ast_Expression rvalue);
CORTO_AST_EXPORT cx_string ast_MemberStr(ast_Member value);
CORTO_AST_EXPORT ast_Member ast_MemberFromStr(ast_Member value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_MemberCopy(ast_Member *dst, ast_Member src);
CORTO_AST_EXPORT cx_int16 ast_MemberCompare(ast_Member dst, ast_Member src);

/* ::corto::ast::New */
CORTO_AST_EXPORT ast_New ast_NewCreate(cx_type type_1, ast_Expression attributes);
CORTO_AST_EXPORT ast_New ast_NewCreateChild(cx_object _parent, cx_string _name, cx_type type_1, ast_Expression attributes);

CORTO_AST_EXPORT ast_New ast_NewDeclare(void);
CORTO_AST_EXPORT ast_New ast_NewDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_NewDefine(ast_New _this, cx_type type_1, ast_Expression attributes);
CORTO_AST_EXPORT void ast_NewUpdate(ast_New _this, cx_type type_1, ast_Expression attributes);
CORTO_AST_EXPORT void ast_NewSet(ast_New _this, cx_type type_1, ast_Expression attributes);
CORTO_AST_EXPORT cx_string ast_NewStr(ast_New value);
CORTO_AST_EXPORT ast_New ast_NewFromStr(ast_New value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_NewCopy(ast_New *dst, ast_New src);
CORTO_AST_EXPORT cx_int16 ast_NewCompare(ast_New dst, ast_New src);

/* ::corto::ast::Node */
CORTO_AST_EXPORT ast_Node ast_NodeCreate(ast_nodeKind kind);
CORTO_AST_EXPORT ast_Node ast_NodeCreateChild(cx_object _parent, cx_string _name, ast_nodeKind kind);

CORTO_AST_EXPORT ast_Node ast_NodeDeclare(void);
CORTO_AST_EXPORT ast_Node ast_NodeDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_NodeDefine(ast_Node _this, ast_nodeKind kind);
CORTO_AST_EXPORT void ast_NodeUpdate(ast_Node _this, ast_nodeKind kind);
CORTO_AST_EXPORT void ast_NodeSet(ast_Node _this, ast_nodeKind kind);
CORTO_AST_EXPORT cx_string ast_NodeStr(ast_Node value);
CORTO_AST_EXPORT ast_Node ast_NodeFromStr(ast_Node value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_NodeCopy(ast_Node *dst, ast_Node src);
CORTO_AST_EXPORT cx_int16 ast_NodeCompare(ast_Node dst, ast_Node src);

/* ::corto::ast::nodeKind */
CORTO_AST_EXPORT ast_nodeKind* ast_nodeKindCreate(ast_nodeKind value);
CORTO_AST_EXPORT ast_nodeKind* ast_nodeKindCreateChild(cx_object _parent, cx_string _name, ast_nodeKind value);

CORTO_AST_EXPORT ast_nodeKind* ast_nodeKindDeclare(void);
CORTO_AST_EXPORT ast_nodeKind* ast_nodeKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_nodeKindDefine(ast_nodeKind* _this, ast_nodeKind value);
CORTO_AST_EXPORT void ast_nodeKindUpdate(ast_nodeKind* _this, ast_nodeKind value);
CORTO_AST_EXPORT void ast_nodeKindSet(ast_nodeKind* _this, ast_nodeKind value);
CORTO_AST_EXPORT cx_string ast_nodeKindStr(ast_nodeKind value);
CORTO_AST_EXPORT ast_nodeKind* ast_nodeKindFromStr(ast_nodeKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_nodeKindCopy(ast_nodeKind* *dst, ast_nodeKind* src);
CORTO_AST_EXPORT cx_int16 ast_nodeKindCompare(ast_nodeKind* dst, ast_nodeKind* src);

CORTO_AST_EXPORT cx_int16 ast_nodeKindInit(ast_nodeKind* value);
CORTO_AST_EXPORT cx_int16 ast_nodeKindDeinit(ast_nodeKind* value);

/* ::corto::ast::Null */
CORTO_AST_EXPORT ast_Null ast_NullCreate(void);
CORTO_AST_EXPORT ast_Null ast_NullCreateChild(cx_object _parent, cx_string _name);

CORTO_AST_EXPORT ast_Null ast_NullDeclare(void);
CORTO_AST_EXPORT ast_Null ast_NullDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_NullDefine(ast_Null _this);
CORTO_AST_EXPORT void ast_NullUpdate(ast_Null _this);
CORTO_AST_EXPORT void ast_NullSet(ast_Null _this);
CORTO_AST_EXPORT cx_string ast_NullStr(ast_Null value);
CORTO_AST_EXPORT ast_Null ast_NullFromStr(ast_Null value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_NullCopy(ast_Null *dst, ast_Null src);
CORTO_AST_EXPORT cx_int16 ast_NullCompare(ast_Null dst, ast_Null src);

/* ::corto::ast::Object */
CORTO_AST_EXPORT ast_Object ast_ObjectCreate(cx_object value);
CORTO_AST_EXPORT ast_Object ast_ObjectCreateChild(cx_object _parent, cx_string _name, cx_object value);

CORTO_AST_EXPORT ast_Object ast_ObjectDeclare(void);
CORTO_AST_EXPORT ast_Object ast_ObjectDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ObjectDefine(ast_Object _this, cx_object value);
CORTO_AST_EXPORT void ast_ObjectUpdate(ast_Object _this, cx_object value);
CORTO_AST_EXPORT void ast_ObjectSet(ast_Object _this, cx_object value);
CORTO_AST_EXPORT cx_string ast_ObjectStr(ast_Object value);
CORTO_AST_EXPORT ast_Object ast_ObjectFromStr(ast_Object value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ObjectCopy(ast_Object *dst, ast_Object src);
CORTO_AST_EXPORT cx_int16 ast_ObjectCompare(ast_Object dst, ast_Object src);

/* ::corto::ast::Parser */
CORTO_AST_EXPORT ast_Parser ast_ParserCreate(cx_string source, cx_string filename);
CORTO_AST_EXPORT ast_Parser ast_ParserCreateChild(cx_object _parent, cx_string _name, cx_string source, cx_string filename);

CORTO_AST_EXPORT ast_Parser ast_ParserDeclare(void);
CORTO_AST_EXPORT ast_Parser ast_ParserDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ParserDefine(ast_Parser _this, cx_string source, cx_string filename);
CORTO_AST_EXPORT void ast_ParserUpdate(ast_Parser _this, cx_string source, cx_string filename);
CORTO_AST_EXPORT void ast_ParserSet(ast_Parser _this, cx_string source, cx_string filename);
CORTO_AST_EXPORT cx_string ast_ParserStr(ast_Parser value);
CORTO_AST_EXPORT ast_Parser ast_ParserFromStr(ast_Parser value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ParserCopy(ast_Parser *dst, ast_Parser src);
CORTO_AST_EXPORT cx_int16 ast_ParserCompare(ast_Parser dst, ast_Parser src);

/* ::corto::ast::Parser::stagedId */
CORTO_AST_EXPORT ast_Parser_stagedId* ast_Parser_stagedIdCreate(cx_string name, cx_bool found, cx_uint32 line, cx_uint32 column);
CORTO_AST_EXPORT ast_Parser_stagedId* ast_Parser_stagedIdCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_bool found, cx_uint32 line, cx_uint32 column);

CORTO_AST_EXPORT ast_Parser_stagedId* ast_Parser_stagedIdDeclare(void);
CORTO_AST_EXPORT ast_Parser_stagedId* ast_Parser_stagedIdDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_Parser_stagedIdDefine(ast_Parser_stagedId* _this, cx_string name, cx_bool found, cx_uint32 line, cx_uint32 column);
CORTO_AST_EXPORT void ast_Parser_stagedIdUpdate(ast_Parser_stagedId* _this, cx_string name, cx_bool found, cx_uint32 line, cx_uint32 column);
CORTO_AST_EXPORT void ast_Parser_stagedIdSet(ast_Parser_stagedId* _this, cx_string name, cx_bool found, cx_uint32 line, cx_uint32 column);
CORTO_AST_EXPORT cx_string ast_Parser_stagedIdStr(ast_Parser_stagedId* value);
CORTO_AST_EXPORT ast_Parser_stagedId* ast_Parser_stagedIdFromStr(ast_Parser_stagedId* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_Parser_stagedIdCopy(ast_Parser_stagedId* *dst, ast_Parser_stagedId* src);
CORTO_AST_EXPORT cx_int16 ast_Parser_stagedIdCompare(ast_Parser_stagedId* dst, ast_Parser_stagedId* src);

CORTO_AST_EXPORT cx_int16 ast_Parser_stagedIdInit(ast_Parser_stagedId* value);
CORTO_AST_EXPORT cx_int16 ast_Parser_stagedIdDeinit(ast_Parser_stagedId* value);

/* ::corto::ast::ParserDeclaration */
CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationCreate(cx_string name, ast_Storage storage);
CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationCreateChild(cx_object _parent, cx_string _name, cx_string name, ast_Storage storage);

CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationDeclare(void);
CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationDefine(ast_ParserDeclaration* _this, cx_string name, ast_Storage storage);
CORTO_AST_EXPORT void ast_ParserDeclarationUpdate(ast_ParserDeclaration* _this, cx_string name, ast_Storage storage);
CORTO_AST_EXPORT void ast_ParserDeclarationSet(ast_ParserDeclaration* _this, cx_string name, ast_Storage storage);
CORTO_AST_EXPORT cx_string ast_ParserDeclarationStr(ast_ParserDeclaration* value);
CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationFromStr(ast_ParserDeclaration* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationCopy(ast_ParserDeclaration* *dst, ast_ParserDeclaration* src);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationCompare(ast_ParserDeclaration* dst, ast_ParserDeclaration* src);

CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationInit(ast_ParserDeclaration* value);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationDeinit(ast_ParserDeclaration* value);

/* ::corto::ast::ParserDeclarationSeq */
CORTO_AST_EXPORT ast_ParserDeclarationSeq* ast_ParserDeclarationSeqCreate(void);
CORTO_AST_EXPORT ast_ParserDeclarationSeq* ast_ParserDeclarationSeqCreateChild(cx_object _parent, cx_string _name);

CORTO_AST_EXPORT ast_ParserDeclarationSeq* ast_ParserDeclarationSeqDeclare(void);
CORTO_AST_EXPORT ast_ParserDeclarationSeq* ast_ParserDeclarationSeqDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationSeqDefine(ast_ParserDeclarationSeq* _this, ast_ParserDeclarationSeq value);
CORTO_AST_EXPORT void ast_ParserDeclarationSeqUpdate(ast_ParserDeclarationSeq* _this, ast_ParserDeclarationSeq value);
CORTO_AST_EXPORT void ast_ParserDeclarationSeqSet(ast_ParserDeclarationSeq* _this, ast_ParserDeclarationSeq value);
CORTO_AST_EXPORT cx_string ast_ParserDeclarationSeqStr(ast_ParserDeclarationSeq value);
CORTO_AST_EXPORT ast_ParserDeclarationSeq* ast_ParserDeclarationSeqFromStr(ast_ParserDeclarationSeq* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationSeqCopy(ast_ParserDeclarationSeq* *dst, ast_ParserDeclarationSeq* src);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationSeqCompare(ast_ParserDeclarationSeq* dst, ast_ParserDeclarationSeq* src);

CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationSeqInit(ast_ParserDeclarationSeq* value);
CORTO_AST_EXPORT cx_int16 ast_ParserDeclarationSeqDeinit(ast_ParserDeclarationSeq* value);

/* ::corto::ast::ParserNew */
CORTO_AST_EXPORT ast_ParserNew* ast_ParserNewCreate(ast_nodeKind kind, ast_Expression parent, ast_Expression name, ast_Expression attr);
CORTO_AST_EXPORT ast_ParserNew* ast_ParserNewCreateChild(cx_object _parent, cx_string _name, ast_nodeKind kind, ast_Expression parent, ast_Expression name, ast_Expression attr);

CORTO_AST_EXPORT ast_ParserNew* ast_ParserNewDeclare(void);
CORTO_AST_EXPORT ast_ParserNew* ast_ParserNewDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_ParserNewDefine(ast_ParserNew* _this, ast_nodeKind kind, ast_Expression parent, ast_Expression name, ast_Expression attr);
CORTO_AST_EXPORT void ast_ParserNewUpdate(ast_ParserNew* _this, ast_nodeKind kind, ast_Expression parent, ast_Expression name, ast_Expression attr);
CORTO_AST_EXPORT void ast_ParserNewSet(ast_ParserNew* _this, ast_nodeKind kind, ast_Expression parent, ast_Expression name, ast_Expression attr);
CORTO_AST_EXPORT cx_string ast_ParserNewStr(ast_ParserNew* value);
CORTO_AST_EXPORT ast_ParserNew* ast_ParserNewFromStr(ast_ParserNew* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_ParserNewCopy(ast_ParserNew* *dst, ast_ParserNew* src);
CORTO_AST_EXPORT cx_int16 ast_ParserNewCompare(ast_ParserNew* dst, ast_ParserNew* src);

CORTO_AST_EXPORT cx_int16 ast_ParserNewInit(ast_ParserNew* value);
CORTO_AST_EXPORT cx_int16 ast_ParserNewDeinit(ast_ParserNew* value);

/* ::corto::ast::PostFix */
CORTO_AST_EXPORT ast_PostFix ast_PostFixCreate(ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT ast_PostFix ast_PostFixCreateChild(cx_object _parent, cx_string _name, ast_Expression lvalue, cx_operatorKind _operator);

CORTO_AST_EXPORT ast_PostFix ast_PostFixDeclare(void);
CORTO_AST_EXPORT ast_PostFix ast_PostFixDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_PostFixDefine(ast_PostFix _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_PostFixUpdate(ast_PostFix _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_PostFixSet(ast_PostFix _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT cx_string ast_PostFixStr(ast_PostFix value);
CORTO_AST_EXPORT ast_PostFix ast_PostFixFromStr(ast_PostFix value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_PostFixCopy(ast_PostFix *dst, ast_PostFix src);
CORTO_AST_EXPORT cx_int16 ast_PostFixCompare(ast_PostFix dst, ast_PostFix src);

/* ::corto::ast::SignedInteger */
CORTO_AST_EXPORT ast_SignedInteger ast_SignedIntegerCreate(cx_int64 value);
CORTO_AST_EXPORT ast_SignedInteger ast_SignedIntegerCreateChild(cx_object _parent, cx_string _name, cx_int64 value);

CORTO_AST_EXPORT ast_SignedInteger ast_SignedIntegerDeclare(void);
CORTO_AST_EXPORT ast_SignedInteger ast_SignedIntegerDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_SignedIntegerDefine(ast_SignedInteger _this, cx_int64 value);
CORTO_AST_EXPORT void ast_SignedIntegerUpdate(ast_SignedInteger _this, cx_int64 value);
CORTO_AST_EXPORT void ast_SignedIntegerSet(ast_SignedInteger _this, cx_int64 value);
CORTO_AST_EXPORT cx_string ast_SignedIntegerStr(ast_SignedInteger value);
CORTO_AST_EXPORT ast_SignedInteger ast_SignedIntegerFromStr(ast_SignedInteger value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_SignedIntegerCopy(ast_SignedInteger *dst, ast_SignedInteger src);
CORTO_AST_EXPORT cx_int16 ast_SignedIntegerCompare(ast_SignedInteger dst, ast_SignedInteger src);

/* ::corto::ast::StaticCall */
CORTO_AST_EXPORT ast_StaticCall ast_StaticCallCreate(ast_Expression instanceExpr, ast_Expression arguments, cx_function function);
CORTO_AST_EXPORT ast_StaticCall ast_StaticCallCreateChild(cx_object _parent, cx_string _name, ast_Expression instanceExpr, ast_Expression arguments, cx_function function);

CORTO_AST_EXPORT ast_StaticCall ast_StaticCallDeclare(void);
CORTO_AST_EXPORT ast_StaticCall ast_StaticCallDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_StaticCallDefine(ast_StaticCall _this, ast_Expression instanceExpr, ast_Expression arguments, cx_function function);
CORTO_AST_EXPORT void ast_StaticCallUpdate(ast_StaticCall _this, ast_Expression instanceExpr, ast_Expression arguments, cx_function function);
CORTO_AST_EXPORT void ast_StaticCallSet(ast_StaticCall _this, ast_Expression instanceExpr, ast_Expression arguments, cx_function function);
CORTO_AST_EXPORT cx_string ast_StaticCallStr(ast_StaticCall value);
CORTO_AST_EXPORT ast_StaticCall ast_StaticCallFromStr(ast_StaticCall value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_StaticCallCopy(ast_StaticCall *dst, ast_StaticCall src);
CORTO_AST_EXPORT cx_int16 ast_StaticCallCompare(ast_StaticCall dst, ast_StaticCall src);

/* ::corto::ast::StaticInitializer */
CORTO_AST_EXPORT ast_StaticInitializer ast_StaticInitializerCreate(ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT ast_StaticInitializer ast_StaticInitializerCreateChild(cx_object _parent, cx_string _name, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);

CORTO_AST_EXPORT ast_StaticInitializer ast_StaticInitializerDeclare(void);
CORTO_AST_EXPORT ast_StaticInitializer ast_StaticInitializerDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerDefine(ast_StaticInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT void ast_StaticInitializerUpdate(ast_StaticInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT void ast_StaticInitializerSet(ast_StaticInitializer _this, ast_InitializerVariableArray64 variables, cx_uint8 variableCount);
CORTO_AST_EXPORT cx_string ast_StaticInitializerStr(ast_StaticInitializer value);
CORTO_AST_EXPORT ast_StaticInitializer ast_StaticInitializerFromStr(ast_StaticInitializer value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerCopy(ast_StaticInitializer *dst, ast_StaticInitializer src);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerCompare(ast_StaticInitializer dst, ast_StaticInitializer src);

/* ::corto::ast::StaticInitializerFrame */
CORTO_AST_EXPORT ast_StaticInitializerFrame* ast_StaticInitializerFrameCreate(cx_wordArray64 ptr, cx_wordArray64 keyPtr);
CORTO_AST_EXPORT ast_StaticInitializerFrame* ast_StaticInitializerFrameCreateChild(cx_object _parent, cx_string _name, cx_wordArray64 ptr, cx_wordArray64 keyPtr);

CORTO_AST_EXPORT ast_StaticInitializerFrame* ast_StaticInitializerFrameDeclare(void);
CORTO_AST_EXPORT ast_StaticInitializerFrame* ast_StaticInitializerFrameDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerFrameDefine(ast_StaticInitializerFrame* _this, cx_wordArray64 ptr, cx_wordArray64 keyPtr);
CORTO_AST_EXPORT void ast_StaticInitializerFrameUpdate(ast_StaticInitializerFrame* _this, cx_wordArray64 ptr, cx_wordArray64 keyPtr);
CORTO_AST_EXPORT void ast_StaticInitializerFrameSet(ast_StaticInitializerFrame* _this, cx_wordArray64 ptr, cx_wordArray64 keyPtr);
CORTO_AST_EXPORT cx_string ast_StaticInitializerFrameStr(ast_StaticInitializerFrame* value);
CORTO_AST_EXPORT ast_StaticInitializerFrame* ast_StaticInitializerFrameFromStr(ast_StaticInitializerFrame* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerFrameCopy(ast_StaticInitializerFrame* *dst, ast_StaticInitializerFrame* src);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerFrameCompare(ast_StaticInitializerFrame* dst, ast_StaticInitializerFrame* src);

CORTO_AST_EXPORT cx_int16 ast_StaticInitializerFrameInit(ast_StaticInitializerFrame* value);
CORTO_AST_EXPORT cx_int16 ast_StaticInitializerFrameDeinit(ast_StaticInitializerFrame* value);

/* ::corto::ast::Storage */
CORTO_AST_EXPORT ast_Storage ast_StorageCreate(ast_storageKind kind_1);
CORTO_AST_EXPORT ast_Storage ast_StorageCreateChild(cx_object _parent, cx_string _name, ast_storageKind kind_1);

CORTO_AST_EXPORT ast_Storage ast_StorageDeclare(void);
CORTO_AST_EXPORT ast_Storage ast_StorageDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_StorageDefine(ast_Storage _this, ast_storageKind kind_1);
CORTO_AST_EXPORT void ast_StorageUpdate(ast_Storage _this, ast_storageKind kind_1);
CORTO_AST_EXPORT void ast_StorageSet(ast_Storage _this, ast_storageKind kind_1);
CORTO_AST_EXPORT cx_string ast_StorageStr(ast_Storage value);
CORTO_AST_EXPORT ast_Storage ast_StorageFromStr(ast_Storage value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_StorageCopy(ast_Storage *dst, ast_Storage src);
CORTO_AST_EXPORT cx_int16 ast_StorageCompare(ast_Storage dst, ast_Storage src);

/* ::corto::ast::storageKind */
CORTO_AST_EXPORT ast_storageKind* ast_storageKindCreate(ast_storageKind value);
CORTO_AST_EXPORT ast_storageKind* ast_storageKindCreateChild(cx_object _parent, cx_string _name, ast_storageKind value);

CORTO_AST_EXPORT ast_storageKind* ast_storageKindDeclare(void);
CORTO_AST_EXPORT ast_storageKind* ast_storageKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_storageKindDefine(ast_storageKind* _this, ast_storageKind value);
CORTO_AST_EXPORT void ast_storageKindUpdate(ast_storageKind* _this, ast_storageKind value);
CORTO_AST_EXPORT void ast_storageKindSet(ast_storageKind* _this, ast_storageKind value);
CORTO_AST_EXPORT cx_string ast_storageKindStr(ast_storageKind value);
CORTO_AST_EXPORT ast_storageKind* ast_storageKindFromStr(ast_storageKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_storageKindCopy(ast_storageKind* *dst, ast_storageKind* src);
CORTO_AST_EXPORT cx_int16 ast_storageKindCompare(ast_storageKind* dst, ast_storageKind* src);

CORTO_AST_EXPORT cx_int16 ast_storageKindInit(ast_storageKind* value);
CORTO_AST_EXPORT cx_int16 ast_storageKindDeinit(ast_storageKind* value);

/* ::corto::ast::String */
CORTO_AST_EXPORT ast_String ast_StringCreate(cx_string value);
CORTO_AST_EXPORT ast_String ast_StringCreateChild(cx_object _parent, cx_string _name, cx_string value);

CORTO_AST_EXPORT ast_String ast_StringDeclare(void);
CORTO_AST_EXPORT ast_String ast_StringDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_StringDefine(ast_String _this, cx_string value);
CORTO_AST_EXPORT void ast_StringUpdate(ast_String _this, cx_string value);
CORTO_AST_EXPORT void ast_StringSet(ast_String _this, cx_string value);
CORTO_AST_EXPORT cx_string ast_StringStr(ast_String value);
CORTO_AST_EXPORT ast_String ast_StringFromStr(ast_String value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_StringCopy(ast_String *dst, ast_String src);
CORTO_AST_EXPORT cx_int16 ast_StringCompare(ast_String dst, ast_String src);

/* ::corto::ast::Template */
CORTO_AST_EXPORT ast_Template ast_TemplateCreate(cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT ast_Template ast_TemplateCreateChild(cx_object _parent, cx_string _name, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);

CORTO_AST_EXPORT ast_Template ast_TemplateDeclare(void);
CORTO_AST_EXPORT ast_Template ast_TemplateDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_TemplateDefine(ast_Template _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT void ast_TemplateUpdate(ast_Template _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT void ast_TemplateSet(ast_Template _this, cx_string name, cx_type type_1, ast_LocalKind kind_2, cx_bool reference);
CORTO_AST_EXPORT cx_string ast_TemplateStr(ast_Template value);
CORTO_AST_EXPORT ast_Template ast_TemplateFromStr(ast_Template value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_TemplateCopy(ast_Template *dst, ast_Template src);
CORTO_AST_EXPORT cx_int16 ast_TemplateCompare(ast_Template dst, ast_Template src);

/* ::corto::ast::Temporary */
CORTO_AST_EXPORT ast_Temporary ast_TemporaryCreate(cx_type type_1, cx_bool reference);
CORTO_AST_EXPORT ast_Temporary ast_TemporaryCreateChild(cx_object _parent, cx_string _name, cx_type type_1, cx_bool reference);

CORTO_AST_EXPORT ast_Temporary ast_TemporaryDeclare(void);
CORTO_AST_EXPORT ast_Temporary ast_TemporaryDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_TemporaryDefine(ast_Temporary _this, cx_type type_1, cx_bool reference);
CORTO_AST_EXPORT void ast_TemporaryUpdate(ast_Temporary _this, cx_type type_1, cx_bool reference);
CORTO_AST_EXPORT void ast_TemporarySet(ast_Temporary _this, cx_type type_1, cx_bool reference);
CORTO_AST_EXPORT cx_string ast_TemporaryStr(ast_Temporary value);
CORTO_AST_EXPORT ast_Temporary ast_TemporaryFromStr(ast_Temporary value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_TemporaryCopy(ast_Temporary *dst, ast_Temporary src);
CORTO_AST_EXPORT cx_int16 ast_TemporaryCompare(ast_Temporary dst, ast_Temporary src);

/* ::corto::ast::Ternary */
CORTO_AST_EXPORT ast_Ternary ast_TernaryCreate(ast_Expression condition, ast_Expression ifTrue, ast_Expression ifFalse, ast_Expression result);
CORTO_AST_EXPORT ast_Ternary ast_TernaryCreateChild(cx_object _parent, cx_string _name, ast_Expression condition, ast_Expression ifTrue, ast_Expression ifFalse, ast_Expression result);

CORTO_AST_EXPORT ast_Ternary ast_TernaryDeclare(void);
CORTO_AST_EXPORT ast_Ternary ast_TernaryDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_TernaryDefine(ast_Ternary _this, ast_Expression condition, ast_Expression ifTrue, ast_Expression ifFalse, ast_Expression result);
CORTO_AST_EXPORT void ast_TernaryUpdate(ast_Ternary _this, ast_Expression condition, ast_Expression ifTrue, ast_Expression ifFalse, ast_Expression result);
CORTO_AST_EXPORT void ast_TernarySet(ast_Ternary _this, ast_Expression condition, ast_Expression ifTrue, ast_Expression ifFalse, ast_Expression result);
CORTO_AST_EXPORT cx_string ast_TernaryStr(ast_Ternary value);
CORTO_AST_EXPORT ast_Ternary ast_TernaryFromStr(ast_Ternary value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_TernaryCopy(ast_Ternary *dst, ast_Ternary src);
CORTO_AST_EXPORT cx_int16 ast_TernaryCompare(ast_Ternary dst, ast_Ternary src);

/* ::corto::ast::Unary */
CORTO_AST_EXPORT ast_Unary ast_UnaryCreate(ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT ast_Unary ast_UnaryCreateChild(cx_object _parent, cx_string _name, ast_Expression lvalue, cx_operatorKind _operator);

CORTO_AST_EXPORT ast_Unary ast_UnaryDeclare(void);
CORTO_AST_EXPORT ast_Unary ast_UnaryDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_UnaryDefine(ast_Unary _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_UnaryUpdate(ast_Unary _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT void ast_UnarySet(ast_Unary _this, ast_Expression lvalue, cx_operatorKind _operator);
CORTO_AST_EXPORT cx_string ast_UnaryStr(ast_Unary value);
CORTO_AST_EXPORT ast_Unary ast_UnaryFromStr(ast_Unary value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_UnaryCopy(ast_Unary *dst, ast_Unary src);
CORTO_AST_EXPORT cx_int16 ast_UnaryCompare(ast_Unary dst, ast_Unary src);

/* ::corto::ast::Update */
CORTO_AST_EXPORT ast_Update ast_UpdateCreate(ast_ExpressionList exprList, ast_Block block, ast_Expression from, ast_UpdateKind kind_1);
CORTO_AST_EXPORT ast_Update ast_UpdateCreateChild(cx_object _parent, cx_string _name, ast_ExpressionList exprList, ast_Block block, ast_Expression from, ast_UpdateKind kind_1);

CORTO_AST_EXPORT ast_Update ast_UpdateDeclare(void);
CORTO_AST_EXPORT ast_Update ast_UpdateDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_UpdateDefine(ast_Update _this, ast_ExpressionList exprList, ast_Block block, ast_Expression from, ast_UpdateKind kind_1);
CORTO_AST_EXPORT void ast_UpdateUpdate(ast_Update _this, ast_ExpressionList exprList, ast_Block block, ast_Expression from, ast_UpdateKind kind_1);
CORTO_AST_EXPORT void ast_UpdateSet(ast_Update _this, ast_ExpressionList exprList, ast_Block block, ast_Expression from, ast_UpdateKind kind_1);
CORTO_AST_EXPORT cx_string ast_UpdateStr(ast_Update value);
CORTO_AST_EXPORT ast_Update ast_UpdateFromStr(ast_Update value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_UpdateCopy(ast_Update *dst, ast_Update src);
CORTO_AST_EXPORT cx_int16 ast_UpdateCompare(ast_Update dst, ast_Update src);

/* ::corto::ast::UpdateKind */
CORTO_AST_EXPORT ast_UpdateKind* ast_UpdateKindCreate(ast_UpdateKind value);
CORTO_AST_EXPORT ast_UpdateKind* ast_UpdateKindCreateChild(cx_object _parent, cx_string _name, ast_UpdateKind value);

CORTO_AST_EXPORT ast_UpdateKind* ast_UpdateKindDeclare(void);
CORTO_AST_EXPORT ast_UpdateKind* ast_UpdateKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_UpdateKindDefine(ast_UpdateKind* _this, ast_UpdateKind value);
CORTO_AST_EXPORT void ast_UpdateKindUpdate(ast_UpdateKind* _this, ast_UpdateKind value);
CORTO_AST_EXPORT void ast_UpdateKindSet(ast_UpdateKind* _this, ast_UpdateKind value);
CORTO_AST_EXPORT cx_string ast_UpdateKindStr(ast_UpdateKind value);
CORTO_AST_EXPORT ast_UpdateKind* ast_UpdateKindFromStr(ast_UpdateKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_UpdateKindCopy(ast_UpdateKind* *dst, ast_UpdateKind* src);
CORTO_AST_EXPORT cx_int16 ast_UpdateKindCompare(ast_UpdateKind* dst, ast_UpdateKind* src);

CORTO_AST_EXPORT cx_int16 ast_UpdateKindInit(ast_UpdateKind* value);
CORTO_AST_EXPORT cx_int16 ast_UpdateKindDeinit(ast_UpdateKind* value);

/* ::corto::ast::valueKind */
CORTO_AST_EXPORT ast_valueKind* ast_valueKindCreate(ast_valueKind value);
CORTO_AST_EXPORT ast_valueKind* ast_valueKindCreateChild(cx_object _parent, cx_string _name, ast_valueKind value);

CORTO_AST_EXPORT ast_valueKind* ast_valueKindDeclare(void);
CORTO_AST_EXPORT ast_valueKind* ast_valueKindDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_valueKindDefine(ast_valueKind* _this, ast_valueKind value);
CORTO_AST_EXPORT void ast_valueKindUpdate(ast_valueKind* _this, ast_valueKind value);
CORTO_AST_EXPORT void ast_valueKindSet(ast_valueKind* _this, ast_valueKind value);
CORTO_AST_EXPORT cx_string ast_valueKindStr(ast_valueKind value);
CORTO_AST_EXPORT ast_valueKind* ast_valueKindFromStr(ast_valueKind* value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_valueKindCopy(ast_valueKind* *dst, ast_valueKind* src);
CORTO_AST_EXPORT cx_int16 ast_valueKindCompare(ast_valueKind* dst, ast_valueKind* src);

CORTO_AST_EXPORT cx_int16 ast_valueKindInit(ast_valueKind* value);
CORTO_AST_EXPORT cx_int16 ast_valueKindDeinit(ast_valueKind* value);

/* ::corto::ast::Wait */
CORTO_AST_EXPORT ast_Wait ast_WaitCreate(ast_ExpressionList exprList, ast_Expression timeout);
CORTO_AST_EXPORT ast_Wait ast_WaitCreateChild(cx_object _parent, cx_string _name, ast_ExpressionList exprList, ast_Expression timeout);

CORTO_AST_EXPORT ast_Wait ast_WaitDeclare(void);
CORTO_AST_EXPORT ast_Wait ast_WaitDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_WaitDefine(ast_Wait _this, ast_ExpressionList exprList, ast_Expression timeout);
CORTO_AST_EXPORT void ast_WaitUpdate(ast_Wait _this, ast_ExpressionList exprList, ast_Expression timeout);
CORTO_AST_EXPORT void ast_WaitSet(ast_Wait _this, ast_ExpressionList exprList, ast_Expression timeout);
CORTO_AST_EXPORT cx_string ast_WaitStr(ast_Wait value);
CORTO_AST_EXPORT ast_Wait ast_WaitFromStr(ast_Wait value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_WaitCopy(ast_Wait *dst, ast_Wait src);
CORTO_AST_EXPORT cx_int16 ast_WaitCompare(ast_Wait dst, ast_Wait src);

/* ::corto::ast::While */
CORTO_AST_EXPORT ast_While ast_WhileCreate(ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);
CORTO_AST_EXPORT ast_While ast_WhileCreateChild(cx_object _parent, cx_string _name, ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);

CORTO_AST_EXPORT ast_While ast_WhileDeclare(void);
CORTO_AST_EXPORT ast_While ast_WhileDeclareChild(cx_object _parent, cx_string _name);
CORTO_AST_EXPORT cx_int16 ast_WhileDefine(ast_While _this, ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);
CORTO_AST_EXPORT void ast_WhileUpdate(ast_While _this, ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);
CORTO_AST_EXPORT void ast_WhileSet(ast_While _this, ast_Expression condition, ast_Block trueBranch, cx_bool isUntil);
CORTO_AST_EXPORT cx_string ast_WhileStr(ast_While value);
CORTO_AST_EXPORT ast_While ast_WhileFromStr(ast_While value, cx_string str);
CORTO_AST_EXPORT cx_int16 ast_WhileCopy(ast_While *dst, ast_While src);
CORTO_AST_EXPORT cx_int16 ast_WhileCompare(ast_While dst, ast_While src);


/* <0x7fbb2af38308> */
#define ast_BindingListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ast_Binding *elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT ast_Binding* ast_BindingListInsertAlloc(ast_BindingList list);
CORTO_AST_EXPORT ast_Binding* ast_BindingListInsert(ast_BindingList list, ast_Binding* element);
CORTO_AST_EXPORT ast_Binding* ast_BindingListAppendAlloc(ast_BindingList list);
CORTO_AST_EXPORT ast_Binding* ast_BindingListAppend(ast_BindingList list, ast_Binding* element);
CORTO_AST_EXPORT ast_Binding* ast_BindingListTakeFirst(ast_BindingList list);
CORTO_AST_EXPORT ast_Binding* ast_BindingListLast(ast_BindingList list);
CORTO_AST_EXPORT void ast_BindingListClear(ast_BindingList list);
CORTO_AST_EXPORT ast_Binding* ast_BindingListGet(ast_BindingList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 ast_BindingListSize(ast_BindingList list);

/* <0x7fbb2aeb2368> */
#define ast_ExpressionListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ast_Expression elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT void ast_ExpressionListInsert(ast_ExpressionList list, ast_Expression element);
CORTO_AST_EXPORT void ast_ExpressionListAppend(ast_ExpressionList list, ast_Expression element);
CORTO_AST_EXPORT ast_Expression ast_ExpressionListTakeFirst(ast_ExpressionList list);
CORTO_AST_EXPORT ast_Expression ast_ExpressionListLast(ast_ExpressionList list);
CORTO_AST_EXPORT void ast_ExpressionListClear(ast_ExpressionList list);
CORTO_AST_EXPORT ast_Expression ast_ExpressionListGet(ast_ExpressionList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 ast_ExpressionListSize(ast_ExpressionList list);

/* <0x7fbb2af2edf8> */
#define ast_InitOperListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ast_InitOper *elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT ast_InitOper* ast_InitOperListInsertAlloc(ast_InitOperList list);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListInsert(ast_InitOperList list, ast_InitOper* element);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListAppendAlloc(ast_InitOperList list);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListAppend(ast_InitOperList list, ast_InitOper* element);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListTakeFirst(ast_InitOperList list);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListLast(ast_InitOperList list);
CORTO_AST_EXPORT void ast_InitOperListClear(ast_InitOperList list);
CORTO_AST_EXPORT ast_InitOper* ast_InitOperListGet(ast_InitOperList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 ast_InitOperListSize(ast_InitOperList list);

/* <0x7fbb2aec7318> */
#define ast_LocalListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ast_Local elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT void ast_LocalListInsert(ast_LocalList list, ast_Local element);
CORTO_AST_EXPORT void ast_LocalListAppend(ast_LocalList list, ast_Local element);
CORTO_AST_EXPORT ast_Local ast_LocalListTakeFirst(ast_LocalList list);
CORTO_AST_EXPORT ast_Local ast_LocalListLast(ast_LocalList list);
CORTO_AST_EXPORT void ast_LocalListClear(ast_LocalList list);
CORTO_AST_EXPORT ast_Local ast_LocalListGet(ast_LocalList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 ast_LocalListSize(ast_LocalList list);

/* <0x7fbb2aec6ab8> */
#define ast_NodeListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    ast_Node elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT void ast_NodeListInsert(ast_NodeList list, ast_Node element);
CORTO_AST_EXPORT void ast_NodeListAppend(ast_NodeList list, ast_Node element);
CORTO_AST_EXPORT ast_Node ast_NodeListTakeFirst(ast_NodeList list);
CORTO_AST_EXPORT ast_Node ast_NodeListLast(ast_NodeList list);
CORTO_AST_EXPORT void ast_NodeListClear(ast_NodeList list);
CORTO_AST_EXPORT ast_Node ast_NodeListGet(ast_NodeList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 ast_NodeListSize(ast_NodeList list);

/* ::corto::ast::ParserDeclarationSeq */
#define ast_ParserDeclarationSeqForeach(seq, elem) \
    cx_uint32 elem##_iter;\
    ast_ParserDeclaration elem;\
    for(elem##_iter=0; seq.buffer ? elem = seq.buffer[elem##_iter] : elem, elem##_iter<seq.length; elem##_iter++)\

CORTO_AST_EXPORT ast_ParserDeclaration* ast_ParserDeclarationSeqAppend(ast_ParserDeclarationSeq *seq);
CORTO_AST_EXPORT void ast_ParserDeclarationSeqSize(ast_ParserDeclarationSeq *seq, cx_uint32 length);
CORTO_AST_EXPORT void ast_ParserDeclarationSeqClear(ast_ParserDeclarationSeq *seq);

/* <0x7fbb2af024d8> */
#define cx_parameterSeqForeach(seq, elem) \
    cx_uint32 elem##_iter;\
    cx_parameter elem;\
    for(elem##_iter=0; seq.buffer ? elem = seq.buffer[elem##_iter] : elem, elem##_iter<seq.length; elem##_iter++)\

CORTO_AST_EXPORT cx_parameter* cx_parameterSeqAppend(cx_parameterSeq *seq);
CORTO_AST_EXPORT void cx_parameterSeqSize(cx_parameterSeq *seq, cx_uint32 length);
CORTO_AST_EXPORT void cx_parameterSeqClear(cx_parameterSeq *seq);

/* <0x7fbb2af39ae8> */
#define cx_objectListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    cx_object elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT void cx_objectListInsert(cx_objectList list, cx_object element);
CORTO_AST_EXPORT void cx_objectListAppend(cx_objectList list, cx_object element);
CORTO_AST_EXPORT cx_object cx_objectListTakeFirst(cx_objectList list);
CORTO_AST_EXPORT cx_object cx_objectListLast(cx_objectList list);
CORTO_AST_EXPORT void cx_objectListClear(cx_objectList list);
CORTO_AST_EXPORT cx_object cx_objectListGet(cx_objectList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 cx_objectListSize(cx_objectList list);

/* <0x7fbb2af39328> */
#define cx_wordListForeach(list, elem) \
    cx_iter elem##_iter = cx_llIter(list);\
    cx_word elem;\
    while(cx_iterHasNext(&elem##_iter) ? elem = (cx_word)(cx_word)cx_iterNext(&elem##_iter), TRUE : FALSE)

CORTO_AST_EXPORT void cx_wordListInsert(cx_wordList list, cx_word element);
CORTO_AST_EXPORT void cx_wordListAppend(cx_wordList list, cx_word element);
CORTO_AST_EXPORT cx_word cx_wordListTakeFirst(cx_wordList list);
CORTO_AST_EXPORT cx_word cx_wordListLast(cx_wordList list);
CORTO_AST_EXPORT void cx_wordListClear(cx_wordList list);
CORTO_AST_EXPORT cx_word cx_wordListGet(cx_wordList list, cx_uint32 index);
CORTO_AST_EXPORT cx_uint32 cx_wordListSize(cx_wordList list);

/* <0x7fbb2af3fd88> */
#define cx_stringSeqForeach(seq, elem) \
    cx_uint32 elem##_iter;\
    cx_string elem;\
    for(elem##_iter=0; seq.buffer ? elem = seq.buffer[elem##_iter] : elem, elem##_iter<seq.length; elem##_iter++)\

CORTO_AST_EXPORT cx_string* cx_stringSeqAppend(cx_stringSeq *seq);
CORTO_AST_EXPORT void cx_stringSeqSize(cx_stringSeq *seq, cx_uint32 length);
CORTO_AST_EXPORT void cx_stringSeqClear(cx_stringSeq *seq);

#ifdef __cplusplus
}
#endif
#endif

