/* ast_Local.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_LOCAL_H
#define CORTO_AST_LOCAL_H

#include "corto.h"
#include "ast_Storage.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Local::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Local_construct(ast_Local _this);
#define ast_Local_construct(_this) _ast_Local_construct(ast_Local(_this))

/* virtual ::corto::ast::Local::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Local_toIc(ast_Local _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Local_toIc(_this, program, storage, stored) _ast_Local_toIc(ast_Local(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Local::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Local_toIc_v(ast_Local _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Local_toIc_v(_this, program, storage, stored) _ast_Local_toIc_v(ast_Local(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

