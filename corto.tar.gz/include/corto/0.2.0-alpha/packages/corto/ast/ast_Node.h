/* ast_Node.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_NODE_H
#define CORTO_AST_NODE_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Node::init() */
CORTO_AST_EXPORT cx_int16 _ast_Node_init(ast_Node _this);
#define ast_Node_init(_this) _ast_Node_init(ast_Node(_this))

/* virtual ::corto::ast::Node::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Node_toIc(ast_Node _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Node_toIc(_this, program, storage, stored) _ast_Node_toIc(ast_Node(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Node::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Node_toIc_v(ast_Node _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Node_toIc_v(_this, program, storage, stored) _ast_Node_toIc_v(ast_Node(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

