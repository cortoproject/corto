/* ast_InitOper.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_INITOPER_H
#define CORTO_AST_INITOPER_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

