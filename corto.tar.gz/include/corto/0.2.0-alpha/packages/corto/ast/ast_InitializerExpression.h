/* ast_InitializerExpression.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_INITIALIZEREXPRESSION_H
#define CORTO_AST_INITIALIZEREXPRESSION_H

#include "corto.h"
#include "ast_Initializer.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::InitializerExpression::construct() */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_construct(ast_InitializerExpression _this);
#define ast_InitializerExpression_construct(_this) _ast_InitializerExpression_construct(ast_InitializerExpression(_this))

/* ::corto::ast::InitializerExpression::define() */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_define(ast_InitializerExpression _this);
#define ast_InitializerExpression_define(_this) _ast_InitializerExpression_define(ast_InitializerExpression(_this))

/* virtual ::corto::ast::InitializerExpression::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_InitializerExpression_hasReturnedResource(ast_InitializerExpression _this);
#define ast_InitializerExpression_hasReturnedResource(_this) _ast_InitializerExpression_hasReturnedResource(ast_InitializerExpression(_this))

/* ::corto::ast::InitializerExpression::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_InitializerExpression_hasReturnedResource_v(ast_InitializerExpression _this);
#define ast_InitializerExpression_hasReturnedResource_v(_this) _ast_InitializerExpression_hasReturnedResource_v(ast_InitializerExpression(_this))

/* ::corto::ast::InitializerExpression::insert(Expression variable) */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_insert(ast_InitializerExpression _this, ast_Expression variable);
#define ast_InitializerExpression_insert(_this, variable) _ast_InitializerExpression_insert(ast_InitializerExpression(_this), ast_Expression(variable))

/* ::corto::ast::InitializerExpression::member(string name) */
CORTO_AST_EXPORT cx_int32 _ast_InitializerExpression_member(ast_InitializerExpression _this, cx_string name);
#define ast_InitializerExpression_member(_this, name) _ast_InitializerExpression_member(ast_InitializerExpression(_this), name)

/* ::corto::ast::InitializerExpression::pop() */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_pop(ast_InitializerExpression _this);
#define ast_InitializerExpression_pop(_this) _ast_InitializerExpression_pop(ast_InitializerExpression(_this))

/* ::corto::ast::InitializerExpression::push() */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_push(ast_InitializerExpression _this);
#define ast_InitializerExpression_push(_this) _ast_InitializerExpression_push(ast_InitializerExpression(_this))

/* ::corto::ast::InitializerExpression::value(Expression v) */
CORTO_AST_EXPORT cx_int16 _ast_InitializerExpression_value(ast_InitializerExpression _this, ast_Expression v);
#define ast_InitializerExpression_value(_this, v) _ast_InitializerExpression_value(ast_InitializerExpression(_this), ast_Expression(v))

#ifdef __cplusplus
}
#endif
#endif

