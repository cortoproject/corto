/* ast_StaticInitializer.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_STATICINITIALIZER_H
#define CORTO_AST_STATICINITIALIZER_H

#include "corto.h"
#include "ast_Initializer.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::StaticInitializer::construct() */
CORTO_AST_EXPORT cx_int16 _ast_StaticInitializer_construct(ast_StaticInitializer _this);
#define ast_StaticInitializer_construct(_this) _ast_StaticInitializer_construct(ast_StaticInitializer(_this))

/* ::corto::ast::StaticInitializer::define() */
CORTO_AST_EXPORT cx_int16 _ast_StaticInitializer_define(ast_StaticInitializer _this);
#define ast_StaticInitializer_define(_this) _ast_StaticInitializer_define(ast_StaticInitializer(_this))

/* ::corto::ast::StaticInitializer::push() */
CORTO_AST_EXPORT cx_int16 _ast_StaticInitializer_push(ast_StaticInitializer _this);
#define ast_StaticInitializer_push(_this) _ast_StaticInitializer_push(ast_StaticInitializer(_this))

/* ::corto::ast::StaticInitializer::value(Expression v) */
CORTO_AST_EXPORT cx_int16 _ast_StaticInitializer_value(ast_StaticInitializer _this, ast_Expression v);
#define ast_StaticInitializer_value(_this, v) _ast_StaticInitializer_value(ast_StaticInitializer(_this), ast_Expression(v))

#ifdef __cplusplus
}
#endif
#endif

