/* ast_Define.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_DEFINE_H
#define CORTO_AST_DEFINE_H

#include "corto.h"
#include "ast_Node.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Define::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Define_construct(ast_Define _this);
#define ast_Define_construct(_this) _ast_Define_construct(ast_Define(_this))

/* virtual ::corto::ast::Define::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Define_toIc(ast_Define _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Define_toIc(_this, program, storage, stored) _ast_Define_toIc(ast_Define(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Define::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Define_toIc_v(ast_Define _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Define_toIc_v(_this, program, storage, stored) _ast_Define_toIc_v(ast_Define(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

