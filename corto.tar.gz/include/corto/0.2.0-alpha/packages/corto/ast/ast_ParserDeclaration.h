/* ast_ParserDeclaration.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_PARSERDECLARATION_H
#define CORTO_AST_PARSERDECLARATION_H

#include "corto.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

