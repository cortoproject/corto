/* ast_DynamicInitializer.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_DYNAMICINITIALIZER_H
#define CORTO_AST_DYNAMICINITIALIZER_H

#include "corto.h"
#include "ast_Initializer.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::DynamicInitializer::construct() */
CORTO_AST_EXPORT cx_int16 _ast_DynamicInitializer_construct(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_construct(_this) _ast_DynamicInitializer_construct(ast_DynamicInitializer(_this))

/* ::corto::ast::DynamicInitializer::define() */
CORTO_AST_EXPORT cx_int16 _ast_DynamicInitializer_define(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_define(_this) _ast_DynamicInitializer_define(ast_DynamicInitializer(_this))

/* virtual ::corto::ast::DynamicInitializer::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_DynamicInitializer_hasReturnedResource(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_hasReturnedResource(_this) _ast_DynamicInitializer_hasReturnedResource(ast_DynamicInitializer(_this))

/* ::corto::ast::DynamicInitializer::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_DynamicInitializer_hasReturnedResource_v(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_hasReturnedResource_v(_this) _ast_DynamicInitializer_hasReturnedResource_v(ast_DynamicInitializer(_this))

/* ::corto::ast::DynamicInitializer::pop() */
CORTO_AST_EXPORT cx_int16 _ast_DynamicInitializer_pop(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_pop(_this) _ast_DynamicInitializer_pop(ast_DynamicInitializer(_this))

/* ::corto::ast::DynamicInitializer::push() */
CORTO_AST_EXPORT cx_int16 _ast_DynamicInitializer_push(ast_DynamicInitializer _this);
#define ast_DynamicInitializer_push(_this) _ast_DynamicInitializer_push(ast_DynamicInitializer(_this))

/* ::corto::ast::DynamicInitializer::value(Expression v) */
CORTO_AST_EXPORT cx_int16 _ast_DynamicInitializer_value(ast_DynamicInitializer _this, ast_Expression v);
#define ast_DynamicInitializer_value(_this, v) _ast_DynamicInitializer_value(ast_DynamicInitializer(_this), ast_Expression(v))

#ifdef __cplusplus
}
#endif
#endif

