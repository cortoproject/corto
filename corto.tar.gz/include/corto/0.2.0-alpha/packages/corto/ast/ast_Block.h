/* ast_Block.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_BLOCK_H
#define CORTO_AST_BLOCK_H

#include "corto.h"
#include "ast_Node.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Block::addStatement(ast::Node statement) */
CORTO_AST_EXPORT cx_void _ast_Block_addStatement(ast_Block _this, ast_Node statement);
#define ast_Block_addStatement(_this, statement) _ast_Block_addStatement(ast_Block(_this), ast_Node(statement))

/* ::corto::ast::Block::declare(string id,type type,bool isParameter,bool isReference) */
CORTO_AST_EXPORT ast_Local _ast_Block_declare(ast_Block _this, cx_string id, cx_type type, cx_bool isParameter, cx_bool isReference);
#define ast_Block_declare(_this, id, type, isParameter, isReference) _ast_Block_declare(ast_Block(_this), id, cx_type(type), isParameter, isReference)

/* ::corto::ast::Block::declareReturnVariable(function function) */
CORTO_AST_EXPORT ast_Local _ast_Block_declareReturnVariable(ast_Block _this, cx_function function);
#define ast_Block_declareReturnVariable(_this, function) _ast_Block_declareReturnVariable(ast_Block(_this), cx_function(function))

/* ::corto::ast::Block::declareTemplate(string id,type type,bool isParameter,bool isReference) */
CORTO_AST_EXPORT ast_Template _ast_Block_declareTemplate(ast_Block _this, cx_string id, cx_type type, cx_bool isParameter, cx_bool isReference);
#define ast_Block_declareTemplate(_this, id, type, isParameter, isReference) _ast_Block_declareTemplate(ast_Block(_this), id, cx_type(type), isParameter, isReference)

/* ::corto::ast::Block::lookup(string id) */
CORTO_AST_EXPORT ast_Expression _ast_Block_lookup(ast_Block _this, cx_string id);
#define ast_Block_lookup(_this, id) _ast_Block_lookup(ast_Block(_this), id)

/* ::corto::ast::Block::lookupLocal(string id) */
CORTO_AST_EXPORT ast_Local _ast_Block_lookupLocal(ast_Block _this, cx_string id);
#define ast_Block_lookupLocal(_this, id) _ast_Block_lookupLocal(ast_Block(_this), id)

/* ::corto::ast::Block::resolve(string id) */
CORTO_AST_EXPORT ast_Expression _ast_Block_resolve(ast_Block _this, cx_string id);
#define ast_Block_resolve(_this, id) _ast_Block_resolve(ast_Block(_this), id)

/* ::corto::ast::Block::resolveLocal(string id) */
CORTO_AST_EXPORT ast_Local _ast_Block_resolveLocal(ast_Block _this, cx_string id);
#define ast_Block_resolveLocal(_this, id) _ast_Block_resolveLocal(ast_Block(_this), id)

/* ::corto::ast::Block::setFunction(function function */
CORTO_AST_EXPORT cx_void _ast_Block_setFunction(ast_Block _this, cx_function function);
#define ast_Block_setFunction(_this, function) _ast_Block_setFunction(ast_Block(_this), cx_function(function))

/* virtual ::corto::ast::Block::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Block_toIc(ast_Block _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Block_toIc(_this, program, storage, stored) _ast_Block_toIc(ast_Block(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Block::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Block_toIc_v(ast_Block _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Block_toIc_v(_this, program, storage, stored) _ast_Block_toIc_v(ast_Block(_this), ic_program(program), ic_storage(storage), stored)

/* virtual ::corto::ast::Block::toIcBody(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Block_toIcBody(ast_Block _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Block_toIcBody(_this, program, storage, stored) _ast_Block_toIcBody(ast_Block(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Block::toIcBody(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Block_toIcBody_v(ast_Block _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Block_toIcBody_v(_this, program, storage, stored) _ast_Block_toIcBody_v(ast_Block(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

