/* ast_Wait.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_WAIT_H
#define CORTO_AST_WAIT_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Wait::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Wait_construct(ast_Wait _this);
#define ast_Wait_construct(_this) _ast_Wait_construct(ast_Wait(_this))

/* virtual ::corto::ast::Wait::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Wait_hasReturnedResource(ast_Wait _this);
#define ast_Wait_hasReturnedResource(_this) _ast_Wait_hasReturnedResource(ast_Wait(_this))

/* ::corto::ast::Wait::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Wait_hasReturnedResource_v(ast_Wait _this);
#define ast_Wait_hasReturnedResource_v(_this) _ast_Wait_hasReturnedResource_v(ast_Wait(_this))

/* virtual ::corto::ast::Wait::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Wait_toIc(ast_Wait _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Wait_toIc(_this, program, storage, stored) _ast_Wait_toIc(ast_Wait(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Wait::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Wait_toIc_v(ast_Wait _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Wait_toIc_v(_this, program, storage, stored) _ast_Wait_toIc_v(ast_Wait(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

