/* ast_Character.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_CHARACTER_H
#define CORTO_AST_CHARACTER_H

#include "corto.h"
#include "ast_Literal.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Character::init() */
CORTO_AST_EXPORT cx_int16 _ast_Character_init(ast_Character _this);
#define ast_Character_init(_this) _ast_Character_init(ast_Character(_this))

/* ::corto::ast::Character::serialize(type dstType,word dst) */
CORTO_AST_EXPORT cx_int16 _ast_Character_serialize(ast_Character _this, cx_type dstType, cx_word dst);
#define ast_Character_serialize(_this, dstType, dst) _ast_Character_serialize(ast_Character(_this), cx_type(dstType), dst)

/* virtual ::corto::ast::Character::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Character_toIc(ast_Character _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Character_toIc(_this, program, storage, stored) _ast_Character_toIc(ast_Character(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Character::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Character_toIc_v(ast_Character _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Character_toIc_v(_this, program, storage, stored) _ast_Character_toIc_v(ast_Character(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

