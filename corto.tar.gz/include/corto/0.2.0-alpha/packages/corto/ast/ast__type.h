/* ast__type.h
 *
 * Type definitions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_ast__type_H
#define corto_ast__type_H

#include "corto.h"
#include "corto/ic/ic__type.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Casting macro's for classes */
#define ast_Binary(o) ((ast_Binary)cx_assertType((cx_type)ast_Binary_o, o))
#define ast_Binding(o) ((ast_Binding *)cx_assertType((cx_type)ast_Binding_o, o))
#define ast_Block(o) ((ast_Block)cx_assertType((cx_type)ast_Block_o, o))
#define ast_Boolean(o) ((ast_Boolean)cx_assertType((cx_type)ast_Boolean_o, o))
#define ast_Call(o) ((ast_Call)cx_assertType((cx_type)ast_Call_o, o))
#define ast_CallBuilder(o) ((ast_CallBuilder *)cx_assertType((cx_type)ast_CallBuilder_o, o))
#define ast_Cast(o) ((ast_Cast)cx_assertType((cx_type)ast_Cast_o, o))
#define ast_Character(o) ((ast_Character)cx_assertType((cx_type)ast_Character_o, o))
#define ast_Comma(o) ((ast_Comma)cx_assertType((cx_type)ast_Comma_o, o))
#define ast_Define(o) ((ast_Define)cx_assertType((cx_type)ast_Define_o, o))
#define ast_Deinit(o) ((ast_Deinit)cx_assertType((cx_type)ast_Deinit_o, o))
#define ast_DelegateCall(o) ((ast_DelegateCall)cx_assertType((cx_type)ast_DelegateCall_o, o))
#define ast_derefKind(o) ((ast_derefKind *)cx_assertType((cx_type)ast_derefKind_o, o))
#define ast_DynamicInitializer(o) ((ast_DynamicInitializer)cx_assertType((cx_type)ast_DynamicInitializer_o, o))
#define ast_DynamicInitializerFrame(o) ((ast_DynamicInitializerFrame *)cx_assertType((cx_type)ast_DynamicInitializerFrame_o, o))
#define ast_Element(o) ((ast_Element)cx_assertType((cx_type)ast_Element_o, o))
#define ast_Expression(o) ((ast_Expression)cx_assertType((cx_type)ast_Expression_o, o))
#define ast_FloatingPoint(o) ((ast_FloatingPoint)cx_assertType((cx_type)ast_FloatingPoint_o, o))
#define ast_If(o) ((ast_If)cx_assertType((cx_type)ast_If_o, o))
#define ast_Init(o) ((ast_Init)cx_assertType((cx_type)ast_Init_o, o))
#define ast_Initializer(o) ((ast_Initializer)cx_assertType((cx_type)ast_Initializer_o, o))
#define ast_InitializerExpression(o) ((ast_InitializerExpression)cx_assertType((cx_type)ast_InitializerExpression_o, o))
#define ast_InitializerFrame(o) ((ast_InitializerFrame *)cx_assertType((cx_type)ast_InitializerFrame_o, o))
#define ast_InitializerKind(o) ((ast_InitializerKind *)cx_assertType((cx_type)ast_InitializerKind_o, o))
#define ast_InitializerVariable(o) ((ast_InitializerVariable *)cx_assertType((cx_type)ast_InitializerVariable_o, o))
#define ast_InitOper(o) ((ast_InitOper *)cx_assertType((cx_type)ast_InitOper_o, o))
#define ast_InitOperKind(o) ((ast_InitOperKind *)cx_assertType((cx_type)ast_InitOperKind_o, o))
#define ast_Integer(o) ((ast_Integer)cx_assertType((cx_type)ast_Integer_o, o))
#define ast_Literal(o) ((ast_Literal)cx_assertType((cx_type)ast_Literal_o, o))
#define ast_Local(o) ((ast_Local)cx_assertType((cx_type)ast_Local_o, o))
#define ast_LocalKind(o) ((ast_LocalKind *)cx_assertType((cx_type)ast_LocalKind_o, o))
#define ast_Lvalue(o) ((ast_Lvalue *)cx_assertType((cx_type)ast_Lvalue_o, o))
#define ast_Member(o) ((ast_Member)cx_assertType((cx_type)ast_Member_o, o))
#define ast_New(o) ((ast_New)cx_assertType((cx_type)ast_New_o, o))
#define ast_Node(o) ((ast_Node)cx_assertType((cx_type)ast_Node_o, o))
#define ast_nodeKind(o) ((ast_nodeKind *)cx_assertType((cx_type)ast_nodeKind_o, o))
#define ast_Null(o) ((ast_Null)cx_assertType((cx_type)ast_Null_o, o))
#define ast_Object(o) ((ast_Object)cx_assertType((cx_type)ast_Object_o, o))
#define ast_Parser(o) ((ast_Parser)cx_assertType((cx_type)ast_Parser_o, o))
#define ast_Parser_stagedId(o) ((ast_Parser_stagedId *)cx_assertType((cx_type)ast_Parser_stagedId_o, o))
#define ast_ParserDeclaration(o) ((ast_ParserDeclaration *)cx_assertType((cx_type)ast_ParserDeclaration_o, o))
#define ast_ParserDeclarationSeq(o) ((ast_ParserDeclarationSeq *)cx_assertType((cx_type)ast_ParserDeclarationSeq_o, o))
#define ast_ParserNew(o) ((ast_ParserNew *)cx_assertType((cx_type)ast_ParserNew_o, o))
#define ast_PostFix(o) ((ast_PostFix)cx_assertType((cx_type)ast_PostFix_o, o))
#define ast_SignedInteger(o) ((ast_SignedInteger)cx_assertType((cx_type)ast_SignedInteger_o, o))
#define ast_StaticCall(o) ((ast_StaticCall)cx_assertType((cx_type)ast_StaticCall_o, o))
#define ast_StaticInitializer(o) ((ast_StaticInitializer)cx_assertType((cx_type)ast_StaticInitializer_o, o))
#define ast_StaticInitializerFrame(o) ((ast_StaticInitializerFrame *)cx_assertType((cx_type)ast_StaticInitializerFrame_o, o))
#define ast_Storage(o) ((ast_Storage)cx_assertType((cx_type)ast_Storage_o, o))
#define ast_storageKind(o) ((ast_storageKind *)cx_assertType((cx_type)ast_storageKind_o, o))
#define ast_String(o) ((ast_String)cx_assertType((cx_type)ast_String_o, o))
#define ast_Template(o) ((ast_Template)cx_assertType((cx_type)ast_Template_o, o))
#define ast_Temporary(o) ((ast_Temporary)cx_assertType((cx_type)ast_Temporary_o, o))
#define ast_Ternary(o) ((ast_Ternary)cx_assertType((cx_type)ast_Ternary_o, o))
#define ast_Unary(o) ((ast_Unary)cx_assertType((cx_type)ast_Unary_o, o))
#define ast_Update(o) ((ast_Update)cx_assertType((cx_type)ast_Update_o, o))
#define ast_UpdateKind(o) ((ast_UpdateKind *)cx_assertType((cx_type)ast_UpdateKind_o, o))
#define ast_valueKind(o) ((ast_valueKind *)cx_assertType((cx_type)ast_valueKind_o, o))
#define ast_Wait(o) ((ast_Wait)cx_assertType((cx_type)ast_Wait_o, o))
#define ast_While(o) ((ast_While)cx_assertType((cx_type)ast_While_o, o))

/* Type definitions */
/* ::corto::ast::nodeKind */
typedef enum ast_nodeKind {
    Ast_BinaryExpr = 0,
    Ast_CallExpr = 1,
    Ast_CastExpr = 2,
    Ast_CommaExpr = 3,
    Ast_DeclarationExpr = 4,
    Ast_DeclareExpr = 5,
    Ast_DefineExpr = 6,
    Ast_InitExpr = 7,
    Ast_DeinitExpr = 8,
    Ast_IfExpr = 9,
    Ast_InitializerExpr = 10,
    Ast_LiteralExpr = 11,
    Ast_MethodExpr = 12,
    Ast_NewExpr = 13,
    Ast_PostfixExpr = 14,
    Ast_TernaryExpr = 15,
    Ast_UnaryExpr = 16,
    Ast_UpdateExpr = 17,
    Ast_StorageExpr = 18,
    Ast_WaitExpr = 19,
    Ast_WhileExpr = 20
} ast_nodeKind;

/*  ::corto::ast::Node */
CX_CLASS(ast_Node);

CX_CLASS_DEF(ast_Node) {
    ast_nodeKind kind;
    cx_uint32 line;
    cx_uint32 column;
};

/* ::corto::ast::derefKind */
typedef enum ast_derefKind {
    Ast_ByValue = 0,
    Ast_ByReference = 1
} ast_derefKind;

/*  ::corto::ast::Expression */
CX_CLASS(ast_Expression);

CX_CLASS_DEF(ast_Expression) {
    CX_EXTEND(ast_Node);
    cx_type type;
    cx_bool isReference;
    ast_derefKind deref;
};

/*  ::corto::ast::Binary */
CX_CLASS(ast_Binary);

CX_CLASS_DEF(ast_Binary) {
    CX_EXTEND(ast_Expression);
    ast_Expression lvalue;
    ast_Expression rvalue;
    cx_operatorKind _operator;
    ast_derefKind deref;
    cx_bool isScalar;
};

/*  ::corto::ast::Block */
CX_CLASS(ast_Block);

CX_LIST(ast_NodeList);

/* ::corto::ast::storageKind */
typedef enum ast_storageKind {
    Ast_LocalStorage = 0,
    Ast_ObjectStorage = 1,
    Ast_MemberStorage = 2,
    Ast_ElementStorage = 3,
    Ast_TemporaryStorage = 4,
    Ast_TemplateStorage = 5
} ast_storageKind;

/*  ::corto::ast::Storage */
CX_CLASS(ast_Storage);

CX_CLASS_DEF(ast_Storage) {
    CX_EXTEND(ast_Expression);
    ast_storageKind kind;
};

/* ::corto::ast::LocalKind */
typedef enum ast_LocalKind {
    Ast_LocalDefault = 0,
    Ast_LocalParameter = 1,
    Ast_LocalReturn = 2
} ast_LocalKind;

/*  ::corto::ast::Local */
CX_CLASS(ast_Local);

CX_CLASS_DEF(ast_Local) {
    CX_EXTEND(ast_Storage);
    cx_string name;
    cx_type type;
    ast_LocalKind kind;
    cx_bool reference;
};

CX_LIST(ast_LocalList);

/*  ::corto::ast::While */
CX_CLASS(ast_While);

CX_CLASS_DEF(ast_While) {
    CX_EXTEND(ast_Node);
    ast_Expression condition;
    ast_Block trueBranch;
    cx_bool isUntil;
};

CX_CLASS_DEF(ast_Block) {
    CX_EXTEND(ast_Node);
    ast_Block parent;
    cx_bool isRoot;
    ast_NodeList statements;
    ast_LocalList locals;
    cx_function function;
    ast_While _while;
};

/*  ::corto::ast::Binding */
typedef struct ast_Binding ast_Binding;

struct ast_Binding {
    cx_function function;
    ast_Block impl;
};

/* ::corto::ast::valueKind */
typedef enum ast_valueKind {
    Ast_Bool = 0,
    Ast_Char = 1,
    Ast_Int = 2,
    Ast_SignedInt = 3,
    Ast_Float = 4,
    Ast_Text = 5,
    Ast_Enum = 6,
    Ast_Ref = 7,
    Ast_Nothing = 8
} ast_valueKind;

/*  ::corto::ast::Literal */
CX_CLASS(ast_Literal);

CX_CLASS_DEF(ast_Literal) {
    CX_EXTEND(ast_Expression);
    ast_valueKind kind;
};

/*  ::corto::ast::Boolean */
CX_CLASS(ast_Boolean);

CX_CLASS_DEF(ast_Boolean) {
    CX_EXTEND(ast_Literal);
    cx_bool value;
};

#ifndef cx_parameterSeq_DEFINED
#define cx_parameterSeq_DEFINED
CX_SEQUENCE(cx_parameterSeq, cx_parameter,);
#endif

/*  ::corto::ast::Call */
CX_CLASS(ast_Call);

CX_CLASS_DEF(ast_Call) {
    CX_EXTEND(ast_Expression);
    ast_Expression instanceExpr;
    ast_Expression arguments;
    ast_Expression functionExpr;
    cx_bool instanceIsAny;
    cx_type returnType;
    cx_bool returnsReference;
    cx_parameterSeq parameters;
    cx_bool overloaded;
};

/*  ::corto::ast::CallBuilder */
typedef struct ast_CallBuilder ast_CallBuilder;

struct ast_CallBuilder {
    cx_string name;
    ast_Expression arguments;
    ast_Expression instance;
    cx_object scope;
    ast_Block block;
    cx_bool overloaded;
    cx_string signature;
};

/*  ::corto::ast::Cast */
CX_CLASS(ast_Cast);

CX_CLASS_DEF(ast_Cast) {
    CX_EXTEND(ast_Expression);
    cx_type lvalue;
    ast_Expression rvalue;
    cx_bool isReference;
};

/*  ::corto::ast::Character */
CX_CLASS(ast_Character);

CX_CLASS_DEF(ast_Character) {
    CX_EXTEND(ast_Literal);
    cx_char value;
};

CX_LIST(ast_ExpressionList);

/*  ::corto::ast::Comma */
CX_CLASS(ast_Comma);

CX_CLASS_DEF(ast_Comma) {
    CX_EXTEND(ast_Expression);
    ast_ExpressionList expressions;
};

/*  ::corto::ast::Define */
CX_CLASS(ast_Define);

CX_CLASS_DEF(ast_Define) {
    CX_EXTEND(ast_Node);
    ast_Expression object;
};

/*  ::corto::ast::Deinit */
CX_CLASS(ast_Deinit);

CX_CLASS_DEF(ast_Deinit) {
    CX_EXTEND(ast_Expression);
    ast_Storage storage;
};

/*  ::corto::ast::DelegateCall */
CX_CLASS(ast_DelegateCall);

CX_CLASS_DEF(ast_DelegateCall) {
    CX_EXTEND(ast_Call);
    ast_Expression expr;
};

/*  ::corto::ast::InitializerVariable */
typedef struct ast_InitializerVariable ast_InitializerVariable;

struct ast_InitializerVariable {
    cx_word offset;
    ast_Expression object;
    cx_word key;
};

typedef ast_InitializerVariable ast_InitializerVariableArray64[64];

/*  ::corto::ast::InitializerFrame */
typedef struct ast_InitializerFrame ast_InitializerFrame;

struct ast_InitializerFrame {
    cx_uint32 location;
    cx_type type;
    cx_bool isKey;
    cx_member member;
};

typedef ast_InitializerFrame ast_InitializerFrameArray64[64];

/*  ::corto::ast::Initializer */
CX_CLASS(ast_Initializer);

CX_CLASS_DEF(ast_Initializer) {
    CX_EXTEND(ast_Expression);
    ast_InitializerVariableArray64 variables;
    cx_uint8 variableCount;
    ast_InitializerFrameArray64 frames;
    cx_uint8 fp;
};

typedef ast_Expression ast_ExpressionArray64[64];

/*  ::corto::ast::Integer */
CX_CLASS(ast_Integer);

CX_CLASS_DEF(ast_Integer) {
    CX_EXTEND(ast_Literal);
    cx_uint64 value;
};

/*  ::corto::ast::DynamicInitializerFrame */
typedef struct ast_DynamicInitializerFrame ast_DynamicInitializerFrame;

struct ast_DynamicInitializerFrame {
    ast_ExpressionArray64 expr;
    ast_ExpressionArray64 keyExpr;
    ast_Integer sequenceSize;
};

typedef ast_DynamicInitializerFrame ast_DynamicInitializerFrameArray64[64];

/*  ::corto::ast::DynamicInitializer */
CX_CLASS(ast_DynamicInitializer);

CX_CLASS_DEF(ast_DynamicInitializer) {
    CX_EXTEND(ast_Initializer);
    cx_bool assignValue;
    ast_DynamicInitializerFrameArray64 frames;
};

/*  ::corto::ast::Element */
CX_CLASS(ast_Element);

CX_CLASS_DEF(ast_Element) {
    CX_EXTEND(ast_Storage);
    ast_Expression lvalue;
    ast_Expression rvalue;
};

/*  ::corto::ast::FloatingPoint */
CX_CLASS(ast_FloatingPoint);

CX_CLASS_DEF(ast_FloatingPoint) {
    CX_EXTEND(ast_Literal);
    cx_float64 value;
};

/*  ::corto::ast::If */
CX_CLASS(ast_If);

CX_CLASS_DEF(ast_If) {
    CX_EXTEND(ast_Node);
    ast_Expression condition;
    ast_Block trueBranch;
    ast_If falseBranch;
    cx_bool warnUnreachable;
};

/*  ::corto::ast::Init */
CX_CLASS(ast_Init);

CX_CLASS_DEF(ast_Init) {
    CX_EXTEND(ast_Expression);
    ast_Storage storage;
};

/* ::corto::ast::InitOperKind */
typedef enum ast_InitOperKind {
    Ast_InitOpPush = 0,
    Ast_InitOpPop = 1,
    Ast_InitOpDefine = 2,
    Ast_InitOpValue = 3,
    Ast_InitOpMember = 4
} ast_InitOperKind;

/*  ::corto::ast::InitOper */
typedef struct ast_InitOper ast_InitOper;

struct ast_InitOper {
    ast_InitOperKind kind;
    ast_Expression expr;
    cx_string name;
};

CX_LIST(ast_InitOperList);

/*  ::corto::ast::InitializerExpression */
CX_CLASS(ast_InitializerExpression);

CX_CLASS_DEF(ast_InitializerExpression) {
    CX_EXTEND(ast_Initializer);
    cx_bool assignValue;
    ast_InitOperList operations;
};

/* ::corto::ast::InitializerKind */
typedef enum ast_InitializerKind {
    Ast_InitStatic = 0,
    Ast_InitDynamic = 1,
    Ast_InitExpression = 2
} ast_InitializerKind;

/*  ::corto::ast::Lvalue */
typedef struct ast_Lvalue ast_Lvalue;

struct ast_Lvalue {
    ast_Expression expr;
    cx_bool isAssignment;
};

/*  ::corto::ast::Member */
CX_CLASS(ast_Member);

CX_CLASS_DEF(ast_Member) {
    CX_EXTEND(ast_Storage);
    ast_Expression lvalue;
    ast_Expression rvalue;
    cx_bool superMember;
    cx_object member;
};

/*  ::corto::ast::New */
CX_CLASS(ast_New);

CX_CLASS_DEF(ast_New) {
    CX_EXTEND(ast_Expression);
    cx_type type;
    ast_Expression attributes;
};

/*  ::corto::ast::Null */
CX_CLASS(ast_Null);

CX_CLASS_DEF(ast_Null) {
    CX_EXTEND(ast_Literal);
};

/*  ::corto::ast::Object */
CX_CLASS(ast_Object);

CX_CLASS_DEF(ast_Object) {
    CX_EXTEND(ast_Storage);
    cx_object value;
};

CX_LIST(ast_BindingList);

CX_LIST(cx_wordList);

CX_LIST(cx_objectList);

typedef ast_Storage ast_StorageArray64[64];

typedef ast_Initializer ast_InitializerArray64[64];

/*  ::corto::ast::Parser::stagedId */
typedef struct ast_Parser_stagedId ast_Parser_stagedId;

struct ast_Parser_stagedId {
    cx_string name;
    cx_bool found;
    cx_uint32 line;
    cx_uint32 column;
};

typedef ast_Parser_stagedId ast_Parser_stagedIdArray64[64];

typedef ast_Lvalue ast_LvalueArray64[64];

typedef cx_type cx_typeArray64[64];

/*  ::corto::ast::Parser */
CX_CLASS(ast_Parser);

CX_CLASS_DEF(ast_Parser) {
    cx_string source;
    cx_string preprocessed;
    cx_string filename;
    cx_uint32 repl;
    cx_uint32 line;
    cx_uint32 column;
    cx_string token;
    ast_Block block;
    cx_uint32 blockCount;
    cx_object scope;
    cx_uint32 errors;
    cx_uint32 warnings;
    cx_bool errSet;
    cx_uint32 errLine;
    cx_bool abort;
    ast_BindingList bindings;
    cx_uint32 pass;
    cx_wordList heapCollected;
    cx_objectList collected;
    cx_bool blockPreset;
    cx_bool isLocal;
    cx_bool parseSingleExpr;
    ast_Expression singleExpr;
    cx_string lastFailedResolve;
    ast_StorageArray64 variables;
    cx_uint32 variableCount;
    cx_bool variablesInitialized;
    cx_bool variablePushed;
    ast_InitializerArray64 initializers;
    cx_int8 initializerCount;
    cx_uint32 initAnonymousId;
    cx_bool initDynamic;
    ast_Parser_stagedIdArray64 staged;
    cx_uint32 stagedCount;
    cx_bool stagingAllowed;
    ast_LvalueArray64 lvalue;
    cx_int32 lvalueSp;
    cx_typeArray64 complexType;
    cx_int32 complexTypeSp;
};

#ifndef cx_stringSeq_DEFINED
#define cx_stringSeq_DEFINED
CX_SEQUENCE(cx_stringSeq, cx_string,);
#endif

/*  ::corto::ast::ParserDeclaration */
typedef struct ast_ParserDeclaration ast_ParserDeclaration;

struct ast_ParserDeclaration {
    cx_string name;
    ast_Storage storage;
};

CX_SEQUENCE(ast_ParserDeclarationSeq, ast_ParserDeclaration,);

/*  ::corto::ast::ParserNew */
typedef struct ast_ParserNew ast_ParserNew;

struct ast_ParserNew {
    ast_nodeKind kind;
    ast_Expression parent;
    ast_Expression name;
    ast_Expression attr;
};

/*  ::corto::ast::PostFix */
CX_CLASS(ast_PostFix);

CX_CLASS_DEF(ast_PostFix) {
    CX_EXTEND(ast_Expression);
    ast_Expression lvalue;
    cx_operatorKind _operator;
};

/*  ::corto::ast::SignedInteger */
CX_CLASS(ast_SignedInteger);

CX_CLASS_DEF(ast_SignedInteger) {
    CX_EXTEND(ast_Literal);
    cx_int64 value;
};

/*  ::corto::ast::StaticCall */
CX_CLASS(ast_StaticCall);

CX_CLASS_DEF(ast_StaticCall) {
    CX_EXTEND(ast_Call);
    cx_function function;
};

typedef cx_word cx_wordArray64[64];

/*  ::corto::ast::StaticInitializerFrame */
typedef struct ast_StaticInitializerFrame ast_StaticInitializerFrame;

struct ast_StaticInitializerFrame {
    cx_wordArray64 ptr;
    cx_wordArray64 keyPtr;
};

typedef ast_StaticInitializerFrame ast_StaticInitializerFrameArray64[64];

/*  ::corto::ast::StaticInitializer */
CX_CLASS(ast_StaticInitializer);

CX_CLASS_DEF(ast_StaticInitializer) {
    CX_EXTEND(ast_Initializer);
    ast_StaticInitializerFrameArray64 frames;
};

/*  ::corto::ast::String */
CX_CLASS(ast_String);

CX_CLASS_DEF(ast_String) {
    CX_EXTEND(ast_Literal);
    cx_string value;
    ast_ExpressionList elements;
    ast_Block block;
    cx_object scope;
};

/*  ::corto::ast::Template */
CX_CLASS(ast_Template);

CX_CLASS_DEF(ast_Template) {
    CX_EXTEND(ast_Local);
};

/*  ::corto::ast::Temporary */
CX_CLASS(ast_Temporary);

CX_CLASS_DEF(ast_Temporary) {
    CX_EXTEND(ast_Storage);
    cx_type type;
    cx_bool reference;
    ast_Temporary proxy;
    ic_node ic;
};

/*  ::corto::ast::Ternary */
CX_CLASS(ast_Ternary);

CX_CLASS_DEF(ast_Ternary) {
    CX_EXTEND(ast_Expression);
    ast_Expression condition;
    ast_Expression ifTrue;
    ast_Expression ifFalse;
    ast_Expression ifTrueExpr;
    ast_Expression ifFalseExpr;
    ast_Expression result;
    ast_If ifstmt;
};

/*  ::corto::ast::Unary */
CX_CLASS(ast_Unary);

CX_CLASS_DEF(ast_Unary) {
    CX_EXTEND(ast_Expression);
    ast_Expression lvalue;
    cx_operatorKind _operator;
};

/* ::corto::ast::UpdateKind */
typedef enum ast_UpdateKind {
    Ast_UpdateDefault = 0,
    Ast_UpdateBegin = 1,
    Ast_UpdateEnd = 2
} ast_UpdateKind;

/*  ::corto::ast::Update */
CX_CLASS(ast_Update);

CX_CLASS_DEF(ast_Update) {
    CX_EXTEND(ast_Node);
    ast_ExpressionList exprList;
    ast_Block block;
    ast_Expression from;
    ast_UpdateKind kind;
};

/*  ::corto::ast::Wait */
CX_CLASS(ast_Wait);

CX_CLASS_DEF(ast_Wait) {
    CX_EXTEND(ast_Expression);
    ast_ExpressionList exprList;
    ast_Expression timeout;
};

#ifdef __cplusplus
}
#endif
#endif

