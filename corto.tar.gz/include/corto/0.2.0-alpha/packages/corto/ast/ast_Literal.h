/* ast_Literal.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_LITERAL_H
#define CORTO_AST_LITERAL_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* virtual ::corto::ast::Literal::getValue() */
CORTO_AST_EXPORT cx_word _ast_Literal_getValue(ast_Literal _this);
#define ast_Literal_getValue(_this) _ast_Literal_getValue(ast_Literal(_this))

/* ::corto::ast::Literal::getValue() */
CORTO_AST_EXPORT cx_word _ast_Literal_getValue_v(ast_Literal _this);
#define ast_Literal_getValue_v(_this) _ast_Literal_getValue_v(ast_Literal(_this))

/* ::corto::ast::Literal::init() */
CORTO_AST_EXPORT cx_int16 _ast_Literal_init(ast_Literal _this);
#define ast_Literal_init(_this) _ast_Literal_init(ast_Literal(_this))

#ifdef __cplusplus
}
#endif
#endif

