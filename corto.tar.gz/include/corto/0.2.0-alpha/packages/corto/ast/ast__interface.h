/* ast__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_AST
#include "ast__type.h"
#include "ast__api.h"
#include "ast__meta.h"
#else
#include "corto/ast/ast__type.h"
#include "corto/ast/ast__api.h"
#include "corto/ast/ast__meta.h"
#endif

#if BUILDING_CORTO_AST && defined _MSC_VER
#define CORTO_AST_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_AST
#define CORTO_AST_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_AST_EXPORT __declspec(dllimport)
#else
#define CORTO_AST_EXPORT
#endif

