/* ast_Comma.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_COMMA_H
#define CORTO_AST_COMMA_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Comma::addExpression(Expression expr) */
CORTO_AST_EXPORT cx_int16 _ast_Comma_addExpression(ast_Comma _this, ast_Expression expr);
#define ast_Comma_addExpression(_this, expr) _ast_Comma_addExpression(ast_Comma(_this), ast_Expression(expr))

/* ::corto::ast::Comma::addOrCreate(Expression list,Expression expr) */
CORTO_AST_EXPORT ast_Expression _ast_Comma_addOrCreate(ast_Expression list, ast_Expression expr);
#define ast_Comma_addOrCreate(list, expr) _ast_Comma_addOrCreate(ast_Expression(list), ast_Expression(expr))

/* ::corto::ast::Comma::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Comma_construct(ast_Comma _this);
#define ast_Comma_construct(_this) _ast_Comma_construct(ast_Comma(_this))

/* virtual ::corto::ast::Comma::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Comma_hasReturnedResource(ast_Comma _this);
#define ast_Comma_hasReturnedResource(_this) _ast_Comma_hasReturnedResource(ast_Comma(_this))

/* ::corto::ast::Comma::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Comma_hasReturnedResource_v(ast_Comma _this);
#define ast_Comma_hasReturnedResource_v(_this) _ast_Comma_hasReturnedResource_v(ast_Comma(_this))

/* virtual ::corto::ast::Comma::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Comma_hasSideEffects(ast_Comma _this);
#define ast_Comma_hasSideEffects(_this) _ast_Comma_hasSideEffects(ast_Comma(_this))

/* ::corto::ast::Comma::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Comma_hasSideEffects_v(ast_Comma _this);
#define ast_Comma_hasSideEffects_v(_this) _ast_Comma_hasSideEffects_v(ast_Comma(_this))

/* ::corto::ast::Comma::init() */
CORTO_AST_EXPORT cx_int16 _ast_Comma_init(ast_Comma _this);
#define ast_Comma_init(_this) _ast_Comma_init(ast_Comma(_this))

/* ::corto::ast::Comma::insertOrCreate(Expression list,Expression expr) */
CORTO_AST_EXPORT ast_Expression _ast_Comma_insertOrCreate(ast_Expression list, ast_Expression expr);
#define ast_Comma_insertOrCreate(list, expr) _ast_Comma_insertOrCreate(ast_Expression(list), ast_Expression(expr))

/* virtual ::corto::ast::Comma::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Comma_toIc(ast_Comma _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Comma_toIc(_this, program, storage, stored) _ast_Comma_toIc(ast_Comma(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Comma::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Comma_toIc_v(ast_Comma _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Comma_toIc_v(_this, program, storage, stored) _ast_Comma_toIc_v(ast_Comma(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Comma::toList() */
CORTO_AST_EXPORT ast_NodeList _ast_Comma_toList(ast_Comma _this);
#define ast_Comma_toList(_this) _ast_Comma_toList(ast_Comma(_this))

#ifdef __cplusplus
}
#endif
#endif

