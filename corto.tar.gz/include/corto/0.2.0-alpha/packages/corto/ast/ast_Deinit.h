/* ast_Deinit.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_DEINIT_H
#define CORTO_AST_DEINIT_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Deinit::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Deinit_construct(ast_Deinit _this);
#define ast_Deinit_construct(_this) _ast_Deinit_construct(ast_Deinit(_this))

/* virtual ::corto::ast::Deinit::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Deinit_toIc(ast_Deinit _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Deinit_toIc(_this, program, storage, stored) _ast_Deinit_toIc(ast_Deinit(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Deinit::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Deinit_toIc_v(ast_Deinit _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Deinit_toIc_v(_this, program, storage, stored) _ast_Deinit_toIc_v(ast_Deinit(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

