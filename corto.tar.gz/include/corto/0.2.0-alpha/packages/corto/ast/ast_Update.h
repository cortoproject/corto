/* ast_Update.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_UPDATE_H
#define CORTO_AST_UPDATE_H

#include "corto.h"
#include "ast_Node.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Update::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Update_construct(ast_Update _this);
#define ast_Update_construct(_this) _ast_Update_construct(ast_Update(_this))

/* virtual ::corto::ast::Update::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Update_toIc(ast_Update _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Update_toIc(_this, program, storage, stored) _ast_Update_toIc(ast_Update(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Update::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Update_toIc_v(ast_Update _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Update_toIc_v(_this, program, storage, stored) _ast_Update_toIc_v(ast_Update(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

