/* ast_Binary.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_BINARY_H
#define CORTO_AST_BINARY_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Binary::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Binary_construct(ast_Binary _this);
#define ast_Binary_construct(_this) _ast_Binary_construct(ast_Binary(_this))

/* ::corto::ast::Binary::fold() */
CORTO_AST_EXPORT ast_Expression _ast_Binary_fold(ast_Binary _this);
#define ast_Binary_fold(_this) _ast_Binary_fold(ast_Binary(_this))

/* virtual ::corto::ast::Binary::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Binary_hasReturnedResource(ast_Binary _this);
#define ast_Binary_hasReturnedResource(_this) _ast_Binary_hasReturnedResource(ast_Binary(_this))

/* ::corto::ast::Binary::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Binary_hasReturnedResource_v(ast_Binary _this);
#define ast_Binary_hasReturnedResource_v(_this) _ast_Binary_hasReturnedResource_v(ast_Binary(_this))

/* virtual ::corto::ast::Binary::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Binary_hasSideEffects(ast_Binary _this);
#define ast_Binary_hasSideEffects(_this) _ast_Binary_hasSideEffects(ast_Binary(_this))

/* ::corto::ast::Binary::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Binary_hasSideEffects_v(ast_Binary _this);
#define ast_Binary_hasSideEffects_v(_this) _ast_Binary_hasSideEffects_v(ast_Binary(_this))

/* ::corto::ast::Binary::setOperator(operatorKind kind) */
CORTO_AST_EXPORT cx_void _ast_Binary_setOperator(ast_Binary _this, cx_operatorKind kind);
#define ast_Binary_setOperator(_this, kind) _ast_Binary_setOperator(ast_Binary(_this), kind)

/* virtual ::corto::ast::Binary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Binary_toIc(ast_Binary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Binary_toIc(_this, program, storage, stored) _ast_Binary_toIc(ast_Binary(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Binary::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Binary_toIc_v(ast_Binary _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Binary_toIc_v(_this, program, storage, stored) _ast_Binary_toIc_v(ast_Binary(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

