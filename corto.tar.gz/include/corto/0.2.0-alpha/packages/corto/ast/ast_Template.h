/* ast_Template.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_TEMPLATE_H
#define CORTO_AST_TEMPLATE_H

#include "corto.h"
#include "ast_Local.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Template::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Template_construct(ast_Template _this);
#define ast_Template_construct(_this) _ast_Template_construct(ast_Template(_this))

#ifdef __cplusplus
}
#endif
#endif

