/* ast_Call.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_CALL_H
#define CORTO_AST_CALL_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Call::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Call_construct(ast_Call _this);
#define ast_Call_construct(_this) _ast_Call_construct(ast_Call(_this))

/* virtual ::corto::ast::Call::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Call_hasReturnedResource(ast_Call _this);
#define ast_Call_hasReturnedResource(_this) _ast_Call_hasReturnedResource(ast_Call(_this))

/* ::corto::ast::Call::hasReturnedResource() */
CORTO_AST_EXPORT cx_bool _ast_Call_hasReturnedResource_v(ast_Call _this);
#define ast_Call_hasReturnedResource_v(_this) _ast_Call_hasReturnedResource_v(ast_Call(_this))

/* virtual ::corto::ast::Call::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Call_hasSideEffects(ast_Call _this);
#define ast_Call_hasSideEffects(_this) _ast_Call_hasSideEffects(ast_Call(_this))

/* ::corto::ast::Call::hasSideEffects() */
CORTO_AST_EXPORT cx_bool _ast_Call_hasSideEffects_v(ast_Call _this);
#define ast_Call_hasSideEffects_v(_this) _ast_Call_hasSideEffects_v(ast_Call(_this))

/* ::corto::ast::Call::setParameters(function function) */
CORTO_AST_EXPORT cx_void _ast_Call_setParameters(ast_Call _this, cx_function function);
#define ast_Call_setParameters(_this, function) _ast_Call_setParameters(ast_Call(_this), cx_function(function))

/* virtual ::corto::ast::Call::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Call_toIc(ast_Call _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Call_toIc(_this, program, storage, stored) _ast_Call_toIc(ast_Call(_this), ic_program(program), ic_storage(storage), stored)

/* ::corto::ast::Call::toIc(ic::program program,ic::storage storage,bool stored) */
CORTO_AST_EXPORT ic_node _ast_Call_toIc_v(ast_Call _this, ic_program program, ic_storage storage, cx_bool stored);
#define ast_Call_toIc_v(_this, program, storage, stored) _ast_Call_toIc_v(ast_Call(_this), ic_program(program), ic_storage(storage), stored)

#ifdef __cplusplus
}
#endif
#endif

