/* ast_Initializer.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_AST_INITIALIZER_H
#define CORTO_AST_INITIALIZER_H

#include "corto.h"
#include "ast_Expression.h"
#include "ast__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::ast::Initializer::construct() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_construct(ast_Initializer _this);
#define ast_Initializer_construct(_this) _ast_Initializer_construct(ast_Initializer(_this))

/* ::corto::ast::Initializer::currentType() */
CORTO_AST_EXPORT cx_type _ast_Initializer_currentType(ast_Initializer _this);
#define ast_Initializer_currentType(_this) _ast_Initializer_currentType(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::define() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_define(ast_Initializer _this);
#define ast_Initializer_define(_this) _ast_Initializer_define(ast_Initializer(_this))

/* ::corto::ast::Initializer::define() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_define_v(ast_Initializer _this);
#define ast_Initializer_define_v(_this) _ast_Initializer_define_v(ast_Initializer(_this))

/* ::corto::ast::Initializer::initFrame() */
CORTO_AST_EXPORT cx_uint16 _ast_Initializer_initFrame(ast_Initializer _this);
#define ast_Initializer_initFrame(_this) _ast_Initializer_initFrame(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::member(string name) */
CORTO_AST_EXPORT cx_int32 _ast_Initializer_member(ast_Initializer _this, cx_string name);
#define ast_Initializer_member(_this, name) _ast_Initializer_member(ast_Initializer(_this), name)

/* ::corto::ast::Initializer::member(string name) */
CORTO_AST_EXPORT cx_int32 _ast_Initializer_member_v(ast_Initializer _this, cx_string name);
#define ast_Initializer_member_v(_this, name) _ast_Initializer_member_v(ast_Initializer(_this), name)

/* virtual ::corto::ast::Initializer::next() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_next(ast_Initializer _this);
#define ast_Initializer_next(_this) _ast_Initializer_next(ast_Initializer(_this))

/* ::corto::ast::Initializer::next() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_next_v(ast_Initializer _this);
#define ast_Initializer_next_v(_this) _ast_Initializer_next_v(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::pop() */
CORTO_AST_EXPORT cx_int8 _ast_Initializer_pop(ast_Initializer _this);
#define ast_Initializer_pop(_this) _ast_Initializer_pop(ast_Initializer(_this))

/* ::corto::ast::Initializer::pop() */
CORTO_AST_EXPORT cx_int8 _ast_Initializer_pop_v(ast_Initializer _this);
#define ast_Initializer_pop_v(_this) _ast_Initializer_pop_v(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::popKey() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_popKey(ast_Initializer _this);
#define ast_Initializer_popKey(_this) _ast_Initializer_popKey(ast_Initializer(_this))

/* ::corto::ast::Initializer::popKey() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_popKey_v(ast_Initializer _this);
#define ast_Initializer_popKey_v(_this) _ast_Initializer_popKey_v(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::push() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_push(ast_Initializer _this);
#define ast_Initializer_push(_this) _ast_Initializer_push(ast_Initializer(_this))

/* ::corto::ast::Initializer::push() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_push_v(ast_Initializer _this);
#define ast_Initializer_push_v(_this) _ast_Initializer_push_v(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::pushKey() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_pushKey(ast_Initializer _this);
#define ast_Initializer_pushKey(_this) _ast_Initializer_pushKey(ast_Initializer(_this))

/* ::corto::ast::Initializer::pushKey() */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_pushKey_v(ast_Initializer _this);
#define ast_Initializer_pushKey_v(_this) _ast_Initializer_pushKey_v(ast_Initializer(_this))

/* ::corto::ast::Initializer::type() */
CORTO_AST_EXPORT cx_type _ast_Initializer_type(ast_Initializer _this);
#define ast_Initializer_type(_this) _ast_Initializer_type(ast_Initializer(_this))

/* virtual ::corto::ast::Initializer::value(Expression v) */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_value(ast_Initializer _this, ast_Expression v);
#define ast_Initializer_value(_this, v) _ast_Initializer_value(ast_Initializer(_this), ast_Expression(v))

/* ::corto::ast::Initializer::value(Expression v) */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_value_v(ast_Initializer _this, ast_Expression v);
#define ast_Initializer_value_v(_this, v) _ast_Initializer_value_v(ast_Initializer(_this), ast_Expression(v))

/* virtual ::corto::ast::Initializer::valueKey(Expression key) */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_valueKey(ast_Initializer _this, ast_Expression key);
#define ast_Initializer_valueKey(_this, key) _ast_Initializer_valueKey(ast_Initializer(_this), ast_Expression(key))

/* ::corto::ast::Initializer::valueKey(Expression key) */
CORTO_AST_EXPORT cx_int16 _ast_Initializer_valueKey_v(ast_Initializer _this, ast_Expression key);
#define ast_Initializer_valueKey_v(_this, key) _ast_Initializer_valueKey_v(ast_Initializer(_this), ast_Expression(key))

#ifdef __cplusplus
}
#endif
#endif

