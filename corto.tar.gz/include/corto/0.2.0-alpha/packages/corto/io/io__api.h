/* io__api.h
 *
 * API convenience functions for C-language.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_io__API_H
#define corto_io__API_H

#include "corto.h"
#include "io__interface.h"
#ifdef __cplusplus
extern "C" {
#endif
/* ::corto::io::file */
CORTO_IO_EXPORT io_file io_fileCreate(cx_string name, io_fileMode mode, cx_bool binary);
CORTO_IO_EXPORT io_file io_fileCreateChild(cx_object _parent, cx_string _name, cx_string name, io_fileMode mode, cx_bool binary);

CORTO_IO_EXPORT io_file io_fileDeclare(void);
CORTO_IO_EXPORT io_file io_fileDeclareChild(cx_object _parent, cx_string _name);
CORTO_IO_EXPORT cx_int16 io_fileDefine(io_file _this, cx_string name, io_fileMode mode, cx_bool binary);
CORTO_IO_EXPORT void io_fileUpdate(io_file _this, cx_string name, io_fileMode mode, cx_bool binary);
CORTO_IO_EXPORT void io_fileSet(io_file _this, cx_string name, io_fileMode mode, cx_bool binary);
CORTO_IO_EXPORT cx_string io_fileStr(io_file value);
CORTO_IO_EXPORT io_file io_fileFromStr(io_file value, cx_string str);
CORTO_IO_EXPORT cx_int16 io_fileCopy(io_file *dst, io_file src);
CORTO_IO_EXPORT cx_int16 io_fileCompare(io_file dst, io_file src);

/* ::corto::io::fileMode */
CORTO_IO_EXPORT io_fileMode* io_fileModeCreate(io_fileMode value);
CORTO_IO_EXPORT io_fileMode* io_fileModeCreateChild(cx_object _parent, cx_string _name, io_fileMode value);

CORTO_IO_EXPORT io_fileMode* io_fileModeDeclare(void);
CORTO_IO_EXPORT io_fileMode* io_fileModeDeclareChild(cx_object _parent, cx_string _name);
CORTO_IO_EXPORT cx_int16 io_fileModeDefine(io_fileMode* _this, io_fileMode value);
CORTO_IO_EXPORT void io_fileModeUpdate(io_fileMode* _this, io_fileMode value);
CORTO_IO_EXPORT void io_fileModeSet(io_fileMode* _this, io_fileMode value);
CORTO_IO_EXPORT cx_string io_fileModeStr(io_fileMode value);
CORTO_IO_EXPORT io_fileMode* io_fileModeFromStr(io_fileMode* value, cx_string str);
CORTO_IO_EXPORT cx_int16 io_fileModeCopy(io_fileMode* *dst, io_fileMode* src);
CORTO_IO_EXPORT cx_int16 io_fileModeCompare(io_fileMode* dst, io_fileMode* src);

CORTO_IO_EXPORT cx_int16 io_fileModeInit(io_fileMode* value);
CORTO_IO_EXPORT cx_int16 io_fileModeDeinit(io_fileMode* value);


/* <0x7fac48711c58> */
#define cx_octetSeqForeach(seq, elem) \
    cx_uint32 elem##_iter;\
    cx_octet elem;\
    for(elem##_iter=0; seq.buffer ? elem = seq.buffer[elem##_iter] : elem, elem##_iter<seq.length; elem##_iter++)\

CORTO_IO_EXPORT cx_octet* cx_octetSeqAppend(cx_octetSeq *seq);
CORTO_IO_EXPORT void cx_octetSeqSize(cx_octetSeq *seq, cx_uint32 length);
CORTO_IO_EXPORT void cx_octetSeqClear(cx_octetSeq *seq);

#ifdef __cplusplus
}
#endif
#endif

