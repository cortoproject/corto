/* io__interface.h
 *
 * This file contains generated code. Do not modify!
 */

#ifdef BUILDING_CORTO_IO
#include "io__type.h"
#include "io__api.h"
#include "io__meta.h"
#else
#include "corto/io/io__type.h"
#include "corto/io/io__api.h"
#include "corto/io/io__meta.h"
#endif

#if BUILDING_CORTO_IO && defined _MSC_VER
#define CORTO_IO_DLL_EXPORTED __declspec(dllexport)
#elif BUILDING_CORTO_IO
#define CORTO_IO_EXPORT __attribute__((__visibility__("default")))
#elif defined _MSC_VER
#define CORTO_IO_EXPORT __declspec(dllimport)
#else
#define CORTO_IO_EXPORT
#endif

