/* io.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_IO_H
#define CORTO_IO_H

#include "corto.h"
#include "io__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::io::print(string str) */
CORTO_IO_EXPORT cx_void _io_print(cx_string str);
#define io_print(str) _io_print(str)

/* ::corto::io::println(string str) */
CORTO_IO_EXPORT cx_void _io_println(cx_string str);
#define io_println(str) _io_println(str)

/* ::corto::io::readln() */
CORTO_IO_EXPORT cx_string _io_readln(void);
#define io_readln() _io_readln()

#ifdef __cplusplus
}
#endif
#endif

#include "io_file.h"
