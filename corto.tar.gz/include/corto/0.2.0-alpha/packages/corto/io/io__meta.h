/* io__meta.h
 *
 * Loads objects in object store.
 * This file contains generated code. Do not modify!
 */

#ifndef corto_io_META_H
#define corto_io_META_H

#include "corto.h"
#include "io__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

CORTO_IO_EXPORT extern cx_package _o;
extern cx_package io_o;
CORTO_IO_EXPORT extern io_file io_err_o;
CORTO_IO_EXPORT extern cx_class io_file_o;
CORTO_IO_EXPORT extern cx_member io_file_binary_o;
CORTO_IO_EXPORT extern cx_method io_file_construct_o;
CORTO_IO_EXPORT extern cx_method io_file_destruct_o;
CORTO_IO_EXPORT extern cx_method io_file_flush_o;
CORTO_IO_EXPORT extern cx_member io_file_handle_o;
CORTO_IO_EXPORT extern cx_member io_file_mode_o;
CORTO_IO_EXPORT extern cx_member io_file_name_o;
CORTO_IO_EXPORT extern cx_method io_file_read_o;
CORTO_IO_EXPORT extern cx_method io_file_readAll_o;
CORTO_IO_EXPORT extern cx_method io_file_readLn_o;
CORTO_IO_EXPORT extern cx_method io_file_readText_o;
CORTO_IO_EXPORT extern cx_method io_file_write_o;
CORTO_IO_EXPORT extern cx_method io_file_writeText_o;
CORTO_IO_EXPORT extern cx_enum io_fileMode_o;
CORTO_IO_EXPORT extern cx_constant ___ (*io_fileMode_Append_o);
CORTO_IO_EXPORT extern cx_constant ___ (*io_fileMode_Read_o);
CORTO_IO_EXPORT extern cx_constant ___ (*io_fileMode_ReadAppend_o);
CORTO_IO_EXPORT extern cx_constant ___ (*io_fileMode_ReadWrite_o);
CORTO_IO_EXPORT extern cx_constant ___ (*io_fileMode_Write_o);
CORTO_IO_EXPORT extern io_file io_in_o;
CORTO_IO_EXPORT extern io_file io_out_o;
CORTO_IO_EXPORT extern cx_function io_print_o;
CORTO_IO_EXPORT extern cx_function io_println_o;
CORTO_IO_EXPORT extern cx_function io_readln_o;

#ifdef __cplusplus
}
#endif
#endif

