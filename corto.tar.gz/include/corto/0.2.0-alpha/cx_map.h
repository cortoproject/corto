/* cx_map.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_map_H
#define cx_map_H

#include "corto.h"
#include "cx_collection.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::map::construct() */
cx_int16 _cx_map_construct(cx_map _this);
#define cx_map_construct(_this) _cx_map_construct(cx_map(_this))

/* ::corto::lang::map::init() */
cx_int16 _cx_map_init(cx_map _this);
#define cx_map_init(_this) _cx_map_init(cx_map(_this))

#ifdef __cplusplus
}
#endif
#endif

