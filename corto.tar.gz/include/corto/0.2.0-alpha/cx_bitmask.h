/* cx_bitmask.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_bitmask_H
#define cx_bitmask_H

#include "corto.h"
#include "cx_enum.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::bitmask::init() */
cx_int16 _cx_bitmask_init(cx_bitmask _this);
#define cx_bitmask_init(_this) _cx_bitmask_init(cx_bitmask(_this))

#ifdef __cplusplus
}
#endif
#endif

