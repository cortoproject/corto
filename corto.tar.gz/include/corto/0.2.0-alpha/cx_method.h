/* cx_method.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_method_H
#define cx_method_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::method::bind() */
cx_int16 _cx_method_bind(cx_method _this);
#define cx_method_bind(_this) _cx_method_bind(cx_method(_this))

/* ::corto::lang::method::init() */
cx_int16 _cx_method_init(cx_method _this);
#define cx_method_init(_this) _cx_method_init(cx_method(_this))

#ifdef __cplusplus
}
#endif
#endif

