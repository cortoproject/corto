/* cx_event.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_event_H
#define cx_event_H

#include "corto.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* virtual ::corto::lang::event::handle() */
void cx_event_handle(cx_event _this);

/* ::corto::lang::event::handle() */
cx_void _cx_event_handle_v(cx_event _this);
#define cx_event_handle_v(_this) _cx_event_handle_v(cx_event(_this))

/* ::corto::lang::event::uniqueKind() */
cx_int16 _cx_event_uniqueKind(void);
#define cx_event_uniqueKind() _cx_event_uniqueKind()

#ifdef __cplusplus
}
#endif
#endif

