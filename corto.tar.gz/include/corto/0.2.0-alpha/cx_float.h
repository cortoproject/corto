/* cx_float.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef cx_float_H
#define cx_float_H

#include "corto.h"
#include "cx_primitive.h"
#include "cx__type.h"
#include "cx__api.h"
#include "cx__meta.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ::corto::lang::float::init() */
cx_int16 _cx_float_init(cx_float _this);
#define cx_float_init(_this) _cx_float_init(cx_float(_this))

#ifdef __cplusplus
}
#endif
#endif

