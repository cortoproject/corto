/* notifyAction.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_CORE_NOTIFYACTION_H
#define CORTO_CORE_NOTIFYACTION_H

#include "corto/corto.h"
#include "corto/core/_type.h"
#include "corto/core/_api.h"
#include "corto/core/_meta.h"
#include "corto/_interface.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif

