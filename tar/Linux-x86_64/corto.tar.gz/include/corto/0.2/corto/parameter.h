/* corto_parameter.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_PARAMETER_H
#define CORTO_LANG_PARAMETER_H

#include "corto.h"
#include "corto__interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif
#endif

