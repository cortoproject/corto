/* text.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_TEXT_H
#define CORTO_LANG_TEXT_H

#include "corto/corto.h"
#include "corto/lang/_type.h"
#include "corto/lang/_api.h"
#include "corto/lang/_meta.h"
#include "corto/_interface.h"

#ifdef __cplusplus
extern "C" {
#endif


CORTO_EXPORT corto_int16 _corto_text_init(
    corto_text _this);
#define corto_text_init(_this) _corto_text_init(corto_text(_this))

#ifdef __cplusplus
}
#endif
#endif

