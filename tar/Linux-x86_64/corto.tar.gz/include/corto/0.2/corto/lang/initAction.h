/* initAction.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_LANG_INITACTION_H
#define CORTO_LANG_INITACTION_H

#include "corto/corto.h"
#include "corto/lang/_type.h"
#include "corto/lang/_api.h"
#include "corto/lang/_meta.h"
#include "corto/_interface.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif

