/* native.h
 *
 * This file contains generated code. Do not modify!
 */

#ifndef CORTO_NATIVE_H
#define CORTO_NATIVE_H

#include "corto/corto.h"
#include "corto/native/_type.h"
#include "corto/native/_api.h"
#include "corto/native/_meta.h"
#include "corto/_interface.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "corto/native/type.h"

#ifdef __cplusplus
}
#endif
#endif

